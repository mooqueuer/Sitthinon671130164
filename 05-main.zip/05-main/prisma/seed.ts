import 'dotenv/config'
import pg from 'pg'
import { PrismaPg } from '@prisma/adapter-pg'
import { PrismaClient } from '../generated/prisma/client'
import { scryptSync, randomBytes } from 'node:crypto'

const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL })
const adapter = new PrismaPg(pool)
const prisma = new PrismaClient({ adapter })

function hashPassword(password: string): string {
  const salt = randomBytes(16)
  const hashed = scryptSync(password, salt, 64)
  return `${salt.toString('hex')}:${hashed.toString('hex')}`
}

async function main() {
  console.log('Seeding database...')

  // --- Users ---
  const admin = await prisma.user.upsert({
    where: { email: 'admin@panit.dev' },
    update: {},
    create: {
      email: 'admin@panit.dev',
      name: 'Admin',
      passwordHash: hashPassword('password123'),
      role: 'ADMIN',
    },
  })

  const teacher1 = await prisma.user.upsert({
    where: { email: 'teacher@panit.dev' },
    update: {},
    create: {
      email: 'teacher@panit.dev',
      name: 'อ.สมชาย วิทยากร',
      passwordHash: hashPassword('password123'),
      role: 'TEACHER',
    },
  })

  const teacher2 = await prisma.user.upsert({
    where: { email: 'teacher2@panit.dev' },
    update: {},
    create: {
      email: 'teacher2@panit.dev',
      name: 'อ.สมหญิง โปรแกรมเมอร์',
      passwordHash: hashPassword('password123'),
      role: 'TEACHER',
    },
  })

  const student = await prisma.user.upsert({
    where: { email: 'student@panit.dev' },
    update: {},
    create: {
      email: 'student@panit.dev',
      name: 'นักเรียนทดสอบ',
      passwordHash: hashPassword('password123'),
      role: 'STUDENT',
    },
  })

  console.log('Users created')

  // --- Course 1: Web Development ---
  const course1 = await prisma.course.create({
    data: {
      title: 'พัฒนาเว็บไซต์ด้วย HTML, CSS, JavaScript',
      slug: 'web-development-fundamentals',
      description: 'เรียนรู้พื้นฐานการพัฒนาเว็บไซต์ตั้งแต่เริ่มต้น ครอบคลุม HTML5, CSS3 และ JavaScript สมัยใหม่ พร้อมโปรเจกต์จริงให้ฝึกทำ',
      price: 0,
      status: 'PUBLISHED',
      teacherId: teacher1.id,
      chapters: {
        create: [
          {
            title: 'บทนำ — เริ่มต้นกับ Web Development',
            position: 1,
            lessons: {
              create: [
                {
                  title: 'Web Development คืออะไร?',
                  type: 'TEXT',
                  content: '<h2>Web Development คืออะไร?</h2><p>Web Development คือการพัฒนาเว็บไซต์และเว็บแอปพลิเคชัน แบ่งออกเป็น 3 ส่วนหลัก:</p><ul><li><strong>Frontend</strong> — ส่วนที่ผู้ใช้มองเห็นและโต้ตอบได้ (HTML, CSS, JavaScript)</li><li><strong>Backend</strong> — ส่วนเซิร์ฟเวอร์ที่จัดการข้อมูลและ logic (Node.js, Python, etc.)</li><li><strong>Database</strong> — ที่เก็บข้อมูล (PostgreSQL, MongoDB, etc.)</li></ul><p>ในคอร์สนี้เราจะเน้นที่ Frontend เป็นหลัก</p>',
                  position: 1,
                },
                {
                  title: 'เครื่องมือที่ต้องเตรียม',
                  type: 'TEXT',
                  content: '<h2>เครื่องมือที่ต้องเตรียม</h2><ol><li><strong>Text Editor</strong> — แนะนำ VS Code (ฟรี)</li><li><strong>Web Browser</strong> — Chrome หรือ Firefox</li><li><strong>Terminal</strong> — ใช้ Command Prompt หรือ Terminal ที่มากับ VS Code</li></ol><p>ดาวน์โหลด VS Code ได้ที่ <code>code.visualstudio.com</code></p>',
                  position: 2,
                },
              ],
            },
          },
          {
            title: 'HTML — โครงสร้างของเว็บ',
            position: 2,
            lessons: {
              create: [
                {
                  title: 'HTML Tags พื้นฐาน',
                  type: 'TEXT',
                  content: '<h2>HTML Tags พื้นฐาน</h2><p>HTML ใช้ tags ในการกำหนดโครงสร้างของเนื้อหา:</p><pre><code>&lt;!DOCTYPE html&gt;\n&lt;html lang="th"&gt;\n&lt;head&gt;\n  &lt;title&gt;เว็บไซต์แรกของฉัน&lt;/title&gt;\n&lt;/head&gt;\n&lt;body&gt;\n  &lt;h1&gt;สวัสดี!&lt;/h1&gt;\n  &lt;p&gt;นี่คือเว็บไซต์แรกของฉัน&lt;/p&gt;\n&lt;/body&gt;\n&lt;/html&gt;</code></pre>',
                  position: 1,
                },
                {
                  title: 'Heading, Paragraph, Lists',
                  type: 'TEXT',
                  content: '<h2>Heading, Paragraph, Lists</h2><p><strong>Headings</strong> มี 6 ระดับ: <code>&lt;h1&gt;</code> ถึง <code>&lt;h6&gt;</code></p><p><strong>Paragraph</strong> ใช้ <code>&lt;p&gt;</code></p><p><strong>Lists:</strong></p><ul><li>Ordered list: <code>&lt;ol&gt;&lt;li&gt;...&lt;/li&gt;&lt;/ol&gt;</code></li><li>Unordered list: <code>&lt;ul&gt;&lt;li&gt;...&lt;/li&gt;&lt;/ul&gt;</code></li></ul>',
                  position: 2,
                },
                {
                  title: 'Links และ Images',
                  type: 'TEXT',
                  content: '<h2>Links และ Images</h2><p><strong>Links:</strong></p><pre><code>&lt;a href="https://example.com"&gt;คลิกที่นี่&lt;/a&gt;</code></pre><p><strong>Images:</strong></p><pre><code>&lt;img src="photo.jpg" alt="รูปภาพ" width="300"&gt;</code></pre><p>attribute <code>alt</code> สำคัญมากสำหรับ accessibility</p>',
                  position: 3,
                },
                {
                  title: 'Forms และ Input',
                  type: 'TEXT',
                  content: '<h2>Forms และ Input</h2><pre><code>&lt;form action="/submit" method="POST"&gt;\n  &lt;label for="name"&gt;ชื่อ:&lt;/label&gt;\n  &lt;input type="text" id="name" name="name"&gt;\n  \n  &lt;label for="email"&gt;อีเมล:&lt;/label&gt;\n  &lt;input type="email" id="email" name="email"&gt;\n  \n  &lt;button type="submit"&gt;ส่ง&lt;/button&gt;\n&lt;/form&gt;</code></pre>',
                  position: 4,
                },
              ],
            },
          },
          {
            title: 'CSS — ตกแต่งเว็บให้สวยงาม',
            position: 3,
            lessons: {
              create: [
                {
                  title: 'CSS Selectors',
                  type: 'TEXT',
                  content: '<h2>CSS Selectors</h2><p>CSS ใช้ selectors ในการเลือก element ที่ต้องการ style:</p><pre><code>/* Element selector */\np { color: blue; }\n\n/* Class selector */\n.highlight { background: yellow; }\n\n/* ID selector */\n#header { font-size: 24px; }\n\n/* Descendant selector */\nnav a { text-decoration: none; }</code></pre>',
                  position: 1,
                },
                {
                  title: 'Flexbox Layout',
                  type: 'TEXT',
                  content: '<h2>Flexbox Layout</h2><p>Flexbox ช่วยจัด layout ได้ง่าย:</p><pre><code>.container {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  gap: 16px;\n}\n\n.item {\n  flex: 1;\n}</code></pre><p>Properties สำคัญ: <code>flex-direction</code>, <code>justify-content</code>, <code>align-items</code>, <code>flex-wrap</code></p>',
                  position: 2,
                },
                {
                  title: 'Responsive Design',
                  type: 'TEXT',
                  content: '<h2>Responsive Design</h2><p>ใช้ Media Queries ทำให้เว็บแสดงผลดีทุกขนาดหน้าจอ:</p><pre><code>/* Mobile first */\n.grid {\n  display: grid;\n  grid-template-columns: 1fr;\n  gap: 16px;\n}\n\n/* Tablet */\n@media (min-width: 768px) {\n  .grid {\n    grid-template-columns: repeat(2, 1fr);\n  }\n}\n\n/* Desktop */\n@media (min-width: 1024px) {\n  .grid {\n    grid-template-columns: repeat(3, 1fr);\n  }\n}</code></pre>',
                  position: 3,
                },
              ],
            },
          },
          {
            title: 'JavaScript — เพิ่มความ Interactive',
            position: 4,
            lessons: {
              create: [
                {
                  title: 'Variables, Data Types, Functions',
                  type: 'TEXT',
                  content: '<h2>Variables, Data Types, Functions</h2><pre><code>// Variables\nconst name = "สมชาย";\nlet age = 25;\n\n// Data Types\nconst isStudent = true;    // boolean\nconst scores = [85, 92];   // array\nconst user = { name, age }; // object\n\n// Functions\nfunction greet(name) {\n  return `สวัสดี ${name}!`;\n}\n\n// Arrow function\nconst add = (a, b) => a + b;</code></pre>',
                  position: 1,
                },
                {
                  title: 'DOM Manipulation',
                  type: 'TEXT',
                  content: '<h2>DOM Manipulation</h2><pre><code>// เลือก element\nconst btn = document.querySelector("#myButton");\nconst items = document.querySelectorAll(".item");\n\n// เปลี่ยนเนื้อหา\nbtn.textContent = "คลิกฉัน!";\nbtn.style.color = "red";\n\n// เพิ่ม Event Listener\nbtn.addEventListener("click", () => {\n  alert("คุณคลิกปุ่มแล้ว!");\n});\n\n// สร้าง element ใหม่\nconst div = document.createElement("div");\ndiv.textContent = "สวัสดี!";\ndocument.body.appendChild(div);</code></pre>',
                  position: 2,
                },
              ],
            },
          },
        ],
      },
    },
  })
  console.log('Course 1 created:', course1.title)

  // --- Course 2: Vue.js ---
  const course2 = await prisma.course.create({
    data: {
      title: 'Vue.js 3 สำหรับมือใหม่',
      slug: 'vuejs-3-for-beginners',
      description: 'เรียนรู้ Vue.js 3 ตั้งแต่เริ่มต้น Composition API, Reactivity, Components, Router และ State Management พร้อมสร้างโปรเจกต์ Todo App',
      price: 590,
      status: 'PUBLISHED',
      teacherId: teacher1.id,
      chapters: {
        create: [
          {
            title: 'เริ่มต้นกับ Vue.js 3',
            position: 1,
            lessons: {
              create: [
                {
                  title: 'ทำไมต้อง Vue.js?',
                  type: 'TEXT',
                  content: '<h2>ทำไมต้อง Vue.js?</h2><p>Vue.js เป็น JavaScript framework สำหรับสร้าง UI ที่:</p><ul><li>เรียนรู้ง่าย — syntax ชัดเจน อ่านง่าย</li><li>ยืดหยุ่น — ใช้ได้ตั้งแต่โปรเจกต์เล็กถึงใหญ่</li><li>Performance ดี — Virtual DOM + Reactivity system</li><li>Ecosystem สมบูรณ์ — Vue Router, Pinia, Nuxt.js</li></ul>',
                  position: 1,
                },
                {
                  title: 'สร้างโปรเจกต์แรก',
                  type: 'TEXT',
                  content: '<h2>สร้างโปรเจกต์แรก</h2><pre><code>npm create vue@latest my-app\ncd my-app\nnpm install\nnpm run dev</code></pre><p>โครงสร้างโปรเจกต์:</p><pre><code>my-app/\n├── src/\n│   ├── App.vue\n│   ├── main.ts\n│   ├── components/\n│   └── views/\n├── index.html\n└── package.json</code></pre>',
                  position: 2,
                },
              ],
            },
          },
          {
            title: 'Composition API',
            position: 2,
            lessons: {
              create: [
                {
                  title: 'ref, reactive, computed',
                  type: 'TEXT',
                  content: '<h2>Reactivity ด้วย ref, reactive, computed</h2><pre><code>&lt;script setup lang="ts"&gt;\nimport { ref, reactive, computed } from "vue";\n\n// ref สำหรับ primitive values\nconst count = ref(0);\n\n// reactive สำหรับ objects\nconst user = reactive({\n  name: "สมชาย",\n  age: 25,\n});\n\n// computed — คำนวณจาก state อื่น\nconst doubled = computed(() => count.value * 2);\n\nfunction increment() {\n  count.value++;\n}\n&lt;/script&gt;\n\n&lt;template&gt;\n  &lt;p&gt;Count: {{ count }} (x2 = {{ doubled }})&lt;/p&gt;\n  &lt;button @click="increment"&gt;+1&lt;/button&gt;\n&lt;/template&gt;</code></pre>',
                  position: 1,
                },
                {
                  title: 'watch และ watchEffect',
                  type: 'TEXT',
                  content: '<h2>watch และ watchEffect</h2><pre><code>import { ref, watch, watchEffect } from "vue";\n\nconst search = ref("");\n\n// watch — ดักจับการเปลี่ยนแปลงของ state เฉพาะ\nwatch(search, (newVal, oldVal) => {\n  console.log(`Changed from "${oldVal}" to "${newVal}"`);\n});\n\n// watchEffect — รันทันทีและ track dependencies อัตโนมัติ\nwatchEffect(() => {\n  console.log("Search:", search.value);\n});</code></pre>',
                  position: 2,
                },
              ],
            },
          },
          {
            title: 'Components',
            position: 3,
            lessons: {
              create: [
                {
                  title: 'Props และ Events',
                  type: 'TEXT',
                  content: '<h2>Props และ Events</h2><pre><code>&lt;!-- Parent.vue --&gt;\n&lt;template&gt;\n  &lt;ChildComponent\n    :message="greeting"\n    @update="handleUpdate"\n  /&gt;\n&lt;/template&gt;\n\n&lt;!-- ChildComponent.vue --&gt;\n&lt;script setup lang="ts"&gt;\nconst props = defineProps&lt;{\n  message: string;\n}&gt;();\n\nconst emit = defineEmits&lt;{\n  update: [value: string];\n}&gt;();\n\nfunction doUpdate() {\n  emit("update", "new value");\n}\n&lt;/script&gt;</code></pre>',
                  position: 1,
                },
                {
                  title: 'Slots',
                  type: 'TEXT',
                  content: '<h2>Slots</h2><pre><code>&lt;!-- Card.vue --&gt;\n&lt;template&gt;\n  &lt;div class="card"&gt;\n    &lt;div class="card-header"&gt;\n      &lt;slot name="header"&gt;Default Header&lt;/slot&gt;\n    &lt;/div&gt;\n    &lt;div class="card-body"&gt;\n      &lt;slot&gt;Default content&lt;/slot&gt;\n    &lt;/div&gt;\n  &lt;/div&gt;\n&lt;/template&gt;\n\n&lt;!-- Usage --&gt;\n&lt;Card&gt;\n  &lt;template #header&gt;\n    &lt;h2&gt;My Card&lt;/h2&gt;\n  &lt;/template&gt;\n  &lt;p&gt;Card content here&lt;/p&gt;\n&lt;/Card&gt;</code></pre>',
                  position: 2,
                },
              ],
            },
          },
        ],
      },
    },
  })
  console.log('Course 2 created:', course2.title)

  // --- Course 3: Nuxt.js ---
  const course3 = await prisma.course.create({
    data: {
      title: 'สร้าง Full-Stack App ด้วย Nuxt 4',
      slug: 'fullstack-nuxt-4',
      description: 'เรียนรู้ Nuxt 4 แบบเจาะลึก ตั้งแต่ SSR, API Routes, Authentication, Database (Prisma) จนถึง Deploy สร้างแอปจริงตั้งแต่ต้นจนจบ',
      price: 1290,
      status: 'PUBLISHED',
      teacherId: teacher2.id,
      chapters: {
        create: [
          {
            title: 'Nuxt 4 Overview',
            position: 1,
            lessons: {
              create: [
                {
                  title: 'Nuxt 4 มีอะไรใหม่?',
                  type: 'TEXT',
                  content: '<h2>Nuxt 4 มีอะไรใหม่?</h2><ul><li><strong>app/ directory</strong> — โครงสร้างใหม่แยก app code จาก server</li><li><strong>Performance</strong> — Build เร็วขึ้น, Bundle เล็กลง</li><li><strong>TypeScript</strong> — รองรับ TypeScript 100%</li><li><strong>Nitro 2</strong> — Server engine ใหม่</li></ul>',
                  position: 1,
                },
                {
                  title: 'โครงสร้างโปรเจกต์ Nuxt 4',
                  type: 'TEXT',
                  content: '<h2>โครงสร้างโปรเจกต์</h2><pre><code>project/\n├── app/              # Frontend code\n│   ├── pages/\n│   ├── components/\n│   ├── layouts/\n│   ├── middleware/\n│   └── composables/\n├── server/           # Backend code\n│   ├── api/\n│   └── utils/\n├── prisma/           # Database schema\n├── nuxt.config.ts\n└── package.json</code></pre>',
                  position: 2,
                },
              ],
            },
          },
          {
            title: 'Server API Routes',
            position: 2,
            lessons: {
              create: [
                {
                  title: 'สร้าง REST API ด้วย Nitro',
                  type: 'TEXT',
                  content: '<h2>สร้าง REST API</h2><pre><code>// server/api/users.get.ts\nexport default defineEventHandler(async () => {\n  const users = await prisma.user.findMany();\n  return users;\n});\n\n// server/api/users.post.ts\nexport default defineEventHandler(async (event) => {\n  const body = await readBody(event);\n  const user = await prisma.user.create({ data: body });\n  return user;\n});\n\n// server/api/users/[id].get.ts\nexport default defineEventHandler(async (event) => {\n  const id = getRouterParam(event, "id");\n  return await prisma.user.findUnique({ where: { id } });\n});</code></pre>',
                  position: 1,
                },
                {
                  title: 'Validation ด้วย Zod',
                  type: 'TEXT',
                  content: '<h2>Validation ด้วย Zod</h2><pre><code>import { z } from "zod";\n\nconst schema = z.object({\n  email: z.string().email(),\n  name: z.string().min(1).max(100),\n  age: z.number().int().positive().optional(),\n});\n\nexport default defineEventHandler(async (event) => {\n  const body = await readBody(event);\n  const data = schema.parse(body); // throws if invalid\n  \n  return await prisma.user.create({ data });\n});</code></pre>',
                  position: 2,
                },
              ],
            },
          },
          {
            title: 'Authentication',
            position: 3,
            lessons: {
              create: [
                {
                  title: 'Session-based Auth ด้วย nuxt-auth-utils',
                  type: 'TEXT',
                  content: '<h2>Session-based Authentication</h2><pre><code>// server/api/auth/login.post.ts\nexport default defineEventHandler(async (event) => {\n  const { email, password } = await readBody(event);\n  const user = await prisma.user.findUnique({ where: { email } });\n  \n  if (!user || !verifyPassword(password, user.passwordHash)) {\n    throw createError({ statusCode: 401, statusMessage: "Invalid credentials" });\n  }\n  \n  await setUserSession(event, {\n    user: { id: user.id, email: user.email, name: user.name },\n  });\n  \n  return { user };\n});</code></pre><p>Session ถูกเก็บใน encrypted cookie อัตโนมัติ</p>',
                  position: 1,
                },
                {
                  title: 'Middleware ป้องกันหน้า',
                  type: 'TEXT',
                  content: '<h2>Route Middleware</h2><pre><code>// app/middleware/auth.ts\nexport default defineNuxtRouteMiddleware(() => {\n  const { loggedIn } = useUserSession();\n  if (!loggedIn.value) {\n    return navigateTo("/login");\n  }\n});\n\n// ใช้ใน page\ndefinePageMeta({ middleware: "auth" });</code></pre>',
                  position: 2,
                },
              ],
            },
          },
        ],
      },
    },
  })
  console.log('Course 3 created:', course3.title)

  // --- Course 4: Python ---
  const course4 = await prisma.course.create({
    data: {
      title: 'Python สำหรับผู้เริ่มต้น',
      slug: 'python-for-beginners',
      description: 'เรียน Python ตั้งแต่พื้นฐาน ตัวแปร, เงื่อนไข, ลูป, ฟังก์ชัน, OOP จนถึงการทำโปรเจกต์จริง เหมาะสำหรับคนไม่มีพื้นฐานเลย',
      price: 0,
      status: 'PUBLISHED',
      teacherId: teacher2.id,
      chapters: {
        create: [
          {
            title: 'พื้นฐาน Python',
            position: 1,
            lessons: {
              create: [
                {
                  title: 'ติดตั้ง Python และเขียนโปรแกรมแรก',
                  type: 'TEXT',
                  content: '<h2>ติดตั้ง Python</h2><p>ดาวน์โหลด Python จาก <code>python.org</code></p><pre><code># เขียนโปรแกรมแรก\nprint("สวัสดี Python!")\n\n# ตัวแปร\nname = "สมชาย"\nage = 25\nheight = 175.5\nis_student = True\n\nprint(f"ชื่อ {name} อายุ {age} ปี")</code></pre>',
                  position: 1,
                },
                {
                  title: 'เงื่อนไขและลูป',
                  type: 'TEXT',
                  content: '<h2>เงื่อนไขและลูป</h2><pre><code># if-elif-else\nscore = 85\nif score >= 80:\n    grade = "A"\nelif score >= 70:\n    grade = "B"\nelse:\n    grade = "C"\n\n# for loop\nfruits = ["apple", "banana", "cherry"]\nfor fruit in fruits:\n    print(fruit)\n\n# while loop\ncount = 0\nwhile count < 5:\n    print(count)\n    count += 1\n\n# list comprehension\nsquares = [x**2 for x in range(10)]</code></pre>',
                  position: 2,
                },
                {
                  title: 'ฟังก์ชัน',
                  type: 'TEXT',
                  content: '<h2>ฟังก์ชัน</h2><pre><code># ฟังก์ชันพื้นฐาน\ndef greet(name: str) -> str:\n    return f"สวัสดี {name}!"\n\n# Default parameters\ndef power(base: int, exp: int = 2) -> int:\n    return base ** exp\n\n# *args, **kwargs\ndef print_all(*args, **kwargs):\n    for arg in args:\n        print(arg)\n    for key, value in kwargs.items():\n        print(f"{key} = {value}")\n\n# Lambda\nsquare = lambda x: x ** 2</code></pre>',
                  position: 3,
                },
              ],
            },
          },
          {
            title: 'Data Structures',
            position: 2,
            lessons: {
              create: [
                {
                  title: 'List, Tuple, Set, Dictionary',
                  type: 'TEXT',
                  content: '<h2>Data Structures ใน Python</h2><pre><code># List — mutable, ordered\nfruits = ["apple", "banana"]\nfruits.append("cherry")\n\n# Tuple — immutable, ordered\npoint = (10, 20)\n\n# Set — unique, unordered\nunique = {1, 2, 3, 3}  # {1, 2, 3}\n\n# Dictionary — key-value pairs\nstudent = {\n    "name": "สมชาย",\n    "age": 25,\n    "grades": [85, 92, 78]\n}\nprint(student["name"])</code></pre>',
                  position: 1,
                },
              ],
            },
          },
        ],
      },
    },
  })
  console.log('Course 4 created:', course4.title)

  // --- Course 5: Database (Draft) ---
  const course5 = await prisma.course.create({
    data: {
      title: 'ออกแบบ Database ด้วย PostgreSQL',
      slug: 'database-design-postgresql',
      description: 'เรียนรู้การออกแบบ Database, SQL Queries, Indexing, Relations และ Performance Tuning ด้วย PostgreSQL',
      price: 890,
      status: 'DRAFT',
      teacherId: teacher1.id,
      chapters: {
        create: [
          {
            title: 'SQL พื้นฐาน',
            position: 1,
            lessons: {
              create: [
                {
                  title: 'SELECT, INSERT, UPDATE, DELETE',
                  type: 'TEXT',
                  content: '<h2>CRUD Operations</h2><pre><code>-- SELECT\nSELECT * FROM users WHERE age > 20;\n\n-- INSERT\nINSERT INTO users (name, email) VALUES (\'สมชาย\', \'som@email.com\');\n\n-- UPDATE\nUPDATE users SET name = \'ใหม่\' WHERE id = 1;\n\n-- DELETE\nDELETE FROM users WHERE id = 1;</code></pre>',
                  position: 1,
                },
              ],
            },
          },
        ],
      },
    },
  })
  console.log('Course 5 created (DRAFT):', course5.title)

  // --- Add Quizzes ---

  // Quiz for HTML chapter
  const htmlLesson = await prisma.lesson.findFirst({
    where: { title: 'HTML Tags พื้นฐาน' },
  })
  if (htmlLesson) {
    await prisma.quiz.create({
      data: {
        title: 'ทดสอบความรู้ HTML พื้นฐาน',
        passingScore: 60,
        lessonId: htmlLesson.id,
        questions: {
          create: [
            {
              text: 'Tag ใดใช้สำหรับสร้างหัวข้อใหญ่ที่สุดใน HTML?',
              type: 'MULTIPLE_CHOICE',
              position: 0,
              options: {
                create: [
                  { text: '<h1>', isCorrect: true },
                  { text: '<h6>', isCorrect: false },
                  { text: '<header>', isCorrect: false },
                  { text: '<title>', isCorrect: false },
                ],
              },
            },
            {
              text: 'Tag <p> ใช้สำหรับอะไร?',
              type: 'MULTIPLE_CHOICE',
              position: 1,
              options: {
                create: [
                  { text: 'สร้างรูปภาพ', isCorrect: false },
                  { text: 'สร้างย่อหน้า (paragraph)', isCorrect: true },
                  { text: 'สร้างลิงก์', isCorrect: false },
                  { text: 'สร้างปุ่ม', isCorrect: false },
                ],
              },
            },
            {
              text: 'HTML ย่อมาจาก HyperText Markup Language',
              type: 'TRUE_FALSE',
              position: 2,
              options: {
                create: [
                  { text: 'จริง', isCorrect: true },
                  { text: 'ไม่จริง', isCorrect: false },
                ],
              },
            },
            {
              text: 'Tag ใดใช้สร้าง unordered list?',
              type: 'MULTIPLE_CHOICE',
              position: 3,
              options: {
                create: [
                  { text: '<ol>', isCorrect: false },
                  { text: '<ul>', isCorrect: true },
                  { text: '<li>', isCorrect: false },
                  { text: '<list>', isCorrect: false },
                ],
              },
            },
            {
              text: 'Attribute "alt" ใน <img> มีไว้เพื่ออะไร?',
              type: 'MULTIPLE_CHOICE',
              position: 4,
              options: {
                create: [
                  { text: 'กำหนดขนาดรูป', isCorrect: false },
                  { text: 'กำหนดสีพื้นหลัง', isCorrect: false },
                  { text: 'อธิบายรูปภาพ (accessibility)', isCorrect: true },
                  { text: 'กำหนด link ของรูป', isCorrect: false },
                ],
              },
            },
          ],
        },
      },
    })
    console.log('Quiz created for HTML lesson')
  }

  // Quiz for Vue.js Composition API
  const vueLesson = await prisma.lesson.findFirst({
    where: { title: 'ref, reactive, computed' },
  })
  if (vueLesson) {
    await prisma.quiz.create({
      data: {
        title: 'ทดสอบ Vue.js Composition API',
        passingScore: 70,
        lessonId: vueLesson.id,
        questions: {
          create: [
            {
              text: 'ref() ใช้กับข้อมูลประเภทใด?',
              type: 'MULTIPLE_CHOICE',
              position: 0,
              options: {
                create: [
                  { text: 'Primitive values (string, number, boolean)', isCorrect: true },
                  { text: 'เฉพาะ object เท่านั้น', isCorrect: false },
                  { text: 'เฉพาะ array เท่านั้น', isCorrect: false },
                  { text: 'ใช้ไม่ได้กับ TypeScript', isCorrect: false },
                ],
              },
            },
            {
              text: 'ในการเข้าถึงค่า ref ใน <script setup> ต้องใช้ .value',
              type: 'TRUE_FALSE',
              position: 1,
              options: {
                create: [
                  { text: 'จริง', isCorrect: true },
                  { text: 'ไม่จริง', isCorrect: false },
                ],
              },
            },
            {
              text: 'computed() ต่างจาก method อย่างไร?',
              type: 'MULTIPLE_CHOICE',
              position: 2,
              options: {
                create: [
                  { text: 'computed cache ผลลัพธ์จนกว่า dependency เปลี่ยน', isCorrect: true },
                  { text: 'computed เร็วกว่าเสมอ', isCorrect: false },
                  { text: 'method ใช้ใน template ไม่ได้', isCorrect: false },
                  { text: 'ไม่ต่างกัน', isCorrect: false },
                ],
              },
            },
          ],
        },
      },
    })
    console.log('Quiz created for Vue.js lesson')
  }

  // --- Enroll student in free courses ---
  const freeCourses = [course1, course4]
  for (const course of freeCourses) {
    await prisma.enrollment.create({
      data: { userId: student.id, courseId: course.id },
    })
  }
  console.log('Student enrolled in free courses')

  // --- Add some lesson progress ---
  const firstLessons = await prisma.lesson.findMany({
    where: { chapter: { courseId: course1.id } },
    orderBy: [{ chapter: { position: 'asc' } }, { position: 'asc' }],
    take: 4,
  })
  for (const lesson of firstLessons) {
    await prisma.lessonProgress.create({
      data: { userId: student.id, lessonId: lesson.id, completed: true, completedAt: new Date() },
    })
  }
  console.log('Lesson progress added')

  console.log('\n--- Seed Complete ---')
  console.log('Test accounts (password: password123):')
  console.log('  Admin:   admin@panit.dev')
  console.log('  Teacher: teacher@panit.dev')
  console.log('  Teacher: teacher2@panit.dev')
  console.log('  Student: student@panit.dev')
  console.log(`\nCourses: ${course1.title}, ${course2.title}, ${course3.title}, ${course4.title}, ${course5.title} (draft)`)
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
    process.exit(0)
  })
