export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)

  const earned = await prisma.userBadge.findMany({
    where: { userId: user.id },
    select: { badge: true, createdAt: true },
  })
  const earnedSet = new Set(earned.map(b => b.badge))
  const earnedMap = new Map(earned.map(b => [b.badge, b.createdAt]))

  const allBadges = Object.entries(BADGE_DEFINITIONS).map(([key, def]) => ({
    key,
    ...def,
    earned: earnedSet.has(key),
    earnedAt: earnedMap.get(key) || null,
  }))

  return allBadges
})
