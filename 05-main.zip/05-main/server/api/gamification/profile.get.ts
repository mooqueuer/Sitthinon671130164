export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)

  const [xpRecords, streak, badges] = await Promise.all([
    prisma.userXP.aggregate({
      where: { userId: user.id },
      _sum: { amount: true },
    }),
    prisma.userStreak.findUnique({ where: { userId: user.id } }),
    prisma.userBadge.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
    }),
  ])

  return {
    totalXP: xpRecords._sum.amount || 0,
    streak: streak ? {
      currentStreak: streak.currentStreak,
      longestStreak: streak.longestStreak,
      lastActiveDate: streak.lastActiveDate,
    } : { currentStreak: 0, longestStreak: 0, lastActiveDate: null },
    badges: badges.map(b => b.badge),
    badgeCount: badges.length,
  }
})
