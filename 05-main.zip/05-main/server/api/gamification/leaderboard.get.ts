export default defineEventHandler(async () => {
  // Get top 20 users by XP
  const xpTotals = await prisma.userXP.groupBy({
    by: ['userId'],
    _sum: { amount: true },
    orderBy: { _sum: { amount: 'desc' } },
    take: 20,
  })

  if (xpTotals.length === 0) return []

  const users = await prisma.user.findMany({
    where: { id: { in: xpTotals.map(x => x.userId) } },
    select: { id: true, name: true, avatar: true },
  })

  const userMap = new Map(users.map(u => [u.id, u]))

  return xpTotals.map((x, index) => ({
    rank: index + 1,
    user: userMap.get(x.userId) || { id: x.userId, name: 'User', avatar: null },
    totalXP: x._sum.amount || 0,
  }))
})
