export default defineEventHandler(async (event) => {
  const query = getQuery(event)
  const page = Math.max(1, Number(query.page) || 1)
  const limit = Math.min(50, Math.max(1, Number(query.limit) || 12))
  const search = (query.search as string) || ''
  const category = (query.category as string) || ''
  const pricetype = (query.pricetype as string) || ''
  const sort = (query.sort as string) || 'newest'
  const skip = (page - 1) * limit

  const where: any = { status: 'PUBLISHED' }
  if (search) {
    where.OR = [
      { title: { contains: search, mode: 'insensitive' } },
      { description: { contains: search, mode: 'insensitive' } },
    ]
  }
  if (category) {
    where.categoryId = category
  }
  if (pricetype === 'free') {
    where.price = 0
  } else if (pricetype === 'paid') {
    where.price = { gt: 0 }
  }

  let orderBy: any = { createdAt: 'desc' }
  if (sort === 'popular') {
    orderBy = { enrollments: { _count: 'desc' } }
  } else if (sort === 'rating') {
    orderBy = { reviews: { _count: 'desc' } }
  }

  const [courses, total] = await Promise.all([
    prisma.course.findMany({
      where,
      select: {
        id: true,
        title: true,
        slug: true,
        description: true,
        price: true,
        thumbnail: true,
        createdAt: true,
        category: { select: { id: true, name: true, slug: true } },
        teacher: { select: { id: true, name: true } },
        _count: { select: { enrollments: true, chapters: true } },
        reviews: { select: { rating: true } },
      },
      orderBy,
      skip,
      take: limit,
    }),
    prisma.course.count({ where }),
  ])

  const coursesWithRating = courses.map((c) => {
    const ratings = c.reviews
    const avgRating = ratings.length > 0
      ? Math.round((ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length) * 10) / 10
      : 0
    const { reviews, ...rest } = c
    return { ...rest, avgRating, reviewCount: ratings.length }
  })

  return { courses: coursesWithRating, total, page, totalPages: Math.ceil(total / limit) }
})
