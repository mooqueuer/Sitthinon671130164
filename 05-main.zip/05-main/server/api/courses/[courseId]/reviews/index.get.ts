export default defineEventHandler(async (event) => {
  const courseId = getRouterParam(event, 'courseId')!
  const query = getQuery(event)
  const page = Math.max(1, Number(query.page) || 1)
  const limit = 10
  const skip = (page - 1) * limit

  const [reviews, total] = await Promise.all([
    prisma.review.findMany({
      where: { courseId },
      select: {
        id: true,
        rating: true,
        comment: true,
        createdAt: true,
        user: { select: { id: true, name: true, avatar: true } },
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    }),
    prisma.review.count({ where: { courseId } }),
  ])

  const agg = await prisma.review.aggregate({
    where: { courseId },
    _avg: { rating: true },
    _count: true,
  })

  return {
    reviews,
    total,
    page,
    totalPages: Math.ceil(total / limit),
    avgRating: agg._avg.rating ? Math.round(agg._avg.rating * 10) / 10 : 0,
    reviewCount: agg._count,
  }
})
