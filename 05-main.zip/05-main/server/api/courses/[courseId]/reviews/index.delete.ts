export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)
  const courseId = getRouterParam(event, 'courseId')!

  await prisma.review.deleteMany({
    where: { userId: user.id, courseId },
  })

  return { success: true }
})
