import { z } from 'zod'

const schema = z.object({
  rating: z.number().int().min(1).max(5),
  comment: z.string().max(1000).optional(),
})

export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)
  const courseId = getRouterParam(event, 'courseId')!
  const body = await readBody(event)
  const data = schema.parse(body)

  // Verify enrolled
  const enrollment = await prisma.enrollment.findUnique({
    where: { userId_courseId: { userId: user.id, courseId } },
  })
  if (!enrollment) {
    throw createError({ statusCode: 403, statusMessage: 'You must be enrolled to review' })
  }

  const review = await prisma.review.upsert({
    where: { userId_courseId: { userId: user.id, courseId } },
    update: { rating: data.rating, comment: data.comment },
    create: { userId: user.id, courseId, rating: data.rating, comment: data.comment },
  })

  return review
})
