export default defineEventHandler(async (event) => {
  const user = await requireRole(event, 'TEACHER', 'ADMIN')
  const courseId = getRouterParam(event, 'courseId')!
  const id = getRouterParam(event, 'id')!

  const lesson = await prisma.lesson.findFirst({
    where: { id, chapter: { courseId } },
    include: { chapter: { include: { course: true } } },
  })
  if (!lesson) throw createError({ statusCode: 404, statusMessage: 'Lesson not found' })
  if (lesson.chapter.course.teacherId !== user.id && user.role !== 'ADMIN') {
    throw createError({ statusCode: 403, statusMessage: 'Forbidden' })
  }

  await prisma.lesson.delete({ where: { id } })
  return { success: true }
})
