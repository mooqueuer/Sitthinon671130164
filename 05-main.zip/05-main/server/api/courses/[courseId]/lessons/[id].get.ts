export default defineEventHandler(async (event) => {
  const courseId = getRouterParam(event, 'courseId')!
  const id = getRouterParam(event, 'id')!

  const lesson = await prisma.lesson.findFirst({
    where: { id, chapter: { courseId } },
    select: {
      id: true,
      title: true,
      type: true,
      content: true,
      videoUrl: true,
      fileUrl: true,
      position: true,
      chapterId: true,
      chapter: { select: { id: true, title: true, courseId: true } },
      quiz: { select: { id: true, title: true } },
    },
  })

  if (!lesson) {
    throw createError({ statusCode: 404, statusMessage: 'Lesson not found' })
  }

  return lesson
})
