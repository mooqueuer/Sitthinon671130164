import { z } from 'zod'

const schema = z.object({
  title: z.string().min(1).max(200).optional(),
  type: z.enum(['VIDEO', 'TEXT', 'FILE']).optional(),
  content: z.string().optional(),
  videoUrl: z.string().optional(),
  fileUrl: z.string().optional(),
  position: z.number().int().min(0).optional(),
  chapterId: z.string().optional(),
})

export default defineEventHandler(async (event) => {
  const user = await requireRole(event, 'TEACHER', 'ADMIN')
  const courseId = getRouterParam(event, 'courseId')!
  const id = getRouterParam(event, 'id')!
  const body = await readBody(event)
  const data = schema.parse(body)

  const lesson = await prisma.lesson.findFirst({
    where: { id, chapter: { courseId } },
    include: { chapter: { include: { course: true } } },
  })
  if (!lesson) throw createError({ statusCode: 404, statusMessage: 'Lesson not found' })
  if (lesson.chapter.course.teacherId !== user.id && user.role !== 'ADMIN') {
    throw createError({ statusCode: 403, statusMessage: 'Forbidden' })
  }

  return await prisma.lesson.update({ where: { id }, data })
})
