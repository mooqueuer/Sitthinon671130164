export default defineEventHandler(async (event) => {
  const courseId = getRouterParam(event, 'courseId')!

  const lessons = await prisma.lesson.findMany({
    where: { chapter: { courseId } },
    orderBy: [{ chapter: { position: 'asc' } }, { position: 'asc' }],
    select: {
      id: true,
      title: true,
      type: true,
      position: true,
      chapterId: true,
      chapter: { select: { id: true, title: true, position: true } },
    },
  })

  return lessons
})
