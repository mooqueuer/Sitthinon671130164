import { z } from 'zod'

const schema = z.object({
  title: z.string().min(1).max(200),
  type: z.enum(['VIDEO', 'TEXT', 'FILE']).default('TEXT'),
  content: z.string().optional(),
  videoUrl: z.string().optional(),
  fileUrl: z.string().optional(),
  chapterId: z.string().min(1),
})

export default defineEventHandler(async (event) => {
  const user = await requireRole(event, 'TEACHER', 'ADMIN')
  const courseId = getRouterParam(event, 'courseId')!
  const body = await readBody(event)
  const data = schema.parse(body)

  // Verify chapter belongs to this course and user owns it
  const chapter = await prisma.chapter.findFirst({
    where: { id: data.chapterId, courseId },
    include: { course: true },
  })
  if (!chapter) throw createError({ statusCode: 404, statusMessage: 'Chapter not found' })
  if (chapter.course.teacherId !== user.id && user.role !== 'ADMIN') {
    throw createError({ statusCode: 403, statusMessage: 'Forbidden' })
  }

  const lastLesson = await prisma.lesson.findFirst({
    where: { chapterId: data.chapterId },
    orderBy: { position: 'desc' },
  })

  const lesson = await prisma.lesson.create({
    data: {
      title: data.title,
      type: data.type,
      content: data.content,
      videoUrl: data.videoUrl,
      fileUrl: data.fileUrl,
      position: (lastLesson?.position ?? 0) + 1,
      chapterId: data.chapterId,
    },
  })

  return lesson
})
