export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)
  const courseId = getRouterParam(event, 'courseId')!
  const id = getRouterParam(event, 'id')!

  // Verify enrollment
  const enrollment = await prisma.enrollment.findUnique({
    where: { userId_courseId: { userId: user.id, courseId } },
  })
  if (!enrollment) {
    throw createError({ statusCode: 403, statusMessage: 'Not enrolled in this course' })
  }

  // Verify lesson belongs to course
  const lesson = await prisma.lesson.findFirst({
    where: { id, chapter: { courseId } },
  })
  if (!lesson) {
    throw createError({ statusCode: 404, statusMessage: 'Lesson not found' })
  }

  const progress = await prisma.lessonProgress.upsert({
    where: { userId_lessonId: { userId: user.id, lessonId: id } },
    update: { completed: true, completedAt: new Date() },
    create: { userId: user.id, lessonId: id, completed: true, completedAt: new Date() },
  })

  // Gamification: XP + streak + badges
  await awardXP(user.id, 10, 'Lesson completed', { courseId, lessonId: id }).catch(() => {})
  await updateStreak(user.id).catch(() => {})
  await checkBadges(user.id).catch(() => {})

  // Check if certificate can be issued
  const cert = await checkAndIssueCertificate(user.id, courseId).catch(() => null)
  if (cert) {
    await awardXP(user.id, 100, 'Course completed', { courseId }).catch(() => {})
    await checkBadges(user.id).catch(() => {})
  }

  return progress
})
