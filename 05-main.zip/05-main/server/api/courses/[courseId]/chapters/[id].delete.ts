export default defineEventHandler(async (event) => {
  const user = await requireRole(event, 'TEACHER', 'ADMIN')
  const courseId = getRouterParam(event, 'courseId')!
  const id = getRouterParam(event, 'id')!

  const chapter = await prisma.chapter.findFirst({ where: { id, courseId }, include: { course: true } })
  if (!chapter) throw createError({ statusCode: 404, statusMessage: 'Chapter not found' })
  if (chapter.course.teacherId !== user.id && user.role !== 'ADMIN') {
    throw createError({ statusCode: 403, statusMessage: 'Forbidden' })
  }

  await prisma.chapter.delete({ where: { id } })
  return { success: true }
})
