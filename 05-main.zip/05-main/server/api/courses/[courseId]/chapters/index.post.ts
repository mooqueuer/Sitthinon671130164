import { z } from 'zod'

const schema = z.object({
  title: z.string().min(1).max(200),
})

export default defineEventHandler(async (event) => {
  const user = await requireRole(event, 'TEACHER', 'ADMIN')
  const courseId = getRouterParam(event, 'courseId')!
  const body = await readBody(event)
  const data = schema.parse(body)

  const course = await prisma.course.findUnique({ where: { id: courseId } })
  if (!course) throw createError({ statusCode: 404, statusMessage: 'Course not found' })
  if (course.teacherId !== user.id && user.role !== 'ADMIN') {
    throw createError({ statusCode: 403, statusMessage: 'Forbidden' })
  }

  const lastChapter = await prisma.chapter.findFirst({
    where: { courseId },
    orderBy: { position: 'desc' },
  })

  const chapter = await prisma.chapter.create({
    data: {
      title: data.title,
      position: (lastChapter?.position ?? 0) + 1,
      courseId,
    },
  })

  return chapter
})
