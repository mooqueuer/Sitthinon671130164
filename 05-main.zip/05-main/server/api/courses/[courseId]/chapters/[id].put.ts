import { z } from 'zod'

const schema = z.object({
  title: z.string().min(1).max(200).optional(),
  position: z.number().int().min(0).optional(),
})

export default defineEventHandler(async (event) => {
  const user = await requireRole(event, 'TEACHER', 'ADMIN')
  const courseId = getRouterParam(event, 'courseId')!
  const id = getRouterParam(event, 'id')!
  const body = await readBody(event)
  const data = schema.parse(body)

  const chapter = await prisma.chapter.findFirst({ where: { id, courseId }, include: { course: true } })
  if (!chapter) throw createError({ statusCode: 404, statusMessage: 'Chapter not found' })
  if (chapter.course.teacherId !== user.id && user.role !== 'ADMIN') {
    throw createError({ statusCode: 403, statusMessage: 'Forbidden' })
  }

  return await prisma.chapter.update({ where: { id }, data })
})
