export default defineEventHandler(async (event) => {
  const courseId = getRouterParam(event, 'courseId')!

  const chapters = await prisma.chapter.findMany({
    where: { courseId },
    orderBy: { position: 'asc' },
    select: {
      id: true,
      title: true,
      position: true,
      lessons: {
        orderBy: { position: 'asc' },
        select: {
          id: true,
          title: true,
          type: true,
          position: true,
        },
      },
    },
  })

  return chapters
})
