import { z } from 'zod'

const createCourseSchema = z.object({
  title: z.string().min(1).max(200),
  description: z.string().optional(),
  price: z.number().min(0).default(0),
  thumbnail: z.string().optional(),
  categoryId: z.string().optional(),
})

export default defineEventHandler(async (event) => {
  const user = await requireRole(event, 'TEACHER', 'ADMIN')
  const body = await readBody(event)
  const data = createCourseSchema.parse(body)

  // Generate slug from title
  const baseSlug = data.title
    .toLowerCase()
    .replace(/[^a-z0-9\u0E00-\u0E7F]+/g, '-')
    .replace(/^-|-$/g, '')

  // Ensure unique slug
  let slug = baseSlug
  let count = 0
  while (await prisma.course.findUnique({ where: { slug } })) {
    count++
    slug = `${baseSlug}-${count}`
  }

  const course = await prisma.course.create({
    data: {
      title: data.title,
      slug,
      description: data.description,
      price: data.price,
      thumbnail: data.thumbnail,
      categoryId: data.categoryId || null,
      teacherId: user.id,
    },
  })

  return course
})
