export default defineEventHandler(async (event) => {
  const id = getRouterParam(event, 'id')!

  const course = await prisma.course.findFirst({
    where: { OR: [{ id }, { slug: id }] },
    select: {
      id: true,
      title: true,
      slug: true,
      description: true,
      price: true,
      thumbnail: true,
      status: true,
      createdAt: true,
      teacherId: true,
      teacher: { select: { id: true, name: true } },
      category: { select: { id: true, name: true, slug: true } },
      chapters: {
        orderBy: { position: 'asc' },
        select: {
          id: true,
          title: true,
          position: true,
          lessons: {
            orderBy: { position: 'asc' },
            select: {
              id: true,
              title: true,
              type: true,
              position: true,
            },
          },
        },
      },
      _count: { select: { enrollments: true } },
    },
  })

  if (!course) {
    throw createError({ statusCode: 404, statusMessage: 'Course not found' })
  }

  // Allow viewing draft courses only for owner/admin
  if (course.status === 'DRAFT') {
    const session = await getUserSession(event)
    const user = session.user as any
    if (!user || (user.id !== course.teacherId && user.role !== 'ADMIN')) {
      throw createError({ statusCode: 404, statusMessage: 'Course not found' })
    }
  }

  return course
})
