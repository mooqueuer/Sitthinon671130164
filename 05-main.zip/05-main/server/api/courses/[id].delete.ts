export default defineEventHandler(async (event) => {
  const user = await requireRole(event, 'TEACHER', 'ADMIN')
  const id = getRouterParam(event, 'id')!

  const course = await prisma.course.findUnique({ where: { id } })
  if (!course) {
    throw createError({ statusCode: 404, statusMessage: 'Course not found' })
  }
  if (course.teacherId !== user.id && user.role !== 'ADMIN') {
    throw createError({ statusCode: 403, statusMessage: 'Forbidden' })
  }

  await prisma.course.delete({ where: { id } })

  return { success: true }
})
