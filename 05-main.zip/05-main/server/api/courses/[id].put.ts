import { z } from 'zod'

const updateCourseSchema = z.object({
  title: z.string().min(1).max(200).optional(),
  description: z.string().optional(),
  price: z.number().min(0).optional(),
  thumbnail: z.string().optional(),
  status: z.enum(['DRAFT', 'PUBLISHED']).optional(),
})

export default defineEventHandler(async (event) => {
  const user = await requireRole(event, 'TEACHER', 'ADMIN')
  const id = getRouterParam(event, 'id')!
  const body = await readBody(event)
  const data = updateCourseSchema.parse(body)

  const course = await prisma.course.findUnique({ where: { id } })
  if (!course) {
    throw createError({ statusCode: 404, statusMessage: 'Course not found' })
  }
  if (course.teacherId !== user.id && user.role !== 'ADMIN') {
    throw createError({ statusCode: 403, statusMessage: 'Forbidden' })
  }

  const updated = await prisma.course.update({
    where: { id },
    data,
  })

  return updated
})
