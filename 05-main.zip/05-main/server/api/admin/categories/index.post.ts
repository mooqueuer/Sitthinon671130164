import { z } from 'zod'

const schema = z.object({
  name: z.string().min(1).max(100),
})

export default defineEventHandler(async (event) => {
  await requireRole(event, 'ADMIN')
  const body = await readBody(event)
  const data = schema.parse(body)

  const slug = data.name
    .toLowerCase()
    .replace(/[^a-z0-9\u0E00-\u0E7F]+/g, '-')
    .replace(/^-|-$/g, '')

  const category = await prisma.category.create({
    data: { name: data.name, slug },
  })

  return category
})
