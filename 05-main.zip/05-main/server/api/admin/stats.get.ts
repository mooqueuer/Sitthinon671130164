export default defineEventHandler(async (event) => {
  await requireRole(event, 'ADMIN')

  const [
    totalUsers,
    totalCourses,
    totalEnrollments,
    pendingPayments,
    totalRevenue,
    recentUsers,
    roleDistribution,
  ] = await Promise.all([
    prisma.user.count(),
    prisma.course.count(),
    prisma.enrollment.count(),
    prisma.payment.count({ where: { status: 'PENDING' } }),
    prisma.payment.aggregate({ where: { status: 'CONFIRMED' }, _sum: { amount: true } }),
    prisma.user.findMany({
      orderBy: { createdAt: 'desc' },
      take: 5,
      select: { id: true, name: true, email: true, role: true, createdAt: true },
    }),
    prisma.user.groupBy({ by: ['role'], _count: true }),
  ])

  return {
    totalUsers,
    totalCourses,
    totalEnrollments,
    pendingPayments,
    totalRevenue: totalRevenue._sum.amount || 0,
    recentUsers,
    roleDistribution: roleDistribution.map((r) => ({ role: r.role, count: r._count })),
  }
})
