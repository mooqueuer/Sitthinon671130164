import { z } from 'zod'

const schema = z.object({
  role: z.enum(['ADMIN', 'TEACHER', 'STUDENT']),
})

export default defineEventHandler(async (event) => {
  await requireRole(event, 'ADMIN')
  const id = getRouterParam(event, 'id')!
  const body = await readBody(event)
  const { role } = schema.parse(body)

  const user = await prisma.user.findUnique({ where: { id } })
  if (!user) {
    throw createError({ statusCode: 404, statusMessage: 'User not found' })
  }

  const updated = await prisma.user.update({
    where: { id },
    data: { role },
    select: { id: true, email: true, name: true, role: true },
  })

  return updated
})
