export default defineEventHandler(async (event) => {
  await requireRole(event, 'ADMIN')
  const query = getQuery(event)
  const page = Math.max(1, Number(query.page) || 1)
  const limit = Math.min(50, Math.max(1, Number(query.limit) || 20))
  const skip = (page - 1) * limit

  const [courses, total] = await Promise.all([
    prisma.course.findMany({
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
      select: {
        id: true,
        title: true,
        slug: true,
        price: true,
        status: true,
        createdAt: true,
        teacher: { select: { id: true, name: true, email: true } },
        _count: { select: { enrollments: true, chapters: true } },
      },
    }),
    prisma.course.count(),
  ])

  return { courses, total, page, totalPages: Math.ceil(total / limit) }
})
