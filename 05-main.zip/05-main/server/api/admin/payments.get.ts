export default defineEventHandler(async (event) => {
  await requireRole(event, 'ADMIN')
  const query = getQuery(event)
  const page = Math.max(1, Number(query.page) || 1)
  const limit = Math.min(50, Math.max(1, Number(query.limit) || 20))
  const status = query.status as string | undefined
  const skip = (page - 1) * limit

  const where: any = {}
  if (status && ['PENDING', 'CONFIRMED', 'REJECTED'].includes(status)) {
    where.status = status
  }

  const [payments, total] = await Promise.all([
    prisma.payment.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
      select: {
        id: true,
        amount: true,
        status: true,
        method: true,
        createdAt: true,
        user: { select: { id: true, name: true, email: true } },
        course: { select: { id: true, title: true } },
      },
    }),
    prisma.payment.count({ where }),
  ])

  return { payments, total, page, totalPages: Math.ceil(total / limit) }
})
