export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)
  const lessonId = getRouterParam(event, 'lessonId')!

  await prisma.note.deleteMany({
    where: { userId: user.id, lessonId },
  })

  return { success: true }
})
