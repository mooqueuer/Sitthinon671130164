import { z } from 'zod'

const schema = z.object({
  content: z.string().min(1).max(10000),
})

export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)
  const lessonId = getRouterParam(event, 'lessonId')!
  const body = await readBody(event)
  const data = schema.parse(body)

  const note = await prisma.note.upsert({
    where: { userId_lessonId: { userId: user.id, lessonId } },
    update: { content: data.content },
    create: { userId: user.id, lessonId, content: data.content },
  })

  return note
})
