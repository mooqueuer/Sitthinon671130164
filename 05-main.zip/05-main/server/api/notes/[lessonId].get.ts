export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)
  const lessonId = getRouterParam(event, 'lessonId')!

  const note = await prisma.note.findUnique({
    where: { userId_lessonId: { userId: user.id, lessonId } },
  })

  return note
})
