export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)

  const enrollments = await prisma.enrollment.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    select: {
      id: true,
      status: true,
      createdAt: true,
      course: {
        select: {
          id: true,
          title: true,
          slug: true,
          thumbnail: true,
          teacher: { select: { name: true } },
          chapters: {
            select: {
              lessons: { select: { id: true } },
            },
          },
        },
      },
    },
  })

  // Calculate progress for each enrollment
  const result = await Promise.all(
    enrollments.map(async (e) => {
      const lessonIds = e.course.chapters.flatMap((c) => c.lessons.map((l) => l.id))
      const totalLessons = lessonIds.length

      const completedCount = totalLessons > 0
        ? await prisma.lessonProgress.count({
            where: { userId: user.id, lessonId: { in: lessonIds }, completed: true },
          })
        : 0

      return {
        id: e.id,
        status: e.status,
        createdAt: e.createdAt,
        course: {
          id: e.course.id,
          title: e.course.title,
          slug: e.course.slug,
          thumbnail: e.course.thumbnail,
          teacherName: e.course.teacher.name,
        },
        progress: totalLessons > 0 ? Math.round((completedCount / totalLessons) * 100) : 0,
        completedLessons: completedCount,
        totalLessons,
      }
    })
  )

  return result
})
