export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)
  const courseId = getRouterParam(event, 'courseId')!

  const enrollment = await prisma.enrollment.findUnique({
    where: { userId_courseId: { userId: user.id, courseId } },
    select: { id: true, status: true },
  })

  return { enrolled: !!enrollment, status: enrollment?.status || null }
})
