import { z } from 'zod'

const schema = z.object({
  courseId: z.string().min(1),
})

export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)
  const body = await readBody(event)
  const { courseId } = schema.parse(body)

  const course = await prisma.course.findUnique({ where: { id: courseId } })
  if (!course || course.status !== 'PUBLISHED') {
    throw createError({ statusCode: 404, statusMessage: 'Course not found' })
  }

  // Check if already enrolled
  const existing = await prisma.enrollment.findUnique({
    where: { userId_courseId: { userId: user.id, courseId } },
  })
  if (existing) {
    throw createError({ statusCode: 409, statusMessage: 'Already enrolled' })
  }

  // Free course: auto-enroll. Paid course: require payment
  if (course.price > 0) {
    // Check for confirmed payment
    const payment = await prisma.payment.findFirst({
      where: { userId: user.id, courseId, status: 'CONFIRMED' },
    })
    if (!payment) {
      throw createError({ statusCode: 402, statusMessage: 'Payment required' })
    }
  }

  const enrollment = await prisma.enrollment.create({
    data: { userId: user.id, courseId },
  })

  return enrollment
})
