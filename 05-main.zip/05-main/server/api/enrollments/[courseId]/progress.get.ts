export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)
  const courseId = getRouterParam(event, 'courseId')!

  const enrollment = await prisma.enrollment.findUnique({
    where: { userId_courseId: { userId: user.id, courseId } },
  })
  if (!enrollment) {
    throw createError({ statusCode: 404, statusMessage: 'Not enrolled' })
  }

  const lessons = await prisma.lesson.findMany({
    where: { chapter: { courseId } },
    select: { id: true },
  })
  const lessonIds = lessons.map((l) => l.id)
  const totalLessons = lessonIds.length

  const completedLessons = totalLessons > 0
    ? await prisma.lessonProgress.count({
        where: { userId: user.id, lessonId: { in: lessonIds }, completed: true },
      })
    : 0

  const progressRecords = await prisma.lessonProgress.findMany({
    where: { userId: user.id, lessonId: { in: lessonIds } },
    select: { lessonId: true, completed: true, completedAt: true },
  })

  return {
    totalLessons,
    completedLessons,
    percentage: totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0,
    lessons: progressRecords,
  }
})
