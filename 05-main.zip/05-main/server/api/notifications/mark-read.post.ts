import { z } from 'zod'

const schema = z.object({
  id: z.string().optional(),
})

export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)
  const body = await readBody(event)
  const data = schema.parse(body)

  if (data.id) {
    await prisma.notification.updateMany({
      where: { id: data.id, userId: user.id },
      data: { read: true },
    })
  } else {
    await prisma.notification.updateMany({
      where: { userId: user.id, read: false },
      data: { read: true },
    })
  }

  return { success: true }
})
