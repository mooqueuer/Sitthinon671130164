export default defineEventHandler(async (event) => {
  const user = await requireRole(event, 'TEACHER', 'ADMIN')

  const courses = await prisma.course.findMany({
    where: { teacherId: user.id },
    select: {
      id: true,
      title: true,
      price: true,
    },
  })

  const result = []

  for (const course of courses) {
    const revenue = await prisma.payment.aggregate({
      where: { courseId: course.id, status: 'CONFIRMED' },
      _sum: { amount: true },
      _count: true,
    })

    result.push({
      courseId: course.id,
      title: course.title,
      price: course.price,
      revenue: revenue._sum.amount || 0,
      sales: revenue._count,
    })
  }

  return result.sort((a, b) => b.revenue - a.revenue)
})
