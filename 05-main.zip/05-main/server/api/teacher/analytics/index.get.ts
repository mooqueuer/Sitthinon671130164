export default defineEventHandler(async (event) => {
  const user = await requireRole(event, 'TEACHER', 'ADMIN')

  const courses = await prisma.course.findMany({
    where: { teacherId: user.id },
    select: { id: true },
  })
  const courseIds = courses.map(c => c.id)

  const [totalStudents, totalRevenue, totalCourses, totalReviews] = await Promise.all([
    prisma.enrollment.count({ where: { courseId: { in: courseIds } } }),
    prisma.payment.aggregate({
      where: { courseId: { in: courseIds }, status: 'CONFIRMED' },
      _sum: { amount: true },
    }),
    courses.length,
    prisma.review.count({ where: { courseId: { in: courseIds } } }),
  ])

  const avgRating = await prisma.review.aggregate({
    where: { courseId: { in: courseIds } },
    _avg: { rating: true },
  })

  return {
    totalStudents,
    totalRevenue: totalRevenue._sum.amount || 0,
    totalCourses,
    totalReviews,
    avgRating: avgRating._avg.rating ? Math.round(avgRating._avg.rating * 10) / 10 : 0,
  }
})
