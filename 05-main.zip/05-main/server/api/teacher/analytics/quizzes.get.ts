export default defineEventHandler(async (event) => {
  const user = await requireRole(event, 'TEACHER', 'ADMIN')

  const quizzes = await prisma.quiz.findMany({
    where: { lesson: { chapter: { course: { teacherId: user.id } } } },
    select: {
      id: true,
      title: true,
      lesson: {
        select: {
          title: true,
          chapter: { select: { course: { select: { title: true } } } },
        },
      },
      _count: { select: { attempts: true } },
    },
  })

  const result = []

  for (const quiz of quizzes) {
    const [total, passed] = await Promise.all([
      prisma.quizAttempt.count({ where: { quizId: quiz.id } }),
      prisma.quizAttempt.count({ where: { quizId: quiz.id, passed: true } }),
    ])

    result.push({
      quizId: quiz.id,
      quizTitle: quiz.title,
      lessonTitle: quiz.lesson.title,
      courseTitle: quiz.lesson.chapter.course.title,
      totalAttempts: total,
      passed,
      failed: total - passed,
      passRate: total > 0 ? Math.round((passed / total) * 100) : 0,
    })
  }

  return result
})
