export default defineEventHandler(async (event) => {
  const user = await requireRole(event, 'TEACHER', 'ADMIN')

  const courses = await prisma.course.findMany({
    where: { teacherId: user.id },
    select: { id: true },
  })
  const courseIds = courses.map(c => c.id)

  // Last 30 days enrollment trend
  const thirtyDaysAgo = new Date()
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

  const enrollments = await prisma.enrollment.findMany({
    where: {
      courseId: { in: courseIds },
      createdAt: { gte: thirtyDaysAgo },
    },
    select: { createdAt: true },
    orderBy: { createdAt: 'asc' },
  })

  // Group by day
  const dailyCounts: Record<string, number> = {}
  for (let i = 0; i < 30; i++) {
    const d = new Date()
    d.setDate(d.getDate() - (29 - i))
    dailyCounts[d.toISOString().slice(0, 10)] = 0
  }
  for (const e of enrollments) {
    const key = new Date(e.createdAt).toISOString().slice(0, 10)
    if (dailyCounts[key] !== undefined) dailyCounts[key]++
  }

  return Object.entries(dailyCounts).map(([date, count]) => ({
    date,
    label: new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    count,
  }))
})
