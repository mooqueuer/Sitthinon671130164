export default defineEventHandler(async (event) => {
  const user = await requireRole(event, 'TEACHER', 'ADMIN')

  const courses = await prisma.course.findMany({
    where: { teacherId: user.id, status: 'PUBLISHED' },
    select: {
      id: true,
      title: true,
      _count: { select: { enrollments: true } },
      chapters: {
        select: {
          lessons: { select: { id: true } },
        },
      },
    },
  })

  const result = []

  for (const course of courses) {
    const totalLessons = course.chapters.reduce((sum, c) => sum + c.lessons.length, 0)
    if (totalLessons === 0) continue

    const lessonIds = course.chapters.flatMap(c => c.lessons.map(l => l.id))

    // Count enrollments where ALL lessons are completed
    const enrollments = await prisma.enrollment.findMany({
      where: { courseId: course.id },
      select: { userId: true },
    })

    let completedCount = 0
    for (const enrollment of enrollments) {
      const completed = await prisma.lessonProgress.count({
        where: {
          userId: enrollment.userId,
          lessonId: { in: lessonIds },
          completed: true,
        },
      })
      if (completed >= totalLessons) completedCount++
    }

    result.push({
      courseId: course.id,
      title: course.title,
      enrolled: course._count.enrollments,
      completed: completedCount,
      rate: course._count.enrollments > 0 ? Math.round((completedCount / course._count.enrollments) * 100) : 0,
    })
  }

  return result
})
