export default defineEventHandler(async (event) => {
  const user = await requireRole(event, 'TEACHER', 'ADMIN')

  const courses = await prisma.course.findMany({
    where: { teacherId: user.id },
    orderBy: { createdAt: 'desc' },
    select: {
      id: true,
      title: true,
      slug: true,
      description: true,
      price: true,
      thumbnail: true,
      status: true,
      createdAt: true,
      _count: { select: { enrollments: true, chapters: true } },
    },
  })

  return courses
})
