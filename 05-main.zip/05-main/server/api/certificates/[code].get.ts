export default defineEventHandler(async (event) => {
  const code = getRouterParam(event, 'code')!

  const certificate = await prisma.certificate.findUnique({
    where: { code },
    select: {
      id: true,
      code: true,
      issuedAt: true,
      user: { select: { id: true, name: true, email: true } },
      course: {
        select: {
          id: true,
          title: true,
          teacher: { select: { name: true } },
        },
      },
    },
  })

  if (!certificate) {
    throw createError({ statusCode: 404, statusMessage: 'Certificate not found' })
  }

  return certificate
})
