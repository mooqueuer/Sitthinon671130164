export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)

  const certificates = await prisma.certificate.findMany({
    where: { userId: user.id },
    select: {
      id: true,
      code: true,
      issuedAt: true,
      course: {
        select: {
          id: true,
          title: true,
          teacher: { select: { name: true } },
        },
      },
    },
    orderBy: { issuedAt: 'desc' },
  })

  return certificates
})
