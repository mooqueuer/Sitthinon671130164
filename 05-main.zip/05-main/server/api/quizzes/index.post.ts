import { z } from 'zod'

const optionSchema = z.object({
  text: z.string().min(1),
  isCorrect: z.boolean().default(false),
})

const questionSchema = z.object({
  text: z.string().min(1),
  type: z.enum(['MULTIPLE_CHOICE', 'TRUE_FALSE']).default('MULTIPLE_CHOICE'),
  position: z.number().int().min(0),
  options: z.array(optionSchema).min(2),
})

const schema = z.object({
  title: z.string().min(1).max(200),
  lessonId: z.string().min(1),
  passingScore: z.number().int().min(0).max(100).default(70),
  timeLimit: z.number().int().positive().optional(),
  questions: z.array(questionSchema).min(1),
})

export default defineEventHandler(async (event) => {
  const user = await requireRole(event, 'TEACHER', 'ADMIN')
  const body = await readBody(event)
  const data = schema.parse(body)

  // Verify lesson exists and user owns the course
  const lesson = await prisma.lesson.findUnique({
    where: { id: data.lessonId },
    include: { chapter: { include: { course: true } } },
  })
  if (!lesson) throw createError({ statusCode: 404, statusMessage: 'Lesson not found' })
  if (lesson.chapter.course.teacherId !== user.id && user.role !== 'ADMIN') {
    throw createError({ statusCode: 403, statusMessage: 'Forbidden' })
  }

  // Check if quiz already exists for this lesson
  const existing = await prisma.quiz.findUnique({ where: { lessonId: data.lessonId } })
  if (existing) {
    throw createError({ statusCode: 409, statusMessage: 'Quiz already exists for this lesson' })
  }

  const quiz = await prisma.quiz.create({
    data: {
      title: data.title,
      lessonId: data.lessonId,
      passingScore: data.passingScore,
      timeLimit: data.timeLimit,
      questions: {
        create: data.questions.map((q) => ({
          text: q.text,
          type: q.type,
          position: q.position,
          options: {
            create: q.options,
          },
        })),
      },
    },
    include: { questions: { include: { options: true } } },
  })

  return quiz
})
