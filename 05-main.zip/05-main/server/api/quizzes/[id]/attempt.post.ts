import { z } from 'zod'

const schema = z.object({
  answers: z.array(z.object({
    questionId: z.string().min(1),
    selectedOptionId: z.string().min(1),
  })).min(1),
})

export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)
  const quizId = getRouterParam(event, 'id')!
  const body = await readBody(event)
  const data = schema.parse(body)

  // Verify quiz exists
  const quiz = await prisma.quiz.findUnique({
    where: { id: quizId },
    include: {
      questions: { include: { options: true } },
      lesson: { include: { chapter: true } },
    },
  })
  if (!quiz) throw createError({ statusCode: 404, statusMessage: 'Quiz not found' })

  // Verify enrollment
  const enrollment = await prisma.enrollment.findUnique({
    where: { userId_courseId: { userId: user.id, courseId: quiz.lesson.chapter.courseId } },
  })
  if (!enrollment) {
    throw createError({ statusCode: 403, statusMessage: 'Not enrolled' })
  }

  // Grade the quiz
  const totalQuestions = quiz.questions.length
  let correctCount = 0

  const answerData = data.answers.map((a) => {
    const question = quiz.questions.find((q) => q.id === a.questionId)
    if (question) {
      const correctOption = question.options.find((o) => o.isCorrect)
      if (correctOption && correctOption.id === a.selectedOptionId) {
        correctCount++
      }
    }
    return {
      questionId: a.questionId,
      selectedOptionId: a.selectedOptionId,
    }
  })

  const score = totalQuestions > 0 ? Math.round((correctCount / totalQuestions) * 100) : 0
  const passed = score >= quiz.passingScore

  const attempt = await prisma.quizAttempt.create({
    data: {
      userId: user.id,
      quizId,
      score,
      passed,
      completedAt: new Date(),
      answers: {
        create: answerData,
      },
    },
    include: { answers: true },
  })

  if (passed) {
    // Gamification: XP + badges
    await awardXP(user.id, 25, 'Quiz passed', { quizId, courseId: quiz.lesson.chapter.courseId }).catch(() => {})
    await checkBadges(user.id).catch(() => {})

    // Check if certificate can be issued
    await checkAndIssueCertificate(user.id, quiz.lesson.chapter.courseId).catch(() => {})
  }

  return { attempt, score, passed, correctCount, totalQuestions }
})
