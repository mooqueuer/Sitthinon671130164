export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)
  const quizId = getRouterParam(event, 'id')!

  const attempts = await prisma.quizAttempt.findMany({
    where: { quizId, userId: user.id },
    orderBy: { startedAt: 'desc' },
    select: {
      id: true,
      score: true,
      passed: true,
      startedAt: true,
      completedAt: true,
    },
  })

  return attempts
})
