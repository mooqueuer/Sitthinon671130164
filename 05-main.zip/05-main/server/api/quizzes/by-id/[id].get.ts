export default defineEventHandler(async (event) => {
  const id = getRouterParam(event, 'id')!

  const quiz = await prisma.quiz.findUnique({
    where: { id },
    select: {
      id: true,
      title: true,
      passingScore: true,
      timeLimit: true,
      lessonId: true,
      questions: {
        orderBy: { position: 'asc' },
        select: {
          id: true,
          text: true,
          type: true,
          position: true,
          options: {
            select: {
              id: true,
              text: true,
            },
          },
        },
      },
    },
  })

  if (!quiz) {
    throw createError({ statusCode: 404, statusMessage: 'Quiz not found' })
  }

  return quiz
})
