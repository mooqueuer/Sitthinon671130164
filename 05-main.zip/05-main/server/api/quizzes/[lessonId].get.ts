export default defineEventHandler(async (event) => {
  const lessonId = getRouterParam(event, 'lessonId')!

  const quiz = await prisma.quiz.findUnique({
    where: { lessonId },
    select: {
      id: true,
      title: true,
      passingScore: true,
      timeLimit: true,
      questions: {
        orderBy: { position: 'asc' },
        select: {
          id: true,
          text: true,
          type: true,
          position: true,
          options: {
            select: {
              id: true,
              text: true,
              // Don't send isCorrect to students
            },
          },
        },
      },
    },
  })

  if (!quiz) {
    throw createError({ statusCode: 404, statusMessage: 'Quiz not found' })
  }

  return quiz
})
