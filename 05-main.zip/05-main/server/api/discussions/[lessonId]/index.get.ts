export default defineEventHandler(async (event) => {
  const lessonId = getRouterParam(event, 'lessonId')!
  const query = getQuery(event)
  const page = Math.max(1, Number(query.page) || 1)
  const limit = 10
  const skip = (page - 1) * limit

  const [discussions, total] = await Promise.all([
    prisma.discussion.findMany({
      where: { lessonId },
      select: {
        id: true,
        title: true,
        content: true,
        createdAt: true,
        user: { select: { id: true, name: true, avatar: true } },
        _count: { select: { replies: true } },
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    }),
    prisma.discussion.count({ where: { lessonId } }),
  ])

  return { discussions, total, page, totalPages: Math.ceil(total / limit) }
})
