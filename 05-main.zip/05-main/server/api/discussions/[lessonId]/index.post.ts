import { z } from 'zod'

const schema = z.object({
  title: z.string().min(1).max(200),
  content: z.string().min(1).max(5000),
})

export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)
  const lessonId = getRouterParam(event, 'lessonId')!
  const body = await readBody(event)
  const data = schema.parse(body)

  const discussion = await prisma.discussion.create({
    data: {
      title: data.title,
      content: data.content,
      userId: user.id,
      lessonId,
    },
    select: {
      id: true,
      title: true,
      content: true,
      createdAt: true,
      user: { select: { id: true, name: true, avatar: true } },
      _count: { select: { replies: true } },
    },
  })

  return discussion
})
