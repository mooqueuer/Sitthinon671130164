import { z } from 'zod'

const schema = z.object({
  content: z.string().min(1).max(5000),
})

export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)
  const id = getRouterParam(event, 'id')!
  const body = await readBody(event)
  const data = schema.parse(body)

  const discussion = await prisma.discussion.findUnique({ where: { id } })
  if (!discussion) {
    throw createError({ statusCode: 404, statusMessage: 'Discussion not found' })
  }

  const reply = await prisma.discussionReply.create({
    data: {
      content: data.content,
      userId: user.id,
      discussionId: id,
    },
    select: {
      id: true,
      content: true,
      createdAt: true,
      user: { select: { id: true, name: true, avatar: true } },
    },
  })

  // Notify discussion author (if not self)
  if (discussion.userId !== user.id) {
    await prisma.notification.create({
      data: {
        type: 'DISCUSSION_REPLY',
        title: 'New reply to your discussion',
        message: `${user.name || 'Someone'} replied to "${discussion.title}"`,
        userId: discussion.userId,
        link: `/learn/${discussion.lessonId}`,
      },
    }).catch(() => {})
  }

  return reply
})
