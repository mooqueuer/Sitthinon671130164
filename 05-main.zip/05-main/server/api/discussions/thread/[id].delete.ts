export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)
  const id = getRouterParam(event, 'id')!

  const discussion = await prisma.discussion.findUnique({ where: { id } })
  if (!discussion) {
    throw createError({ statusCode: 404, statusMessage: 'Discussion not found' })
  }

  if (discussion.userId !== user.id && (user as any).role !== 'ADMIN') {
    throw createError({ statusCode: 403, statusMessage: 'Not authorized' })
  }

  await prisma.discussion.delete({ where: { id } })

  return { success: true }
})
