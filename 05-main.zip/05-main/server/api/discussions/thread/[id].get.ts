export default defineEventHandler(async (event) => {
  const id = getRouterParam(event, 'id')!

  const discussion = await prisma.discussion.findUnique({
    where: { id },
    select: {
      id: true,
      title: true,
      content: true,
      createdAt: true,
      user: { select: { id: true, name: true, avatar: true } },
      replies: {
        select: {
          id: true,
          content: true,
          createdAt: true,
          user: { select: { id: true, name: true, avatar: true } },
        },
        orderBy: { createdAt: 'asc' },
      },
    },
  })

  if (!discussion) {
    throw createError({ statusCode: 404, statusMessage: 'Discussion not found' })
  }

  return discussion
})
