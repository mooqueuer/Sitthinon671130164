export default defineEventHandler(async () => {
  const categories = await prisma.category.findMany({
    orderBy: { name: 'asc' },
    select: {
      id: true,
      name: true,
      slug: true,
      _count: { select: { courses: true } },
    },
  })

  return categories
})
