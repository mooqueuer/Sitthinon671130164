export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)

  const bookmarks = await prisma.bookmark.findMany({
    where: { userId: user.id },
    select: {
      id: true,
      createdAt: true,
      lesson: {
        select: {
          id: true,
          title: true,
          type: true,
          chapter: {
            select: {
              course: {
                select: { id: true, title: true },
              },
            },
          },
        },
      },
    },
    orderBy: { createdAt: 'desc' },
  })

  return bookmarks
})
