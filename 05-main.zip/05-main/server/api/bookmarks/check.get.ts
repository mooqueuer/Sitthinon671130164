export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)
  const query = getQuery(event)
  const lessonId = query.lessonId as string
  if (!lessonId) return { bookmarked: false }

  const bookmark = await prisma.bookmark.findUnique({
    where: { userId_lessonId: { userId: user.id, lessonId } },
  })

  return { bookmarked: !!bookmark }
})
