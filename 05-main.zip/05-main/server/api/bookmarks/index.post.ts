import { z } from 'zod'

const schema = z.object({
  lessonId: z.string().min(1),
})

export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)
  const body = await readBody(event)
  const data = schema.parse(body)

  const existing = await prisma.bookmark.findUnique({
    where: { userId_lessonId: { userId: user.id, lessonId: data.lessonId } },
  })

  if (existing) {
    await prisma.bookmark.delete({ where: { id: existing.id } })
    return { bookmarked: false }
  }

  await prisma.bookmark.create({
    data: { userId: user.id, lessonId: data.lessonId },
  })
  return { bookmarked: true }
})
