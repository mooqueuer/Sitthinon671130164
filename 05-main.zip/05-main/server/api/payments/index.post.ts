import { z } from 'zod'

const schema = z.object({
  courseId: z.string().min(1),
  method: z.string().optional(),
})

export default defineEventHandler(async (event) => {
  const user = await requireAuth(event)
  const body = await readBody(event)
  const { courseId, method } = schema.parse(body)

  const course = await prisma.course.findUnique({ where: { id: courseId } })
  if (!course || course.status !== 'PUBLISHED') {
    throw createError({ statusCode: 404, statusMessage: 'Course not found' })
  }
  if (course.price <= 0) {
    throw createError({ statusCode: 400, statusMessage: 'This course is free' })
  }

  // Check if already has pending/confirmed payment
  const existing = await prisma.payment.findFirst({
    where: { userId: user.id, courseId, status: { in: ['PENDING', 'CONFIRMED'] } },
  })
  if (existing) {
    throw createError({ statusCode: 409, statusMessage: 'Payment already exists' })
  }

  const payment = await prisma.payment.create({
    data: {
      userId: user.id,
      courseId,
      amount: course.price,
      method,
    },
  })

  return payment
})
