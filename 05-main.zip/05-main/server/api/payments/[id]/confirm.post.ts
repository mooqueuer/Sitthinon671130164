export default defineEventHandler(async (event) => {
  await requireRole(event, 'ADMIN')
  const id = getRouterParam(event, 'id')!

  const payment = await prisma.payment.findUnique({ where: { id } })
  if (!payment) {
    throw createError({ statusCode: 404, statusMessage: 'Payment not found' })
  }
  if (payment.status !== 'PENDING') {
    throw createError({ statusCode: 400, statusMessage: 'Payment is not pending' })
  }

  // Confirm payment and auto-enroll
  const [updatedPayment] = await prisma.$transaction([
    prisma.payment.update({
      where: { id },
      data: { status: 'CONFIRMED' },
    }),
    prisma.enrollment.upsert({
      where: { userId_courseId: { userId: payment.userId, courseId: payment.courseId } },
      update: {},
      create: { userId: payment.userId, courseId: payment.courseId },
    }),
  ])

  // Notify user
  const course = await prisma.course.findUnique({ where: { id: payment.courseId }, select: { title: true } })
  await createNotification({
    userId: payment.userId,
    type: 'PAYMENT_CONFIRMED',
    title: 'Payment Confirmed',
    message: `Your payment for "${course?.title || 'a course'}" has been confirmed. You can now start learning!`,
    link: `/my-courses`,
  }).catch(() => {})

  return updatedPayment
})
