export default defineEventHandler(async (event) => {
  await requireRole(event, 'ADMIN')
  const id = getRouterParam(event, 'id')!

  const payment = await prisma.payment.findUnique({ where: { id } })
  if (!payment) {
    throw createError({ statusCode: 404, statusMessage: 'Payment not found' })
  }
  if (payment.status !== 'PENDING') {
    throw createError({ statusCode: 400, statusMessage: 'Payment is not pending' })
  }

  const updated = await prisma.payment.update({
    where: { id },
    data: { status: 'REJECTED' },
  })

  // Notify user
  const course = await prisma.course.findUnique({ where: { id: payment.courseId }, select: { title: true } })
  await createNotification({
    userId: payment.userId,
    type: 'PAYMENT_REJECTED',
    title: 'Payment Rejected',
    message: `Your payment for "${course?.title || 'a course'}" was rejected. Please contact support for details.`,
    link: `/courses/${payment.courseId}`,
  }).catch(() => {})

  return updated
})
