import type { H3Event } from 'h3'
import type { Role } from '../../generated/prisma/client'

export async function requireAuth(event: H3Event) {
  const session = await getUserSession(event)
  if (!session.user) {
    throw createError({ statusCode: 401, statusMessage: 'Not authenticated' })
  }
  return session.user as { id: string; email: string; name: string | null; role: Role }
}

export async function requireRole(event: H3Event, ...roles: Role[]) {
  const user = await requireAuth(event)
  if (!roles.includes(user.role)) {
    throw createError({ statusCode: 403, statusMessage: 'Forbidden' })
  }
  return user
}
