export async function createNotification(data: {
  userId: string
  type: 'PAYMENT_CONFIRMED' | 'PAYMENT_REJECTED' | 'DISCUSSION_REPLY' | 'COURSE_PUBLISHED'
  title: string
  message: string
  link?: string
}) {
  return prisma.notification.create({ data })
}
