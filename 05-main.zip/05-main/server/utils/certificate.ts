import { randomBytes } from 'crypto'

export function generateCertificateCode(): string {
  return randomBytes(4).toString('hex').toUpperCase()
}

export async function checkAndIssueCertificate(userId: string, courseId: string) {
  // Check if certificate already exists
  const existing = await prisma.certificate.findUnique({
    where: { userId_courseId: { userId, courseId } },
  })
  if (existing) return existing

  // Get all lessons in the course
  const course = await prisma.course.findUnique({
    where: { id: courseId },
    select: {
      title: true,
      chapters: {
        select: {
          lessons: {
            select: {
              id: true,
              quiz: { select: { id: true, passingScore: true } },
            },
          },
        },
      },
    },
  })
  if (!course) return null

  const allLessons = course.chapters.flatMap(c => c.lessons)
  if (allLessons.length === 0) return null

  // Check all lessons completed
  const completedCount = await prisma.lessonProgress.count({
    where: {
      userId,
      lessonId: { in: allLessons.map(l => l.id) },
      completed: true,
    },
  })
  if (completedCount < allLessons.length) return null

  // Check all quizzes passed
  const lessonsWithQuiz = allLessons.filter(l => l.quiz)
  for (const lesson of lessonsWithQuiz) {
    const passed = await prisma.quizAttempt.findFirst({
      where: { userId, quizId: lesson.quiz!.id, passed: true },
    })
    if (!passed) return null
  }

  // Issue certificate
  let code = generateCertificateCode()
  // Ensure unique code
  while (await prisma.certificate.findUnique({ where: { code } })) {
    code = generateCertificateCode()
  }

  const certificate = await prisma.certificate.create({
    data: { userId, courseId, code },
  })

  // Notify user
  await createNotification({
    userId,
    type: 'COURSE_PUBLISHED',
    title: 'Certificate Earned!',
    message: `Congratulations! You earned a certificate for completing "${course.title}".`,
    link: `/certificates/${code}`,
  }).catch(() => {})

  return certificate
}
