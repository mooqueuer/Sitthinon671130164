export const BADGE_DEFINITIONS: Record<string, { name: string; description: string; icon: string }> = {
  first_lesson: {
    name: 'First Steps',
    description: 'Complete your first lesson',
    icon: 'footprints',
  },
  five_lessons: {
    name: 'Quick Learner',
    description: 'Complete 5 lessons',
    icon: 'book-open',
  },
  twenty_lessons: {
    name: 'Knowledge Seeker',
    description: 'Complete 20 lessons',
    icon: 'graduation-cap',
  },
  first_quiz: {
    name: 'Quiz Taker',
    description: 'Pass your first quiz',
    icon: 'check-circle',
  },
  five_quizzes: {
    name: 'Quiz Master',
    description: 'Pass 5 quizzes',
    icon: 'trophy',
  },
  first_certificate: {
    name: 'Certified',
    description: 'Earn your first certificate',
    icon: 'award',
  },
  three_certificates: {
    name: 'Scholar',
    description: 'Earn 3 certificates',
    icon: 'medal',
  },
  streak_7: {
    name: 'Week Warrior',
    description: 'Maintain a 7-day streak',
    icon: 'flame',
  },
  streak_30: {
    name: 'Dedicated Learner',
    description: 'Maintain a 30-day streak',
    icon: 'zap',
  },
}
