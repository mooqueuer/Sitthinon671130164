export async function awardXP(userId: string, amount: number, reason: string, ids?: { courseId?: string; lessonId?: string; quizId?: string }) {
  await prisma.userXP.create({
    data: {
      userId,
      amount,
      reason,
      courseId: ids?.courseId,
      lessonId: ids?.lessonId,
      quizId: ids?.quizId,
    },
  })
}

export async function updateStreak(userId: string) {
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  const streak = await prisma.userStreak.findUnique({ where: { userId } })

  if (!streak) {
    await prisma.userStreak.create({
      data: { userId, currentStreak: 1, longestStreak: 1, lastActiveDate: today },
    })
    return
  }

  const lastActive = new Date(streak.lastActiveDate)
  lastActive.setHours(0, 0, 0, 0)

  const diffDays = Math.floor((today.getTime() - lastActive.getTime()) / (1000 * 60 * 60 * 24))

  if (diffDays === 0) return // Already active today
  if (diffDays === 1) {
    const newStreak = streak.currentStreak + 1
    await prisma.userStreak.update({
      where: { userId },
      data: {
        currentStreak: newStreak,
        longestStreak: Math.max(newStreak, streak.longestStreak),
        lastActiveDate: today,
      },
    })
  } else {
    await prisma.userStreak.update({
      where: { userId },
      data: { currentStreak: 1, lastActiveDate: today },
    })
  }
}

export async function checkBadges(userId: string) {
  const earnedBadges = await prisma.userBadge.findMany({
    where: { userId },
    select: { badge: true },
  })
  const earned = new Set(earnedBadges.map(b => b.badge))
  const newBadges: string[] = []

  // Lesson completion badges
  const lessonCount = await prisma.lessonProgress.count({ where: { userId, completed: true } })
  if (lessonCount >= 1 && !earned.has('first_lesson')) newBadges.push('first_lesson')
  if (lessonCount >= 5 && !earned.has('five_lessons')) newBadges.push('five_lessons')
  if (lessonCount >= 20 && !earned.has('twenty_lessons')) newBadges.push('twenty_lessons')

  // Quiz badges
  const quizCount = await prisma.quizAttempt.count({ where: { userId, passed: true } })
  if (quizCount >= 1 && !earned.has('first_quiz')) newBadges.push('first_quiz')
  if (quizCount >= 5 && !earned.has('five_quizzes')) newBadges.push('five_quizzes')

  // Certificate badges
  const certCount = await prisma.certificate.count({ where: { userId } })
  if (certCount >= 1 && !earned.has('first_certificate')) newBadges.push('first_certificate')
  if (certCount >= 3 && !earned.has('three_certificates')) newBadges.push('three_certificates')

  // Streak badges
  const streak = await prisma.userStreak.findUnique({ where: { userId } })
  if (streak) {
    if (streak.longestStreak >= 7 && !earned.has('streak_7')) newBadges.push('streak_7')
    if (streak.longestStreak >= 30 && !earned.has('streak_30')) newBadges.push('streak_30')
  }

  // Award new badges
  for (const badge of newBadges) {
    await prisma.userBadge.create({ data: { userId, badge } }).catch(() => {})
  }

  return newBadges
}
