import tailwindcss from '@tailwindcss/vite'

// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  compatibilityDate: '2025-07-15',
  devtools: { enabled: true },

  app: {
    head: {
      title: 'Panit',
      titleTemplate: '%s | Panit',
      meta: [
        { charset: 'utf-8' },
        { name: 'viewport', content: 'width=device-width, initial-scale=1' },
        { name: 'description', content: 'Panit - Secure Authentication System' },
      ],
      htmlAttrs: { lang: 'th' },
    },
    pageTransition: { name: 'page', mode: 'out-in' },
  },

  modules: [
    'shadcn-nuxt',
    'nuxt-auth-utils',
    'nuxt-security',
  ],

  css: ['@/assets/css/tailwind.css'],

  vite: {
    plugins: [
      tailwindcss(),
    ],
  },

  shadcn: {
    prefix: '',
    componentDir: './app/components/ui',
  },

  security: {
    headers: {
      contentSecurityPolicy: {
        'default-src': ["'self'"],
        'script-src': ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
        'style-src': ["'self'", "'unsafe-inline'"],
        'img-src': ["'self'", 'data:', 'https:'],
        'font-src': ["'self'"],
        'connect-src': ["'self'"],
        'frame-src': ["'self'", 'https://www.youtube.com', 'https://player.vimeo.com'],
        'media-src': ["'self'", 'https:'],
      },
      xFrameOptions: 'DENY',
      xContentTypeOptions: 'nosniff',
      referrerPolicy: 'strict-origin-when-cross-origin',
    },
    rateLimiter: {
      tokensPerInterval: 100,
      interval: 60000,
    },
    csrf: true,
  },
})
