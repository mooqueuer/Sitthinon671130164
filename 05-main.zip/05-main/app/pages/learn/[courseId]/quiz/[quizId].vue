<script setup lang="ts">
import { toast } from 'vue-sonner'

definePageMeta({ layout: 'learn', middleware: 'auth' })

const route = useRoute()
const { csrf, headerName } = useCsrf()
const courseId = route.params.courseId as string
const quizId = route.params.quizId as string

// Fetch quiz directly by ID
const { data: quiz, status: fetchStatus } = await useFetch(`/api/quizzes/by-id/${quizId}`)

// Fetch course for navigation
const { data: course } = await useFetch(`/api/courses/${courseId}`)
const allLessons = computed(() =>
  (course.value?.chapters || []).flatMap((c: any) => c.lessons)
)

// Find the lesson that owns this quiz for back-navigation
const quizLessonId = computed(() => quiz.value?.lessonId)

const { data: pastResults } = await useFetch(`/api/quizzes/${quizId}/results`)

useHead({ title: computed(() => quiz.value?.title || 'Quiz') })

const answers = ref<Record<string, string>>({})
const submitting = ref(false)
const result = ref<any>(null)

async function submitQuiz() {
  if (!quiz.value) return
  submitting.value = true
  try {
    const answerData = Object.entries(answers.value).map(([questionId, selectedOptionId]) => ({
      questionId,
      selectedOptionId,
    }))
    result.value = await $fetch(`/api/quizzes/${quizId}/attempt`, {
      method: 'POST',
      body: { answers: answerData },
      headers: { [headerName]: csrf },
    })
    if (result.value.passed) {
      toast.success('Quiz passed!', { description: `Score: ${result.value.score}%` })
    } else {
      toast.error('Quiz not passed', { description: `Score: ${result.value.score}%. Try again!` })
    }
  } catch (e: any) {
    toast.error('Failed to submit quiz', { description: e.data?.statusMessage })
  } finally {
    submitting.value = false
  }
}

const backLessonId = computed(() => quizLessonId.value || allLessons.value[0]?.id || '')
</script>

<template>
  <div class="max-w-3xl space-y-6">
    <!-- Loading -->
    <div v-if="fetchStatus === 'pending'" class="py-12 text-center text-muted-foreground">
      Loading quiz...
    </div>

    <!-- Quiz not found -->
    <div v-else-if="!quiz" class="py-12 text-center">
      <p class="text-muted-foreground mb-4">Quiz not found.</p>
      <Button as-child variant="outline">
        <NuxtLink :to="`/learn/${courseId}/${allLessons[0]?.id || ''}`">Back to Lessons</NuxtLink>
      </Button>
    </div>

    <!-- Result -->
    <div v-else-if="result" class="space-y-6">
      <Card>
        <CardHeader class="text-center">
          <CardTitle class="text-2xl">
            {{ result.passed ? 'Congratulations!' : 'Try Again' }}
          </CardTitle>
          <CardDescription>
            You scored {{ result.score }}% ({{ result.correctCount }}/{{ result.totalQuestions }} correct)
          </CardDescription>
        </CardHeader>
        <CardContent class="flex justify-center">
          <Badge :variant="result.passed ? 'default' : 'destructive'" class="text-lg px-4 py-1">
            {{ result.passed ? 'PASSED' : 'FAILED' }}
          </Badge>
        </CardContent>
        <CardFooter class="justify-center gap-3">
          <Button variant="outline" @click="result = null; answers = {}">Retake Quiz</Button>
          <Button as-child>
            <NuxtLink :to="`/learn/${courseId}/${backLessonId}`">Back to Lesson</NuxtLink>
          </Button>
        </CardFooter>
      </Card>

      <!-- Past attempts -->
      <Card v-if="pastResults?.length">
        <CardHeader>
          <CardTitle class="text-base">Previous Attempts</CardTitle>
        </CardHeader>
        <CardContent>
          <div class="space-y-2">
            <div v-for="attempt in pastResults" :key="attempt.id" class="flex items-center justify-between text-sm">
              <span>{{ new Date(attempt.startedAt).toLocaleString() }}</span>
              <Badge :variant="attempt.passed ? 'default' : 'secondary'">{{ attempt.score }}%</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>

    <!-- Quiz Form -->
    <div v-else class="space-y-6">
      <div>
        <h1 class="text-2xl font-bold">{{ quiz.title }}</h1>
        <p class="text-muted-foreground">
          {{ quiz.questions.length }} questions
          <span v-if="quiz.passingScore"> &middot; {{ quiz.passingScore }}% to pass</span>
          <span v-if="quiz.timeLimit"> &middot; {{ quiz.timeLimit }} min</span>
        </p>
      </div>

      <form @submit.prevent="submitQuiz" class="space-y-6">
        <Card v-for="(question, qi) in quiz.questions" :key="question.id">
          <CardHeader>
            <CardTitle class="text-base">
              {{ qi + 1 }}. {{ question.text }}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div class="space-y-2">
              <label
                v-for="option in question.options"
                :key="option.id"
                class="flex items-center gap-3 rounded-md border p-3 cursor-pointer transition-colors hover:bg-accent"
                :class="answers[question.id] === option.id ? 'border-primary bg-accent' : ''"
              >
                <input
                  type="radio"
                  :name="`q-${question.id}`"
                  :value="option.id"
                  v-model="answers[question.id]"
                  class="h-4 w-4"
                />
                <span class="text-sm">{{ option.text }}</span>
              </label>
            </div>
          </CardContent>
        </Card>

        <Button
          type="submit"
          class="w-full"
          :disabled="submitting || Object.keys(answers).length < quiz.questions.length"
        >
          {{ submitting ? 'Submitting...' : 'Submit Quiz' }}
        </Button>
      </form>
    </div>
  </div>
</template>
