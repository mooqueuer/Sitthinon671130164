<script setup lang="ts">
import { toast } from 'vue-sonner'

definePageMeta({ layout: 'learn', middleware: 'auth' })

const route = useRoute()
const { csrf, headerName } = useCsrf()
const courseId = route.params.courseId as string
const lessonId = route.params.lessonId as string

const { data: lesson } = await useFetch(`/api/courses/${courseId}/lessons/${lessonId}`)

useHead({ title: lesson.value?.title || 'Lesson' })

const completing = ref(false)
const completed = ref(false)

// Check bookmark status (lightweight)
const { data: bookmarkCheck } = await useFetch('/api/bookmarks/check', {
  query: { lessonId },
  default: () => ({ bookmarked: false }),
})
const isBookmarked = computed(() => bookmarkCheck.value?.bookmarked || false)

// Check if already completed
const { data: progress } = await useFetch(`/api/enrollments/${courseId}/progress`, {
  default: () => ({ lessons: [] }),
  onResponseError() {},
})
completed.value = progress.value?.lessons?.some((l: any) => l.lessonId === lessonId && l.completed) || false

async function markComplete() {
  completing.value = true
  try {
    await $fetch(`/api/courses/${courseId}/lessons/${lessonId}/complete`, {
      method: 'POST',
      headers: { [headerName]: csrf },
    })
    completed.value = true
    toast.success('Lesson completed!')
  } catch (e: any) {
    toast.error('Failed to mark as complete', { description: e.data?.statusMessage })
  } finally {
    completing.value = false
  }
}

// Navigation
const { data: course } = await useFetch(`/api/courses/${courseId}`)
const allLessons = computed(() =>
  (course.value?.chapters || []).flatMap((c: any) => c.lessons)
)
const currentIndex = computed(() => allLessons.value.findIndex((l: any) => l.id === lessonId))
const prevLesson = computed(() => allLessons.value[currentIndex.value - 1])
const nextLesson = computed(() => allLessons.value[currentIndex.value + 1])

// Discussion
const activeThread = ref('')
</script>

<template>
  <div v-if="lesson" class="max-w-4xl space-y-6">
    <div class="flex items-center justify-between">
      <div>
        <Badge variant="outline" class="mb-2">{{ lesson.type }}</Badge>
        <h1 class="text-2xl font-bold">{{ lesson.title }}</h1>
      </div>
      <div class="flex items-center gap-2">
        <BookmarkButton :lesson-id="lessonId" :initial-bookmarked="isBookmarked" />
        <Button
          v-if="!completed"
          variant="outline"
          :disabled="completing"
          @click="markComplete"
        >
          {{ completing ? 'Saving...' : 'Mark Complete' }}
        </Button>
        <Badge v-else variant="default">Completed</Badge>
      </div>
    </div>

    <!-- Video -->
    <div v-if="lesson.type === 'VIDEO' && lesson.videoUrl" class="aspect-video rounded-lg bg-black overflow-hidden">
      <iframe
        :src="lesson.videoUrl"
        class="h-full w-full"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowfullscreen
      />
    </div>

    <!-- Text content -->
    <div v-if="lesson.content" class="prose prose-zinc max-w-none">
      <div v-html="lesson.content" />
    </div>

    <!-- File download -->
    <Card v-if="lesson.type === 'FILE' && lesson.fileUrl">
      <CardContent class="flex items-center justify-between py-4">
        <span class="text-sm">Attached file</span>
        <Button as-child variant="outline" size="sm">
          <a :href="lesson.fileUrl" target="_blank">Download</a>
        </Button>
      </CardContent>
    </Card>

    <!-- Quiz link -->
    <Card v-if="lesson.quiz">
      <CardContent class="flex items-center justify-between py-4">
        <div>
          <p class="font-medium">{{ lesson.quiz.title }}</p>
          <p class="text-sm text-muted-foreground">Test your knowledge</p>
        </div>
        <Button as-child size="sm">
          <NuxtLink :to="`/learn/${courseId}/quiz/${lesson.quiz.id}`">Take Quiz</NuxtLink>
        </Button>
      </CardContent>
    </Card>

    <!-- Notes & Discussion Tabs -->
    <Tabs default-value="notes">
      <TabsList>
        <TabsTrigger value="notes">Notes</TabsTrigger>
        <TabsTrigger value="discussion">Discussion</TabsTrigger>
      </TabsList>
      <TabsContent value="notes" class="mt-4">
        <LessonNotes :lesson-id="lessonId" />
      </TabsContent>
      <TabsContent value="discussion" class="mt-4">
        <DiscussionThread
          v-if="activeThread"
          :thread-id="activeThread"
          @back="activeThread = ''"
        />
        <DiscussionPanel
          v-else
          :lesson-id="lessonId"
          @open-thread="activeThread = $event"
        />
      </TabsContent>
    </Tabs>

    <Separator />

    <!-- Navigation -->
    <div class="flex justify-between">
      <Button v-if="prevLesson" variant="outline" as-child>
        <NuxtLink :to="`/learn/${courseId}/${prevLesson.id}`">&larr; Previous</NuxtLink>
      </Button>
      <div v-else />
      <Button v-if="nextLesson" as-child>
        <NuxtLink :to="`/learn/${courseId}/${nextLesson.id}`">Next &rarr;</NuxtLink>
      </Button>
    </div>
  </div>
</template>
