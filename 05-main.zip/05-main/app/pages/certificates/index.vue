<script setup lang="ts">
import { Award } from 'lucide-vue-next'

definePageMeta({ middleware: 'auth' })
useHead({ title: 'My Certificates' })

const { data: certificates } = await useFetch('/api/certificates')
</script>

<template>
  <div class="space-y-6">
    <div>
      <h1 class="text-2xl font-bold tracking-tight">My Certificates</h1>
      <p class="text-muted-foreground">Certificates earned from completed courses</p>
    </div>

    <div v-if="certificates?.length" class="space-y-3">
      <CertificateCard v-for="cert in certificates" :key="cert.id" :certificate="cert" />
    </div>

    <div v-else class="py-16 text-center">
      <Award class="mx-auto h-10 w-10 text-muted-foreground/30 mb-4" />
      <p class="text-lg font-medium mb-1">No certificates yet</p>
      <p class="text-muted-foreground">Complete all lessons and quizzes in a course to earn a certificate.</p>
    </div>
  </div>
</template>
