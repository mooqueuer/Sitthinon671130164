<script setup lang="ts">
import { Award, CheckCircle } from 'lucide-vue-next'

const route = useRoute()
const { data: certificate } = await useFetch(`/api/certificates/${route.params.code}`)

useHead({ title: certificate.value ? `Certificate - ${certificate.value.course.title}` : 'Certificate' })
</script>

<template>
  <div v-if="certificate" class="mx-auto max-w-2xl space-y-8 py-8">
    <div class="flex items-center justify-center gap-2 text-green-600">
      <CheckCircle class="h-5 w-5" />
      <span class="text-sm font-medium">Verified Certificate</span>
    </div>

    <Card class="border-2 print:border-black">
      <CardContent class="py-12 text-center space-y-6">
        <Award class="mx-auto h-16 w-16 text-primary" />

        <div>
          <p class="text-sm text-muted-foreground uppercase tracking-wider">Certificate of Completion</p>
          <h1 class="mt-2 text-3xl font-bold">{{ certificate.course.title }}</h1>
        </div>

        <div>
          <p class="text-muted-foreground">Awarded to</p>
          <p class="text-xl font-semibold">{{ certificate.user.name || certificate.user.email }}</p>
        </div>

        <div class="text-sm text-muted-foreground space-y-1">
          <p>Instructor: {{ certificate.course.teacher.name || 'Instructor' }}</p>
          <p>Date: {{ new Date(certificate.issuedAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }) }}</p>
          <p>Certificate ID: {{ certificate.code }}</p>
        </div>

        <Separator />

        <p class="text-xs text-muted-foreground">
          Panit E-Learning Platform
        </p>
      </CardContent>
    </Card>

    <div class="flex justify-center print:hidden">
      <Button variant="outline" @click="globalThis.window?.print()">Print Certificate</Button>
    </div>
  </div>

  <div v-else class="py-16 text-center">
    <p class="text-lg font-medium mb-1">Certificate not found</p>
    <p class="text-muted-foreground">This certificate code is invalid or does not exist.</p>
  </div>
</template>
