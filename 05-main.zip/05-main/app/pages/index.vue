<script setup lang="ts">
import { Star } from 'lucide-vue-next'

useHead({ title: 'E-Learning Platform' })

const { user } = useUserSession()
const { data } = await useFetch('/api/courses', { query: { limit: 6 } })
</script>

<template>
  <div class="space-y-16">
    <!-- Hero -->
    <section class="text-center space-y-6 py-12">
      <h1 class="text-4xl font-bold tracking-tight sm:text-5xl">
        Learn at your own pace
      </h1>
      <p class="mx-auto max-w-2xl text-lg text-muted-foreground">
        Discover courses taught by expert instructors. Video lessons, interactive quizzes, and progress tracking to help you succeed.
      </p>
      <div class="flex items-center justify-center gap-3">
        <Button as-child size="lg">
          <NuxtLink to="/courses">Browse Courses</NuxtLink>
        </Button>
        <Button v-if="!user" variant="outline" as-child size="lg">
          <NuxtLink to="/register">Get Started Free</NuxtLink>
        </Button>
      </div>
    </section>

    <!-- Featured Courses -->
    <section v-if="data?.courses?.length" class="space-y-6">
      <div class="flex items-center justify-between">
        <h2 class="text-2xl font-bold tracking-tight">Featured Courses</h2>
        <Button variant="ghost" as-child>
          <NuxtLink to="/courses">View all &rarr;</NuxtLink>
        </Button>
      </div>
      <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <Card v-for="course in data.courses" :key="course.id" class="overflow-hidden">
          <div class="aspect-video bg-muted" />
          <CardHeader>
            <div class="flex items-center justify-between">
              <Badge variant="secondary">{{ course._count.chapters }} chapters</Badge>
              <span class="text-sm font-semibold">
                {{ course.price > 0 ? `฿${course.price.toLocaleString()}` : 'Free' }}
              </span>
            </div>
            <CardTitle class="line-clamp-1">
              <NuxtLink :to="`/courses/${course.id}`" class="hover:underline">
                {{ course.title }}
              </NuxtLink>
            </CardTitle>
            <CardDescription class="line-clamp-2">{{ course.description }}</CardDescription>
          </CardHeader>
          <CardContent>
            <div class="flex items-center justify-between text-sm text-muted-foreground">
              <span>by {{ course.teacher.name || 'Instructor' }}</span>
              <div class="flex items-center gap-2">
                <span v-if="course.avgRating > 0" class="flex items-center gap-1">
                  <Star class="h-3.5 w-3.5 fill-yellow-400 text-yellow-400" />
                  {{ course.avgRating }}
                </span>
                <span>{{ course._count.enrollments }} students</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>

    <!-- Stats -->
    <section class="grid gap-6 sm:grid-cols-3 text-center py-8">
      <div>
        <p class="text-3xl font-bold">100%</p>
        <p class="text-sm text-muted-foreground">Self-paced learning</p>
      </div>
      <div>
        <p class="text-3xl font-bold">Video + Text</p>
        <p class="text-sm text-muted-foreground">Multiple lesson formats</p>
      </div>
      <div>
        <p class="text-3xl font-bold">Quizzes</p>
        <p class="text-sm text-muted-foreground">Test your knowledge</p>
      </div>
    </section>
  </div>
</template>
