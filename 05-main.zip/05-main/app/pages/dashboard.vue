<script setup lang="ts">
definePageMeta({ middleware: 'auth' })
useHead({ title: 'Dashboard' })

const { user } = useUserSession()
const role = computed(() => (user.value as any)?.role)

const { data: certificates } = await useFetch('/api/certificates', { default: () => [] })
const { data: gamification } = await useFetch('/api/gamification/profile', {
  default: () => ({ totalXP: 0, streak: { currentStreak: 0, longestStreak: 0 }, badges: [], badgeCount: 0 }),
})
const { data: allBadges } = await useFetch('/api/gamification/badges', { default: () => [] })
</script>

<template>
  <div class="space-y-6">
    <div>
      <h1 class="text-2xl font-bold tracking-tight">Dashboard</h1>
      <p class="text-muted-foreground">Welcome back, {{ user?.name || user?.email }}</p>
    </div>

    <Separator />

    <div class="grid gap-4 sm:grid-cols-3">
      <Card>
        <CardHeader class="pb-2">
          <CardDescription>Email</CardDescription>
          <CardTitle class="text-base">{{ user?.email }}</CardTitle>
        </CardHeader>
      </Card>
      <Card>
        <CardHeader class="pb-2">
          <CardDescription>Name</CardDescription>
          <CardTitle class="text-base">{{ user?.name || 'Not set' }}</CardTitle>
        </CardHeader>
      </Card>
      <Card>
        <CardHeader class="pb-2">
          <CardDescription>Role</CardDescription>
          <CardTitle class="text-base">
            <Badge :variant="role === 'ADMIN' ? 'destructive' : role === 'TEACHER' ? 'default' : 'secondary'">
              {{ role }}
            </Badge>
          </CardTitle>
        </CardHeader>
      </Card>
    </div>

    <div class="grid gap-4 sm:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle class="text-sm font-medium">My Courses</CardTitle>
        </CardHeader>
        <CardContent>
          <p class="text-sm text-muted-foreground">View your enrolled courses and track your progress.</p>
          <Button as-child class="mt-4" size="sm">
            <NuxtLink to="/my-courses">Go to My Courses</NuxtLink>
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle class="text-sm font-medium">Browse Courses</CardTitle>
        </CardHeader>
        <CardContent>
          <p class="text-sm text-muted-foreground">Discover new courses and start learning.</p>
          <Button as-child class="mt-4" size="sm" variant="outline">
            <NuxtLink to="/courses">Browse Catalog</NuxtLink>
          </Button>
        </CardContent>
      </Card>

      <Card v-if="role === 'TEACHER' || role === 'ADMIN'">
        <CardHeader>
          <CardTitle class="text-sm font-medium">Teacher Panel</CardTitle>
        </CardHeader>
        <CardContent>
          <p class="text-sm text-muted-foreground">Create and manage your courses.</p>
          <Button as-child class="mt-4" size="sm">
            <NuxtLink to="/teacher">Go to Teacher Panel</NuxtLink>
          </Button>
        </CardContent>
      </Card>

      <Card v-if="role === 'ADMIN'">
        <CardHeader>
          <CardTitle class="text-sm font-medium">Admin Panel</CardTitle>
        </CardHeader>
        <CardContent>
          <p class="text-sm text-muted-foreground">Manage users, courses, and payments.</p>
          <Button as-child class="mt-4" size="sm">
            <NuxtLink to="/admin">Go to Admin Panel</NuxtLink>
          </Button>
        </CardContent>
      </Card>
    </div>

    <!-- Gamification -->
    <Separator />
    <div class="space-y-4">
      <h2 class="text-lg font-semibold">Progress</h2>
      <div class="grid gap-4 sm:grid-cols-3">
        <Card>
          <CardHeader class="pb-2">
            <CardDescription>Total XP</CardDescription>
          </CardHeader>
          <CardContent>
            <XPBadge :xp="gamification.totalXP" />
          </CardContent>
        </Card>
        <Card>
          <CardHeader class="pb-2">
            <CardDescription>Streak</CardDescription>
          </CardHeader>
          <CardContent>
            <StreakDisplay :current="gamification.streak.currentStreak" :longest="gamification.streak.longestStreak" />
          </CardContent>
        </Card>
        <Card>
          <CardHeader class="pb-2">
            <CardDescription>Badges</CardDescription>
          </CardHeader>
          <CardContent>
            <p class="text-sm font-semibold">{{ gamification.badgeCount }} earned</p>
          </CardContent>
        </Card>
      </div>
      <BadgeGrid v-if="allBadges?.length" :badges="allBadges" />
    </div>

    <!-- Certificates -->
    <div v-if="certificates?.length" class="space-y-3">
      <div class="flex items-center justify-between">
        <h2 class="text-lg font-semibold">My Certificates</h2>
        <Button variant="ghost" size="sm" as-child>
          <NuxtLink to="/certificates">View all</NuxtLink>
        </Button>
      </div>
      <CertificateCard v-for="cert in certificates.slice(0, 3)" :key="cert.id" :certificate="cert" />
    </div>
  </div>
</template>
