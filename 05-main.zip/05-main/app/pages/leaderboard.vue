<script setup lang="ts">
import { Trophy, Zap } from 'lucide-vue-next'

useHead({ title: 'Leaderboard' })

const { data: leaderboard } = await useFetch('/api/gamification/leaderboard', { default: () => [] })
</script>

<template>
  <div class="space-y-6">
    <div>
      <h1 class="text-2xl font-bold tracking-tight">Leaderboard</h1>
      <p class="text-muted-foreground">Top learners ranked by XP</p>
    </div>

    <Card v-if="leaderboard?.length">
      <CardContent class="p-0">
        <div class="divide-y">
          <div
            v-for="entry in leaderboard"
            :key="entry.user.id"
            class="flex items-center gap-4 px-6 py-3"
          >
            <div
              class="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-sm font-bold"
              :class="entry.rank <= 3 ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'"
            >
              <Trophy v-if="entry.rank === 1" class="h-4 w-4" />
              <span v-else>{{ entry.rank }}</span>
            </div>
            <Avatar class="h-8 w-8">
              <AvatarFallback class="text-xs">
                {{ (entry.user.name || '?')[0].toUpperCase() }}
              </AvatarFallback>
            </Avatar>
            <div class="flex-1">
              <p class="font-medium text-sm">{{ entry.user.name || 'User' }}</p>
            </div>
            <div class="flex items-center gap-1 text-sm font-semibold">
              <Zap class="h-4 w-4 text-primary" />
              {{ entry.totalXP.toLocaleString() }} XP
            </div>
          </div>
        </div>
      </CardContent>
    </Card>

    <div v-else class="py-16 text-center">
      <Trophy class="mx-auto h-10 w-10 text-muted-foreground/30 mb-4" />
      <p class="text-lg font-medium mb-1">No entries yet</p>
      <p class="text-muted-foreground">Complete lessons and quizzes to earn XP and appear here!</p>
    </div>
  </div>
</template>
