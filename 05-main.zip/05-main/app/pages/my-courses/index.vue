<script setup lang="ts">
definePageMeta({ middleware: 'auth' })
useHead({ title: 'My Courses' })

const { data: enrollments, status } = await useFetch('/api/enrollments')
</script>

<template>
  <div class="space-y-6">
    <div>
      <h1 class="text-2xl font-bold tracking-tight">My Courses</h1>
      <p class="text-muted-foreground">Continue learning where you left off</p>
    </div>

    <!-- Loading skeleton -->
    <div v-if="status === 'pending'" class="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      <Card v-for="i in 3" :key="i" class="overflow-hidden">
        <div class="aspect-video bg-muted animate-pulse" />
        <CardHeader>
          <div class="h-5 w-3/4 animate-pulse rounded bg-muted" />
          <div class="h-4 w-1/2 animate-pulse rounded bg-muted mt-1" />
        </CardHeader>
        <CardContent class="space-y-3">
          <div class="h-2 w-full animate-pulse rounded bg-muted" />
          <div class="h-9 w-full animate-pulse rounded bg-muted" />
        </CardContent>
      </Card>
    </div>

    <div v-else-if="enrollments?.length" class="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      <Card v-for="item in enrollments" :key="item.id" class="overflow-hidden">
        <div class="aspect-video bg-muted" />
        <CardHeader>
          <CardTitle class="line-clamp-1">{{ item.course.title }}</CardTitle>
          <CardDescription>by {{ item.course.teacherName || 'Instructor' }}</CardDescription>
        </CardHeader>
        <CardContent class="space-y-3">
          <div class="space-y-1">
            <div class="flex justify-between text-sm">
              <span class="text-muted-foreground">Progress</span>
              <span class="font-medium">{{ item.progress }}%</span>
            </div>
            <Progress :model-value="item.progress" class="h-2" />
            <p class="text-xs text-muted-foreground">
              {{ item.completedLessons }}/{{ item.totalLessons }} lessons
            </p>
          </div>
          <Button as-child class="w-full" size="sm">
            <NuxtLink :to="`/courses/${item.course.id}`">
              {{ item.progress > 0 ? 'Continue' : 'Start Learning' }}
            </NuxtLink>
          </Button>
        </CardContent>
      </Card>
    </div>

    <div v-else class="py-16 text-center">
      <p class="text-muted-foreground mb-4">You haven't enrolled in any courses yet.</p>
      <Button as-child>
        <NuxtLink to="/courses">Browse Courses</NuxtLink>
      </Button>
    </div>
  </div>
</template>
