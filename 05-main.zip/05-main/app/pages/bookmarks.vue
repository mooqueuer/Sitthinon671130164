<script setup lang="ts">
import { Bookmark } from 'lucide-vue-next'

definePageMeta({ middleware: 'auth' })
useHead({ title: 'My Bookmarks' })

const { data: bookmarks } = await useFetch('/api/bookmarks')
</script>

<template>
  <div class="space-y-6">
    <div>
      <h1 class="text-2xl font-bold tracking-tight">My Bookmarks</h1>
      <p class="text-muted-foreground">Lessons you've saved for later</p>
    </div>

    <div v-if="bookmarks?.length" class="space-y-3">
      <Card v-for="bm in bookmarks" :key="bm.id">
        <CardContent class="flex items-center justify-between py-4">
          <div class="flex items-center gap-3">
            <Bookmark class="h-4 w-4 fill-current text-muted-foreground" />
            <div>
              <NuxtLink
                :to="`/learn/${bm.lesson.chapter.course.id}/${bm.lesson.id}`"
                class="font-medium hover:underline"
              >
                {{ bm.lesson.title }}
              </NuxtLink>
              <p class="text-sm text-muted-foreground">{{ bm.lesson.chapter.course.title }}</p>
            </div>
          </div>
          <Badge variant="outline" class="text-xs">{{ bm.lesson.type }}</Badge>
        </CardContent>
      </Card>
    </div>

    <div v-else class="py-16 text-center">
      <Bookmark class="mx-auto h-10 w-10 text-muted-foreground/30 mb-4" />
      <p class="text-lg font-medium mb-1">No bookmarks yet</p>
      <p class="text-muted-foreground">Bookmark lessons while learning to find them here.</p>
    </div>
  </div>
</template>
