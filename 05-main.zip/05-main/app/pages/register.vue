<script setup lang="ts">
definePageMeta({
  layout: 'auth',
  middleware: 'guest',
})

useHead({ title: 'Create account' })

const { fetch: refreshSession } = useUserSession()
const { csrf, headerName } = useCsrf()

const nameRef = ref()
const name = ref('')
const email = ref('')
const password = ref('')
const showPassword = ref(false)
const error = ref('')
const loading = ref(false)

onMounted(() => nameRef.value?.$el?.focus())

const passwordStrength = computed(() => {
  const len = password.value.length
  if (len === 0) return { level: 0, label: '', color: '' }
  if (len < 8) return { level: 1, label: 'Too short', color: 'bg-red-500' }
  const hasUpper = /[A-Z]/.test(password.value)
  const hasLower = /[a-z]/.test(password.value)
  const hasNumber = /[0-9]/.test(password.value)
  const hasSpecial = /[^A-Za-z0-9]/.test(password.value)
  const score = [hasUpper, hasLower, hasNumber, hasSpecial].filter(Boolean).length
  if (score <= 1) return { level: 2, label: 'Weak', color: 'bg-orange-500' }
  if (score <= 2) return { level: 3, label: 'Fair', color: 'bg-yellow-500' }
  if (score <= 3) return { level: 4, label: 'Strong', color: 'bg-green-500' }
  return { level: 5, label: 'Very strong', color: 'bg-green-600' }
})

async function handleRegister() {
  error.value = ''
  loading.value = true

  try {
    await $fetch('/api/auth/register', {
      method: 'POST',
      body: {
        name: name.value || undefined,
        email: email.value,
        password: password.value,
      },
      headers: { [headerName]: csrf },
    })
    refreshSession()
    await navigateTo('/', { replace: true })
  } catch (e: any) {
    error.value = e.data?.message || e.data?.statusMessage || 'Registration failed'
    loading.value = false
  }
}
</script>

<template>
  <div class="space-y-8">
    <div class="space-y-2">
      <h1 class="text-3xl font-bold tracking-tight">Get started</h1>
      <p class="text-muted-foreground">Create your account to continue</p>
    </div>

    <form @submit.prevent="handleRegister" class="space-y-5">
      <Transition
        enter-active-class="transition-all duration-300 ease-out"
        enter-from-class="opacity-0 -translate-y-2"
        enter-to-class="opacity-100 translate-y-0"
        leave-active-class="transition-all duration-200 ease-in"
        leave-from-class="opacity-100 translate-y-0"
        leave-to-class="opacity-0 -translate-y-2"
      >
        <Alert v-if="error" variant="destructive" class="border-destructive/20 bg-destructive/5">
          <AlertDescription class="text-sm">{{ error }}</AlertDescription>
        </Alert>
      </Transition>

      <div class="space-y-2">
        <Label for="name" class="text-sm font-medium">Full name</Label>
        <Input
          id="name"
          ref="nameRef"
          v-model="name"
          type="text"
          placeholder="John Doe"
          autocomplete="name"
          class="h-11"
          :disabled="loading"
        />
      </div>

      <div class="space-y-2">
        <Label for="email" class="text-sm font-medium">Email address</Label>
        <Input
          id="email"
          v-model="email"
          type="email"
          placeholder="name@example.com"
          required
          autocomplete="email"
          class="h-11"
          :disabled="loading"
        />
      </div>

      <div class="space-y-3">
        <Label for="password" class="text-sm font-medium">Password</Label>
        <div class="relative">
          <Input
            id="password"
            v-model="password"
            :type="showPassword ? 'text' : 'password'"
            placeholder="Create a strong password"
            required
            minlength="8"
            autocomplete="new-password"
            class="h-11 pr-11"
            :disabled="loading"
          />
          <button
            type="button"
            tabindex="-1"
            class="absolute right-0 top-0 flex h-11 w-11 items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
            @click="showPassword = !showPassword"
          >
            <svg v-if="!showPassword" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/></svg>
            <svg v-else xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49"/><path d="M14.084 14.158a3 3 0 0 1-4.242-4.242"/><path d="M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143"/><path d="m2 2 20 20"/></svg>
          </button>
        </div>
        <!-- Password strength indicator -->
        <div v-if="password.length > 0" class="space-y-2">
          <div class="flex gap-1">
            <div
              v-for="i in 5"
              :key="i"
              class="h-1 flex-1 rounded-full transition-all duration-300"
              :class="i <= passwordStrength.level ? passwordStrength.color : 'bg-muted'"
            />
          </div>
          <p class="text-xs text-muted-foreground">
            {{ passwordStrength.label }}
            <span v-if="passwordStrength.level < 3"> &mdash; use uppercase, numbers & symbols</span>
          </p>
        </div>
        <p v-else class="text-xs text-muted-foreground">Must be at least 8 characters</p>
      </div>

      <Button type="submit" class="h-11 w-full text-sm font-medium" :disabled="loading">
        <svg v-if="loading" class="mr-2 h-4 w-4 animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
        </svg>
        {{ loading ? 'Creating account...' : 'Create account' }}
      </Button>

      <p class="text-center text-xs leading-relaxed text-muted-foreground">
        By creating an account, you agree to our
        <span class="underline underline-offset-4">Terms of Service</span>
        and
        <span class="underline underline-offset-4">Privacy Policy</span>.
      </p>
    </form>

    <div class="relative">
      <Separator />
      <span class="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-background px-3 text-xs text-muted-foreground">
        or
      </span>
    </div>

    <p class="text-center text-sm text-muted-foreground">
      Already have an account?
      <NuxtLink to="/login" class="font-semibold text-foreground underline-offset-4 hover:underline">
        Sign in
      </NuxtLink>
    </p>
  </div>
</template>
