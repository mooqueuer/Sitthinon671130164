<script setup lang="ts">
import { toast } from 'vue-sonner'
import { Star } from 'lucide-vue-next'

const route = useRoute()
const { user } = useUserSession()
const { csrf, headerName } = useCsrf()

const { data: course } = await useFetch(`/api/courses/${route.params.id}`)

useHead({ title: course.value?.title || 'Course' })

const enrolling = ref(false)
const enrolled = ref(false)

// Check enrollment status efficiently
if (user.value && course.value) {
  const { data: check } = await useFetch(`/api/enrollments/check/${course.value.id}`)
  enrolled.value = check.value?.enrolled || false
}

const totalLessons = computed(() =>
  (course.value?.chapters || []).reduce((sum: number, c: any) => sum + c.lessons.length, 0)
)

const { data: reviewData, refresh: refreshReviews } = await useFetch(
  () => `/api/courses/${course.value?.id}/reviews`,
  { default: () => ({ reviews: [], avgRating: 0, reviewCount: 0, total: 0, page: 1, totalPages: 1 }) }
)

async function enroll() {
  if (!user.value) return navigateTo('/login')
  enrolling.value = true
  try {
    await $fetch('/api/enrollments', {
      method: 'POST',
      body: { courseId: course.value!.id },
      headers: { [headerName]: csrf },
    })
    enrolled.value = true
    toast.success('Enrolled successfully!', { description: 'You can now start learning.' })
  } catch (e: any) {
    if (e.data?.statusCode === 402) {
      try {
        await $fetch('/api/payments', {
          method: 'POST',
          body: { courseId: course.value!.id, method: 'bank_transfer' },
          headers: { [headerName]: csrf },
        })
        toast.success('Payment submitted!', { description: 'Please wait for admin confirmation.' })
      } catch (payErr: any) {
        toast.error('Payment failed', { description: payErr.data?.statusMessage || 'Please try again.' })
      }
    } else {
      toast.error('Enrollment failed', { description: e.data?.statusMessage || 'Please try again.' })
    }
  } finally {
    enrolling.value = false
  }
}

function goToLearn() {
  const firstLesson = course.value?.chapters?.[0]?.lessons?.[0]
  if (firstLesson) {
    navigateTo(`/learn/${course.value!.id}/${firstLesson.id}`)
  }
}
</script>

<template>
  <div v-if="course" class="space-y-8">
    <div class="grid gap-8 lg:grid-cols-3">
      <!-- Course Info -->
      <div class="lg:col-span-2 space-y-6">
        <div>
          <div class="flex items-center gap-2 mb-2">
            <Badge variant="secondary">{{ course.status }}</Badge>
            <Badge v-if="course.category" variant="outline">{{ course.category.name }}</Badge>
          </div>
          <h1 class="text-3xl font-bold tracking-tight">{{ course.title }}</h1>
          <p class="mt-2 text-muted-foreground">
            by {{ course.teacher.name || 'Instructor' }}
          </p>
        </div>

        <p v-if="course.description" class="text-muted-foreground leading-relaxed">
          {{ course.description }}
        </p>

        <Separator />

        <!-- Curriculum -->
        <div class="space-y-4">
          <h2 class="text-xl font-semibold">Curriculum</h2>
          <p class="text-sm text-muted-foreground">
            {{ course.chapters.length }} chapters &middot; {{ totalLessons }} lessons
          </p>

          <div class="space-y-3">
            <Card v-for="chapter in course.chapters" :key="chapter.id">
              <CardHeader class="py-3">
                <CardTitle class="text-base">{{ chapter.title }}</CardTitle>
                <CardDescription>{{ chapter.lessons.length }} lessons</CardDescription>
              </CardHeader>
              <CardContent class="pt-0">
                <div class="space-y-1">
                  <div
                    v-for="lesson in chapter.lessons"
                    :key="lesson.id"
                    class="flex items-center gap-2 rounded px-2 py-1.5 text-sm"
                  >
                    <Badge variant="outline" class="text-[10px]">{{ lesson.type }}</Badge>
                    <span>{{ lesson.title }}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <!-- Reviews Section -->
        <Separator />
        <div class="space-y-4">
          <div class="flex items-center justify-between">
            <h2 class="text-xl font-semibold">Reviews</h2>
            <div v-if="reviewData.reviewCount > 0" class="flex items-center gap-2">
              <Star class="h-5 w-5 fill-yellow-400 text-yellow-400" />
              <span class="font-semibold">{{ reviewData.avgRating }}</span>
              <span class="text-sm text-muted-foreground">({{ reviewData.reviewCount }} reviews)</span>
            </div>
          </div>

          <ReviewForm v-if="enrolled" :course-id="course.id" @submitted="refreshReviews()" />

          <div v-if="reviewData.reviews?.length" class="divide-y">
            <ReviewCard v-for="review in reviewData.reviews" :key="review.id" :review="review" />
          </div>
          <p v-else class="text-sm text-muted-foreground">No reviews yet.</p>
        </div>
      </div>

      <!-- Sidebar -->
      <div>
        <Card class="sticky top-20">
          <CardHeader>
            <div class="aspect-video rounded-md bg-muted mb-4" />
            <CardTitle class="text-2xl">
              {{ course.price > 0 ? `฿${course.price.toLocaleString()}` : 'Free' }}
            </CardTitle>
            <div v-if="reviewData.avgRating > 0" class="flex items-center gap-2 mt-2">
              <Star class="h-4 w-4 fill-yellow-400 text-yellow-400" />
              <span class="text-sm font-medium">{{ reviewData.avgRating }}</span>
              <span class="text-xs text-muted-foreground">({{ reviewData.reviewCount }})</span>
            </div>
          </CardHeader>
          <CardContent class="space-y-3">
            <Button v-if="enrolled" class="w-full" @click="goToLearn">
              Continue Learning
            </Button>
            <Button v-else class="w-full" :disabled="enrolling" @click="enroll">
              {{ enrolling ? 'Enrolling...' : course.price > 0 ? 'Buy Now' : 'Enroll Free' }}
            </Button>
            <div class="space-y-2 text-sm text-muted-foreground">
              <div class="flex justify-between">
                <span>Chapters</span>
                <span>{{ course.chapters.length }}</span>
              </div>
              <div class="flex justify-between">
                <span>Lessons</span>
                <span>{{ totalLessons }}</span>
              </div>
              <div class="flex justify-between">
                <span>Students</span>
                <span>{{ course._count.enrollments }}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  </div>
</template>
