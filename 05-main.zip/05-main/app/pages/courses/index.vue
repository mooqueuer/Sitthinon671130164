<script setup lang="ts">
import { Star } from 'lucide-vue-next'

useHead({ title: 'Courses' })

const search = ref('')
const page = ref(1)
const category = ref('')
const pricetype = ref('')
const sort = ref('newest')

const { data, refresh, status } = await useFetch('/api/courses', {
  query: { search, page, limit: 12, category, pricetype, sort },
  watch: [page],
})

function doSearch() {
  page.value = 1
  refresh()
}

function onFilter() {
  page.value = 1
  refresh()
}
</script>

<template>
  <div class="space-y-6">
    <div>
      <h1 class="text-2xl font-bold tracking-tight">Course Catalog</h1>
      <p class="text-muted-foreground">Browse and discover courses</p>
    </div>

    <!-- Search -->
    <div class="flex gap-2">
      <Input v-model="search" placeholder="Search courses..." class="max-w-sm" @keyup.enter="doSearch" />
      <Button @click="doSearch">Search</Button>
    </div>

    <!-- Filters -->
    <CourseFilters v-model:category="category" v-model:pricetype="pricetype" v-model:sort="sort" @filter="onFilter" />

    <!-- Loading skeleton -->
    <div v-if="status === 'pending'" class="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      <Card v-for="i in 6" :key="i" class="overflow-hidden">
        <div class="aspect-video bg-muted animate-pulse" />
        <CardHeader>
          <div class="h-4 w-1/3 animate-pulse rounded bg-muted" />
          <div class="h-5 w-3/4 animate-pulse rounded bg-muted mt-1" />
          <div class="h-4 w-full animate-pulse rounded bg-muted mt-1" />
        </CardHeader>
      </Card>
    </div>

    <!-- Grid -->
    <div v-else-if="data?.courses?.length" class="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      <Card v-for="course in data.courses" :key="course.id" class="overflow-hidden">
        <div class="aspect-video bg-muted" />
        <CardHeader>
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <Badge variant="secondary">{{ course._count.chapters }} chapters</Badge>
              <Badge v-if="course.category" variant="outline" class="text-xs">{{ course.category.name }}</Badge>
            </div>
            <span class="text-sm font-semibold">
              {{ course.price > 0 ? `฿${course.price.toLocaleString()}` : 'Free' }}
            </span>
          </div>
          <CardTitle class="line-clamp-1">
            <NuxtLink :to="`/courses/${course.id}`" class="hover:underline">
              {{ course.title }}
            </NuxtLink>
          </CardTitle>
          <CardDescription class="line-clamp-2">{{ course.description }}</CardDescription>
        </CardHeader>
        <CardContent>
          <div class="flex items-center justify-between text-sm text-muted-foreground">
            <span>by {{ course.teacher.name || 'Instructor' }}</span>
            <div class="flex items-center gap-2">
              <span v-if="course.avgRating > 0" class="flex items-center gap-1">
                <Star class="h-3.5 w-3.5 fill-yellow-400 text-yellow-400" />
                {{ course.avgRating }}
              </span>
              <span>{{ course._count.enrollments }} students</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>

    <!-- Empty state -->
    <div v-else class="py-16 text-center">
      <p class="text-lg font-medium mb-1">No courses found</p>
      <p v-if="search" class="text-muted-foreground mb-4">
        No results for "{{ search }}". Try a different search term.
      </p>
      <p v-else class="text-muted-foreground mb-4">
        Courses will appear here once published by teachers.
      </p>
      <Button v-if="search" variant="outline" @click="search = ''; doSearch()">Clear Search</Button>
    </div>

    <!-- Pagination -->
    <div v-if="data && data.totalPages > 1" class="flex justify-center gap-2">
      <Button variant="outline" size="sm" :disabled="page <= 1" @click="page--">Previous</Button>
      <span class="flex items-center px-3 text-sm text-muted-foreground">
        Page {{ data.page }} of {{ data.totalPages }}
      </span>
      <Button variant="outline" size="sm" :disabled="page >= data.totalPages" @click="page++">Next</Button>
    </div>
  </div>
</template>
