<script setup lang="ts">
import { toast } from 'vue-sonner'

definePageMeta({ layout: 'admin', middleware: 'admin' })
useHead({ title: 'Manage Users' })

const { csrf, headerName } = useCsrf()
const page = ref(1)

const { data, refresh, status } = await useFetch('/api/admin/users', {
  query: { page },
  watch: [page],
})

async function changeRole(userId: string, role: string) {
  try {
    await $fetch(`/api/admin/users/${userId}`, {
      method: 'PUT',
      body: { role },
      headers: { [headerName]: csrf },
    })
    toast.success('Role updated', { description: `User role changed to ${role}.` })
    await refresh()
  } catch (e: any) {
    toast.error('Failed to update role', { description: e.data?.statusMessage })
  }
}
</script>

<template>
  <div class="space-y-6">
    <h1 class="text-2xl font-bold tracking-tight">Manage Users</h1>

    <Card>
      <CardContent class="pt-6">
        <div v-if="status === 'pending'" class="space-y-3">
          <div v-for="i in 5" :key="i" class="flex items-center justify-between rounded border px-4 py-3">
            <div class="space-y-2">
              <div class="h-4 w-32 animate-pulse rounded bg-muted" />
              <div class="h-3 w-48 animate-pulse rounded bg-muted" />
            </div>
            <div class="h-9 w-32 animate-pulse rounded bg-muted" />
          </div>
        </div>
        <div v-else class="space-y-3">
          <div
            v-for="u in data?.users"
            :key="u.id"
            class="flex items-center justify-between rounded border px-4 py-3"
          >
            <div>
              <p class="font-medium">{{ u.name || 'No name' }}</p>
              <p class="text-sm text-muted-foreground">{{ u.email }}</p>
              <p class="text-xs text-muted-foreground">
                {{ u._count.courses }} courses &middot; {{ u._count.enrollments }} enrollments
              </p>
            </div>
            <Select :model-value="u.role" @update:model-value="(v: any) => changeRole(u.id, v)">
              <SelectTrigger class="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="STUDENT">Student</SelectItem>
                <SelectItem value="TEACHER">Teacher</SelectItem>
                <SelectItem value="ADMIN">Admin</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardContent>
    </Card>

    <div v-if="data && data.totalPages > 1" class="flex justify-center gap-2">
      <Button variant="outline" size="sm" :disabled="page <= 1" @click="page--">Previous</Button>
      <span class="flex items-center px-3 text-sm text-muted-foreground">
        Page {{ data.page }} of {{ data.totalPages }}
      </span>
      <Button variant="outline" size="sm" :disabled="page >= data.totalPages" @click="page++">Next</Button>
    </div>
  </div>
</template>
