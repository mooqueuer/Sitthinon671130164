<script setup lang="ts">
definePageMeta({ layout: 'admin', middleware: 'admin' })
useHead({ title: 'Admin Dashboard' })

const { data: stats, status } = await useFetch('/api/admin/stats')
</script>

<template>
  <div class="space-y-6">
    <h1 class="text-2xl font-bold tracking-tight">Admin Dashboard</h1>

    <!-- Stats cards with loading -->
    <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <Card v-if="status === 'pending'" v-for="i in 4" :key="i">
        <CardHeader class="pb-2">
          <div class="h-4 w-24 animate-pulse rounded bg-muted" />
          <div class="h-7 w-12 animate-pulse rounded bg-muted mt-1" />
        </CardHeader>
      </Card>
      <template v-else>
        <Card>
          <CardHeader class="pb-2">
            <CardDescription>Total Users</CardDescription>
            <CardTitle class="text-2xl">{{ stats?.totalUsers || 0 }}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader class="pb-2">
            <CardDescription>Total Courses</CardDescription>
            <CardTitle class="text-2xl">{{ stats?.totalCourses || 0 }}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader class="pb-2">
            <CardDescription>Total Enrollments</CardDescription>
            <CardTitle class="text-2xl">{{ stats?.totalEnrollments || 0 }}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader class="pb-2">
            <CardDescription>Pending Payments</CardDescription>
            <CardTitle class="text-2xl">{{ stats?.pendingPayments || 0 }}</CardTitle>
          </CardHeader>
        </Card>
      </template>
    </div>

    <div class="grid gap-6 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle class="text-base">Revenue</CardTitle>
        </CardHeader>
        <CardContent>
          <p class="text-3xl font-bold">฿{{ (stats?.totalRevenue || 0).toLocaleString() }}</p>
          <p class="text-sm text-muted-foreground">From confirmed payments</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle class="text-base">Role Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <div v-if="stats?.roleDistribution?.length" class="space-y-2">
            <div v-for="r in stats.roleDistribution" :key="r.role" class="flex items-center justify-between">
              <Badge :variant="r.role === 'ADMIN' ? 'destructive' : r.role === 'TEACHER' ? 'default' : 'secondary'">
                {{ r.role }}
              </Badge>
              <span class="font-medium">{{ r.count }}</span>
            </div>
          </div>
          <p v-else class="text-sm text-muted-foreground">No data yet.</p>
        </CardContent>
      </Card>
    </div>

    <Card>
      <CardHeader>
        <CardTitle class="text-base">Recent Users</CardTitle>
      </CardHeader>
      <CardContent>
        <div v-if="stats?.recentUsers?.length" class="space-y-3">
          <div v-for="u in stats.recentUsers" :key="u.id" class="flex items-center justify-between">
            <div>
              <p class="text-sm font-medium">{{ u.name || u.email }}</p>
              <p class="text-xs text-muted-foreground">{{ u.email }}</p>
            </div>
            <div class="flex items-center gap-2">
              <Badge variant="secondary" class="text-[10px]">{{ u.role }}</Badge>
              <span class="text-xs text-muted-foreground">{{ new Date(u.createdAt).toLocaleDateString() }}</span>
            </div>
          </div>
        </div>
        <p v-else class="text-sm text-muted-foreground">No users yet.</p>
      </CardContent>
    </Card>
  </div>
</template>
