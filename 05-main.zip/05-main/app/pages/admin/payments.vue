<script setup lang="ts">
import { toast } from 'vue-sonner'

definePageMeta({ layout: 'admin', middleware: 'admin' })
useHead({ title: 'Manage Payments' })

const { csrf, headerName } = useCsrf()
const page = ref(1)
const statusFilter = ref('')

const { data, refresh, status } = await useFetch('/api/admin/payments', {
  query: { page, status: statusFilter },
  watch: [page, statusFilter],
})

async function confirmPayment(id: string) {
  try {
    await $fetch(`/api/payments/${id}/confirm`, {
      method: 'POST',
      headers: { [headerName]: csrf },
    })
    toast.success('Payment confirmed', { description: 'Student has been enrolled.' })
    await refresh()
  } catch (e: any) {
    toast.error('Failed to confirm payment', { description: e.data?.statusMessage })
  }
}

async function rejectPayment(id: string) {
  if (!confirm('Reject this payment?')) return
  try {
    await $fetch(`/api/payments/${id}/reject`, {
      method: 'POST',
      headers: { [headerName]: csrf },
    })
    toast.success('Payment rejected')
    await refresh()
  } catch (e: any) {
    toast.error('Failed to reject payment', { description: e.data?.statusMessage })
  }
}
</script>

<template>
  <div class="space-y-6">
    <div class="flex items-center justify-between">
      <h1 class="text-2xl font-bold tracking-tight">Manage Payments</h1>
      <Select v-model="statusFilter">
        <SelectTrigger class="w-40">
          <SelectValue placeholder="All statuses" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="">All</SelectItem>
          <SelectItem value="PENDING">Pending</SelectItem>
          <SelectItem value="CONFIRMED">Confirmed</SelectItem>
          <SelectItem value="REJECTED">Rejected</SelectItem>
        </SelectContent>
      </Select>
    </div>

    <Card>
      <CardContent class="pt-6">
        <div v-if="status === 'pending'" class="space-y-3">
          <div v-for="i in 3" :key="i" class="flex items-center justify-between rounded border px-4 py-3">
            <div class="space-y-2">
              <div class="h-4 w-24 animate-pulse rounded bg-muted" />
              <div class="h-3 w-48 animate-pulse rounded bg-muted" />
            </div>
            <div class="h-6 w-20 animate-pulse rounded bg-muted" />
          </div>
        </div>
        <div v-else-if="data?.payments?.length" class="space-y-3">
          <div
            v-for="payment in data.payments"
            :key="payment.id"
            class="flex items-center justify-between rounded border px-4 py-3"
          >
            <div>
              <p class="font-medium">฿{{ payment.amount.toLocaleString() }}</p>
              <p class="text-sm text-muted-foreground">
                {{ payment.user.name || payment.user.email }} &rarr; {{ payment.course.title }}
              </p>
              <p class="text-xs text-muted-foreground">
                {{ new Date(payment.createdAt).toLocaleString() }}
                <span v-if="payment.method"> &middot; {{ payment.method }}</span>
              </p>
            </div>
            <div class="flex items-center gap-2">
              <Badge
                :variant="payment.status === 'CONFIRMED' ? 'default' : payment.status === 'REJECTED' ? 'destructive' : 'secondary'"
              >
                {{ payment.status }}
              </Badge>
              <template v-if="payment.status === 'PENDING'">
                <Button size="sm" @click="confirmPayment(payment.id)">Confirm</Button>
                <Button variant="outline" size="sm" @click="rejectPayment(payment.id)">Reject</Button>
              </template>
            </div>
          </div>
        </div>
        <p v-else class="text-center text-muted-foreground py-8">No payments found.</p>
      </CardContent>
    </Card>

    <div v-if="data && data.totalPages > 1" class="flex justify-center gap-2">
      <Button variant="outline" size="sm" :disabled="page <= 1" @click="page--">Previous</Button>
      <span class="flex items-center px-3 text-sm text-muted-foreground">
        Page {{ data.page }} of {{ data.totalPages }}
      </span>
      <Button variant="outline" size="sm" :disabled="page >= data.totalPages" @click="page++">Next</Button>
    </div>
  </div>
</template>
