<script setup lang="ts">
definePageMeta({ layout: 'admin', middleware: 'admin' })
useHead({ title: 'Manage Courses' })

const page = ref(1)

const { data } = await useFetch('/api/admin/courses', {
  query: { page },
  watch: [page],
})
</script>

<template>
  <div class="space-y-6">
    <h1 class="text-2xl font-bold tracking-tight">Manage Courses</h1>

    <Card>
      <CardContent class="pt-6">
        <div class="space-y-3">
          <div
            v-for="course in data?.courses"
            :key="course.id"
            class="flex items-center justify-between rounded border px-4 py-3"
          >
            <div>
              <p class="font-medium">{{ course.title }}</p>
              <p class="text-sm text-muted-foreground">
                by {{ course.teacher.name || course.teacher.email }} &middot;
                {{ course._count.chapters }} chapters &middot;
                {{ course._count.enrollments }} students &middot;
                {{ course.price > 0 ? `฿${course.price}` : 'Free' }}
              </p>
            </div>
            <div class="flex items-center gap-2">
              <Badge :variant="course.status === 'PUBLISHED' ? 'default' : 'secondary'">
                {{ course.status }}
              </Badge>
              <Button variant="outline" size="sm" as-child>
                <NuxtLink :to="`/courses/${course.id}`">View</NuxtLink>
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>

    <div v-if="data && data.totalPages > 1" class="flex justify-center gap-2">
      <Button variant="outline" size="sm" :disabled="page <= 1" @click="page--">Previous</Button>
      <span class="flex items-center px-3 text-sm text-muted-foreground">
        Page {{ data.page }} of {{ data.totalPages }}
      </span>
      <Button variant="outline" size="sm" :disabled="page >= data.totalPages" @click="page++">Next</Button>
    </div>
  </div>
</template>
