<script setup lang="ts">
import { toast } from 'vue-sonner'

definePageMeta({ layout: 'admin', middleware: 'admin' })
useHead({ title: 'Manage Categories' })

const { csrf, headerName } = useCsrf()

const { data: categories, refresh } = await useFetch('/api/categories')

const newName = ref('')
const creating = ref(false)
const editingId = ref('')
const editingName = ref('')

async function createCategory() {
  if (!newName.value.trim()) return
  creating.value = true
  try {
    await $fetch('/api/admin/categories', {
      method: 'POST',
      body: { name: newName.value.trim() },
      headers: { [headerName]: csrf },
    })
    newName.value = ''
    await refresh()
    toast.success('Category created')
  } catch (e: any) {
    toast.error('Failed to create', { description: e.data?.statusMessage })
  } finally {
    creating.value = false
  }
}

function startEdit(cat: any) {
  editingId.value = cat.id
  editingName.value = cat.name
}

async function saveEdit() {
  if (!editingName.value.trim()) return
  try {
    await $fetch(`/api/admin/categories/${editingId.value}`, {
      method: 'PUT',
      body: { name: editingName.value.trim() },
      headers: { [headerName]: csrf },
    })
    editingId.value = ''
    await refresh()
    toast.success('Category updated')
  } catch (e: any) {
    toast.error('Failed to update', { description: e.data?.statusMessage })
  }
}

async function deleteCategory(id: string) {
  if (!confirm('Delete this category? Courses will be unlinked.')) return
  try {
    await $fetch(`/api/admin/categories/${id}`, {
      method: 'DELETE',
      headers: { [headerName]: csrf },
    })
    await refresh()
    toast.success('Category deleted')
  } catch (e: any) {
    toast.error('Failed to delete', { description: e.data?.statusMessage })
  }
}
</script>

<template>
  <div class="space-y-6">
    <div>
      <h1 class="text-2xl font-bold tracking-tight">Categories</h1>
      <p class="text-muted-foreground">Manage course categories</p>
    </div>

    <Card>
      <CardHeader>
        <CardTitle class="text-sm font-medium">Add Category</CardTitle>
      </CardHeader>
      <CardContent>
        <form class="flex gap-2" @submit.prevent="createCategory">
          <Input v-model="newName" placeholder="Category name" class="max-w-xs" />
          <Button :disabled="creating || !newName.trim()">
            {{ creating ? 'Adding...' : 'Add' }}
          </Button>
        </form>
      </CardContent>
    </Card>

    <Card>
      <CardContent class="p-0">
        <div class="divide-y">
          <div v-for="cat in categories" :key="cat.id" class="flex items-center justify-between px-6 py-3">
            <div v-if="editingId === cat.id" class="flex items-center gap-2">
              <Input v-model="editingName" class="h-8 w-48" @keyup.enter="saveEdit" />
              <Button size="sm" variant="outline" @click="saveEdit">Save</Button>
              <Button size="sm" variant="ghost" @click="editingId = ''">Cancel</Button>
            </div>
            <div v-else class="flex items-center gap-3">
              <span class="font-medium">{{ cat.name }}</span>
              <Badge variant="secondary" class="text-xs">{{ cat._count.courses }} courses</Badge>
            </div>
            <div v-if="editingId !== cat.id" class="flex gap-1">
              <Button size="sm" variant="ghost" @click="startEdit(cat)">Edit</Button>
              <Button size="sm" variant="ghost" class="text-destructive" @click="deleteCategory(cat.id)">Delete</Button>
            </div>
          </div>
          <div v-if="!categories?.length" class="px-6 py-8 text-center text-muted-foreground">
            No categories yet
          </div>
        </div>
      </CardContent>
    </Card>
  </div>
</template>
