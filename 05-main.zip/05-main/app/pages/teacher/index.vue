<script setup lang="ts">
definePageMeta({ layout: 'teacher', middleware: 'teacher' })
useHead({ title: 'Teacher Dashboard' })

const { user } = useUserSession()

const { data: courses, status } = await useFetch('/api/teacher/courses')
</script>

<template>
  <div class="space-y-6">
    <div class="flex items-center justify-between">
      <div>
        <h1 class="text-2xl font-bold tracking-tight">Teacher Dashboard</h1>
        <p class="text-muted-foreground">Welcome, {{ user?.name || 'Teacher' }}</p>
      </div>
      <Button as-child>
        <NuxtLink to="/teacher/courses/new">Create Course</NuxtLink>
      </Button>
    </div>

    <div v-if="status === 'pending'" class="grid gap-4 sm:grid-cols-3">
      <Card v-for="i in 3" :key="i">
        <CardHeader class="pb-2">
          <div class="h-4 w-24 animate-pulse rounded bg-muted" />
          <div class="h-7 w-12 animate-pulse rounded bg-muted mt-1" />
        </CardHeader>
      </Card>
    </div>

    <div v-else class="grid gap-4 sm:grid-cols-3">
      <Card>
        <CardHeader class="pb-2">
          <CardDescription>Total Courses</CardDescription>
          <CardTitle class="text-2xl">{{ courses?.length || 0 }}</CardTitle>
        </CardHeader>
      </Card>
      <Card>
        <CardHeader class="pb-2">
          <CardDescription>Published</CardDescription>
          <CardTitle class="text-2xl">
            {{ courses?.filter((c: any) => c.status === 'PUBLISHED').length || 0 }}
          </CardTitle>
        </CardHeader>
      </Card>
      <Card>
        <CardHeader class="pb-2">
          <CardDescription>Total Students</CardDescription>
          <CardTitle class="text-2xl">
            {{ courses?.reduce((sum: number, c: any) => sum + (c._count?.enrollments || 0), 0) || 0 }}
          </CardTitle>
        </CardHeader>
      </Card>
    </div>

    <Separator />

    <div class="space-y-4">
      <h2 class="text-lg font-semibold">Your Courses</h2>
      <div v-if="courses?.length" class="space-y-3">
        <Card v-for="course in courses" :key="course.id">
          <CardContent class="flex items-center justify-between py-4">
            <div>
              <p class="font-medium">{{ course.title }}</p>
              <p class="text-sm text-muted-foreground">
                {{ course._count.enrollments }} students &middot;
                <Badge :variant="course.status === 'PUBLISHED' ? 'default' : 'secondary'" class="text-[10px]">
                  {{ course.status }}
                </Badge>
              </p>
            </div>
            <Button variant="outline" size="sm" as-child>
              <NuxtLink :to="`/teacher/courses/${course.id}/edit`">Edit</NuxtLink>
            </Button>
          </CardContent>
        </Card>
      </div>
      <p v-else class="text-sm text-muted-foreground">No courses yet. Create your first course!</p>
    </div>
  </div>
</template>
