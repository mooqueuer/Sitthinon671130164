<script setup lang="ts">
import { Star } from 'lucide-vue-next'

definePageMeta({ layout: 'teacher', middleware: 'teacher' })
useHead({ title: 'Analytics' })

const { data: overview } = await useFetch('/api/teacher/analytics', {
  default: () => ({ totalStudents: 0, totalRevenue: 0, totalCourses: 0, totalReviews: 0, avgRating: 0 }),
})
const { data: enrollmentTrend } = await useFetch('/api/teacher/analytics/enrollments', { default: () => [] })
const { data: completion } = await useFetch('/api/teacher/analytics/completion', { default: () => [] })
const { data: quizStats } = await useFetch('/api/teacher/analytics/quizzes', { default: () => [] })
const { data: revenue } = await useFetch('/api/teacher/analytics/revenue', { default: () => [] })

const chartData = computed(() =>
  (enrollmentTrend.value || []).map((d: any) => ({ label: d.label, value: d.count }))
)
</script>

<template>
  <div class="space-y-8">
    <div>
      <h1 class="text-2xl font-bold tracking-tight">Analytics</h1>
      <p class="text-muted-foreground">Overview of your teaching performance</p>
    </div>

    <!-- Overview Stats -->
    <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <StatCard title="Total Students" :value="overview.totalStudents" />
      <StatCard title="Courses" :value="overview.totalCourses" />
      <StatCard
        title="Revenue"
        :value="`฿${overview.totalRevenue.toLocaleString()}`"
      />
      <Card>
        <CardHeader class="pb-2">
          <CardDescription>Avg Rating</CardDescription>
          <CardTitle class="flex items-center gap-2 text-2xl">
            {{ overview.avgRating || '-' }}
            <Star v-if="overview.avgRating > 0" class="h-5 w-5 fill-yellow-400 text-yellow-400" />
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p class="text-xs text-muted-foreground">{{ overview.totalReviews }} reviews</p>
        </CardContent>
      </Card>
    </div>

    <!-- Enrollment Trend -->
    <Card>
      <CardHeader>
        <CardTitle class="text-sm font-medium">Enrollments (Last 30 Days)</CardTitle>
      </CardHeader>
      <CardContent>
        <BarChart v-if="chartData.length" :data="chartData" :height="160" />
        <p v-else class="text-sm text-muted-foreground">No enrollment data yet</p>
      </CardContent>
    </Card>

    <!-- Completion Rates -->
    <Card v-if="completion?.length">
      <CardHeader>
        <CardTitle class="text-sm font-medium">Course Completion Rates</CardTitle>
      </CardHeader>
      <CardContent class="space-y-4">
        <div v-for="c in completion" :key="c.courseId" class="space-y-1">
          <div class="flex items-center justify-between text-sm">
            <span class="font-medium line-clamp-1">{{ c.title }}</span>
            <span class="text-muted-foreground">{{ c.completed }}/{{ c.enrolled }} ({{ c.rate }}%)</span>
          </div>
          <Progress :model-value="c.rate" class="h-2" />
        </div>
      </CardContent>
    </Card>

    <!-- Quiz Stats -->
    <Card v-if="quizStats?.length">
      <CardHeader>
        <CardTitle class="text-sm font-medium">Quiz Performance</CardTitle>
      </CardHeader>
      <CardContent class="p-0">
        <div class="divide-y">
          <div v-for="q in quizStats" :key="q.quizId" class="flex items-center justify-between px-6 py-3">
            <div>
              <p class="text-sm font-medium">{{ q.quizTitle }}</p>
              <p class="text-xs text-muted-foreground">{{ q.courseTitle }}</p>
            </div>
            <div class="flex items-center gap-3 text-sm">
              <Badge variant="secondary">{{ q.totalAttempts }} attempts</Badge>
              <Badge :variant="q.passRate >= 70 ? 'default' : 'destructive'">
                {{ q.passRate }}% pass rate
              </Badge>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>

    <!-- Revenue Breakdown -->
    <Card v-if="revenue?.length">
      <CardHeader>
        <CardTitle class="text-sm font-medium">Revenue by Course</CardTitle>
      </CardHeader>
      <CardContent class="p-0">
        <div class="divide-y">
          <div v-for="r in revenue" :key="r.courseId" class="flex items-center justify-between px-6 py-3">
            <div>
              <p class="text-sm font-medium">{{ r.title }}</p>
              <p class="text-xs text-muted-foreground">{{ r.sales }} sales</p>
            </div>
            <span class="font-semibold">฿{{ r.revenue.toLocaleString() }}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  </div>
</template>
