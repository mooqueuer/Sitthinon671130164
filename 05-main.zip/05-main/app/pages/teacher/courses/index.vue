<script setup lang="ts">
definePageMeta({ layout: 'teacher', middleware: 'teacher' })
useHead({ title: 'My Courses' })

const { data, status } = await useFetch('/api/teacher/courses')
</script>

<template>
  <div class="space-y-6">
    <div class="flex items-center justify-between">
      <h1 class="text-2xl font-bold tracking-tight">My Courses</h1>
      <Button as-child>
        <NuxtLink to="/teacher/courses/new">Create Course</NuxtLink>
      </Button>
    </div>

    <div v-if="status === 'pending'" class="space-y-3">
      <Card v-for="i in 3" :key="i">
        <CardContent class="flex items-center justify-between py-4">
          <div class="space-y-2">
            <div class="h-4 w-48 animate-pulse rounded bg-muted" />
            <div class="h-3 w-32 animate-pulse rounded bg-muted" />
          </div>
        </CardContent>
      </Card>
    </div>

    <div v-else-if="data?.length" class="space-y-3">
      <Card v-for="course in data" :key="course.id">
        <CardContent class="flex items-center justify-between py-4">
          <div class="flex-1">
            <p class="font-medium">{{ course.title }}</p>
            <div class="flex items-center gap-3 text-sm text-muted-foreground">
              <Badge :variant="course.status === 'PUBLISHED' ? 'default' : 'secondary'" class="text-[10px]">
                {{ course.status }}
              </Badge>
              <span>{{ course._count.chapters }} chapters</span>
              <span>{{ course._count.enrollments }} students</span>
              <span>{{ course.price > 0 ? `฿${course.price}` : 'Free' }}</span>
            </div>
          </div>
          <Button variant="outline" size="sm" as-child>
            <NuxtLink :to="`/teacher/courses/${course.id}/edit`">Edit</NuxtLink>
          </Button>
        </CardContent>
      </Card>
    </div>
    <p v-else class="text-muted-foreground">No courses yet.</p>
  </div>
</template>
