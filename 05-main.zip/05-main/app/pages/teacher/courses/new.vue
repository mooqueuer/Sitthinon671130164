<script setup lang="ts">
import { toast } from 'vue-sonner'

definePageMeta({ layout: 'teacher', middleware: 'teacher' })
useHead({ title: 'Create Course' })

const { csrf, headerName } = useCsrf()

const title = ref('')
const description = ref('')
const price = ref(0)
const loading = ref(false)

async function create() {
  loading.value = true
  try {
    const course = await $fetch('/api/courses', {
      method: 'POST',
      body: { title: title.value, description: description.value, price: price.value },
      headers: { [headerName]: csrf },
    })
    toast.success('Course created!', { description: 'Now add chapters and lessons.' })
    await navigateTo(`/teacher/courses/${(course as any).id}/edit`)
  } catch (e: any) {
    toast.error('Failed to create course', { description: e.data?.statusMessage || 'Please try again.' })
    loading.value = false
  }
}
</script>

<template>
  <div class="max-w-2xl space-y-6">
    <div>
      <h1 class="text-2xl font-bold tracking-tight">Create Course</h1>
      <p class="text-muted-foreground">Set up your new course</p>
    </div>

    <form @submit.prevent="create" class="space-y-4">
      <div class="space-y-2">
        <Label for="title">Course Title</Label>
        <Input id="title" v-model="title" placeholder="e.g. Introduction to Web Development" required />
      </div>

      <div class="space-y-2">
        <Label for="description">Description</Label>
        <Textarea id="description" v-model="description" placeholder="What will students learn?" rows="4" />
      </div>

      <div class="space-y-2">
        <Label for="price">Price (฿)</Label>
        <Input id="price" v-model.number="price" type="number" min="0" step="1" />
        <p class="text-xs text-muted-foreground">Set to 0 for a free course</p>
      </div>

      <div class="flex gap-3">
        <Button type="submit" :disabled="loading">
          {{ loading ? 'Creating...' : 'Create Course' }}
        </Button>
        <Button variant="outline" type="button" as-child>
          <NuxtLink to="/teacher">Cancel</NuxtLink>
        </Button>
      </div>
    </form>
  </div>
</template>
