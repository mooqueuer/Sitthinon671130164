<script setup lang="ts">
import { toast } from 'vue-sonner'

definePageMeta({ layout: 'teacher', middleware: 'teacher' })

const route = useRoute()
const { csrf, headerName } = useCsrf()
const courseId = route.params.id as string

const { data: course, refresh: refreshCourse } = await useFetch(`/api/courses/${courseId}`)
useHead({ title: `Edit: ${course.value?.title || 'Course'}` })

// Course settings
const title = ref(course.value?.title || '')
const description = ref(course.value?.description || '')
const price = ref(course.value?.price || 0)
const saving = ref(false)

async function saveCourse() {
  saving.value = true
  try {
    await $fetch(`/api/courses/${courseId}`, {
      method: 'PUT',
      body: { title: title.value, description: description.value, price: price.value },
      headers: { [headerName]: csrf },
    })
    toast.success('Course saved')
    await refreshCourse()
  } catch (e: any) {
    toast.error('Failed to save', { description: e.data?.statusMessage })
  } finally {
    saving.value = false
  }
}

async function togglePublish() {
  const newStatus = course.value?.status === 'PUBLISHED' ? 'DRAFT' : 'PUBLISHED'
  try {
    await $fetch(`/api/courses/${courseId}`, {
      method: 'PUT',
      body: { status: newStatus },
      headers: { [headerName]: csrf },
    })
    toast.success(newStatus === 'PUBLISHED' ? 'Course published!' : 'Course unpublished')
    await refreshCourse()
  } catch (e: any) {
    toast.error('Failed to update status', { description: e.data?.statusMessage })
  }
}

// Chapter management
const newChapterTitle = ref('')
const addingChapter = ref(false)

async function addChapter() {
  if (!newChapterTitle.value) return
  addingChapter.value = true
  try {
    await $fetch(`/api/courses/${courseId}/chapters`, {
      method: 'POST',
      body: { title: newChapterTitle.value },
      headers: { [headerName]: csrf },
    })
    toast.success('Chapter added')
    newChapterTitle.value = ''
    await refreshCourse()
  } catch (e: any) {
    toast.error('Failed to add chapter', { description: e.data?.statusMessage })
  } finally {
    addingChapter.value = false
  }
}

async function deleteChapter(chapterId: string) {
  if (!confirm('Delete this chapter and all its lessons?')) return
  try {
    await $fetch(`/api/courses/${courseId}/chapters/${chapterId}`, {
      method: 'DELETE',
      headers: { [headerName]: csrf },
    })
    toast.success('Chapter deleted')
    await refreshCourse()
  } catch (e: any) {
    toast.error('Failed to delete chapter', { description: e.data?.statusMessage })
  }
}

// Lesson management
const addingLessonTo = ref('')
const newLessonTitle = ref('')
const newLessonType = ref('TEXT')

async function addLesson(chapterId: string) {
  if (!newLessonTitle.value) return
  try {
    await $fetch(`/api/courses/${courseId}/lessons`, {
      method: 'POST',
      body: { title: newLessonTitle.value, type: newLessonType.value, chapterId },
      headers: { [headerName]: csrf },
    })
    toast.success('Lesson added')
    newLessonTitle.value = ''
    newLessonType.value = 'TEXT'
    addingLessonTo.value = ''
    await refreshCourse()
  } catch (e: any) {
    toast.error('Failed to add lesson', { description: e.data?.statusMessage })
  }
}

async function deleteLesson(lessonId: string) {
  if (!confirm('Delete this lesson?')) return
  try {
    await $fetch(`/api/courses/${courseId}/lessons/${lessonId}`, {
      method: 'DELETE',
      headers: { [headerName]: csrf },
    })
    toast.success('Lesson deleted')
    await refreshCourse()
  } catch (e: any) {
    toast.error('Failed to delete lesson', { description: e.data?.statusMessage })
  }
}

// Lesson editing
const editingLesson = ref<any>(null)
const editLessonTitle = ref('')
const editLessonType = ref('TEXT')
const editLessonContent = ref('')
const editLessonVideoUrl = ref('')
const editLessonFileUrl = ref('')
const savingLesson = ref(false)

async function openEditLesson(lesson: any) {
  // Fetch full lesson data
  try {
    const data = await $fetch(`/api/courses/${courseId}/lessons/${lesson.id}`)
    editingLesson.value = data
    editLessonTitle.value = (data as any).title || ''
    editLessonType.value = (data as any).type || 'TEXT'
    editLessonContent.value = (data as any).content || ''
    editLessonVideoUrl.value = (data as any).videoUrl || ''
    editLessonFileUrl.value = (data as any).fileUrl || ''
  } catch (e: any) {
    toast.error('Failed to load lesson', { description: e.data?.statusMessage })
  }
}

async function saveLesson() {
  if (!editingLesson.value) return
  savingLesson.value = true
  try {
    await $fetch(`/api/courses/${courseId}/lessons/${editingLesson.value.id}`, {
      method: 'PUT',
      body: {
        title: editLessonTitle.value,
        type: editLessonType.value,
        content: editLessonContent.value || undefined,
        videoUrl: editLessonVideoUrl.value || undefined,
        fileUrl: editLessonFileUrl.value || undefined,
      },
      headers: { [headerName]: csrf },
    })
    toast.success('Lesson updated')
    editingLesson.value = null
    await refreshCourse()
  } catch (e: any) {
    toast.error('Failed to update lesson', { description: e.data?.statusMessage })
  } finally {
    savingLesson.value = false
  }
}
</script>

<template>
  <div v-if="course" class="space-y-8">
    <div class="flex items-center justify-between">
      <div>
        <h1 class="text-2xl font-bold tracking-tight">Edit Course</h1>
        <Badge :variant="course.status === 'PUBLISHED' ? 'default' : 'secondary'">{{ course.status }}</Badge>
      </div>
      <Button :variant="course.status === 'PUBLISHED' ? 'outline' : 'default'" @click="togglePublish">
        {{ course.status === 'PUBLISHED' ? 'Unpublish' : 'Publish' }}
      </Button>
    </div>

    <Tabs default-value="details">
      <TabsList>
        <TabsTrigger value="details">Details</TabsTrigger>
        <TabsTrigger value="curriculum">Curriculum</TabsTrigger>
      </TabsList>

      <!-- Details Tab -->
      <TabsContent value="details" class="space-y-4 pt-4">
        <form @submit.prevent="saveCourse" class="max-w-2xl space-y-4">
          <div class="space-y-2">
            <Label for="title">Title</Label>
            <Input id="title" v-model="title" required />
          </div>
          <div class="space-y-2">
            <Label for="desc">Description</Label>
            <Textarea id="desc" v-model="description" rows="4" />
          </div>
          <div class="space-y-2">
            <Label for="price">Price (฿)</Label>
            <Input id="price" v-model.number="price" type="number" min="0" />
          </div>
          <Button type="submit" :disabled="saving">
            {{ saving ? 'Saving...' : 'Save Changes' }}
          </Button>
        </form>
      </TabsContent>

      <!-- Curriculum Tab -->
      <TabsContent value="curriculum" class="space-y-6 pt-4">
        <div class="space-y-4">
          <div v-for="chapter in course.chapters" :key="chapter.id" class="space-y-2">
            <Card>
              <CardHeader class="py-3">
                <div class="flex items-center justify-between">
                  <CardTitle class="text-base">{{ chapter.title }}</CardTitle>
                  <Button variant="ghost" size="sm" class="text-destructive" @click="deleteChapter(chapter.id)">
                    Delete
                  </Button>
                </div>
              </CardHeader>
              <CardContent class="space-y-2 pt-0">
                <!-- Lessons -->
                <div
                  v-for="lesson in chapter.lessons"
                  :key="lesson.id"
                  class="flex items-center justify-between rounded border px-3 py-2"
                >
                  <div class="flex items-center gap-2">
                    <Badge variant="outline" class="text-[10px]">{{ lesson.type }}</Badge>
                    <span class="text-sm">{{ lesson.title }}</span>
                  </div>
                  <div class="flex items-center gap-1">
                    <Button variant="ghost" size="sm" class="h-7 text-xs" @click="openEditLesson(lesson)">
                      Edit
                    </Button>
                    <Button variant="ghost" size="sm" class="h-7 text-xs text-destructive" @click="deleteLesson(lesson.id)">
                      Delete
                    </Button>
                  </div>
                </div>

                <!-- Add lesson form -->
                <div v-if="addingLessonTo === chapter.id" class="flex items-end gap-2 pt-2">
                  <div class="flex-1 space-y-1">
                    <Label class="text-xs">Lesson Title</Label>
                    <Input v-model="newLessonTitle" placeholder="Lesson title" class="h-8 text-sm" />
                  </div>
                  <Select v-model="newLessonType">
                    <SelectTrigger class="h-8 w-28 text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="TEXT">Text</SelectItem>
                      <SelectItem value="VIDEO">Video</SelectItem>
                      <SelectItem value="FILE">File</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button size="sm" class="h-8" @click="addLesson(chapter.id)">Add</Button>
                  <Button variant="ghost" size="sm" class="h-8" @click="addingLessonTo = ''">Cancel</Button>
                </div>
                <Button v-else variant="ghost" size="sm" class="text-xs" @click="addingLessonTo = chapter.id">
                  + Add Lesson
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        <!-- Add chapter -->
        <div class="flex gap-2">
          <Input v-model="newChapterTitle" placeholder="New chapter title" class="max-w-sm" @keyup.enter="addChapter" />
          <Button :disabled="addingChapter || !newChapterTitle" @click="addChapter">
            {{ addingChapter ? 'Adding...' : 'Add Chapter' }}
          </Button>
        </div>
      </TabsContent>
    </Tabs>

    <!-- Edit Lesson Dialog -->
    <Dialog :open="!!editingLesson" @update:open="(v) => { if (!v) editingLesson = null }">
      <DialogContent class="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Edit Lesson</DialogTitle>
          <DialogDescription>Update lesson content and settings</DialogDescription>
        </DialogHeader>
        <div class="space-y-4">
          <div class="space-y-2">
            <Label>Title</Label>
            <Input v-model="editLessonTitle" />
          </div>
          <div class="space-y-2">
            <Label>Type</Label>
            <Select v-model="editLessonType">
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="TEXT">Text</SelectItem>
                <SelectItem value="VIDEO">Video</SelectItem>
                <SelectItem value="FILE">File</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div v-if="editLessonType === 'TEXT'" class="space-y-2">
            <Label>Content (HTML)</Label>
            <Textarea v-model="editLessonContent" rows="8" placeholder="Lesson content..." />
          </div>
          <div v-if="editLessonType === 'VIDEO'" class="space-y-2">
            <Label>Video URL</Label>
            <Input v-model="editLessonVideoUrl" placeholder="https://www.youtube.com/embed/..." />
          </div>
          <div v-if="editLessonType === 'FILE'" class="space-y-2">
            <Label>File URL</Label>
            <Input v-model="editLessonFileUrl" placeholder="https://..." />
          </div>
          <div v-if="editLessonType !== 'TEXT'" class="space-y-2">
            <Label>Additional Content (optional)</Label>
            <Textarea v-model="editLessonContent" rows="4" placeholder="Additional notes..." />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" @click="editingLesson = null">Cancel</Button>
          <Button :disabled="savingLesson" @click="saveLesson">
            {{ savingLesson ? 'Saving...' : 'Save Lesson' }}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  </div>
</template>
