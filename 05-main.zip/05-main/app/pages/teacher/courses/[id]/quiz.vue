<script setup lang="ts">
import { toast } from 'vue-sonner'

definePageMeta({ layout: 'teacher', middleware: 'teacher' })

const route = useRoute()
const { csrf, headerName } = useCsrf()
const courseId = route.params.id as string

const { data: course, refresh } = await useFetch(`/api/courses/${courseId}`)
useHead({ title: `Quizzes: ${course.value?.title || 'Course'}` })

const allLessons = computed(() =>
  (course.value?.chapters || []).flatMap((c: any) =>
    c.lessons.map((l: any) => ({ ...l, chapterTitle: c.title }))
  )
)

// Fetch quiz status for each lesson
const lessonQuizMap = ref<Record<string, any>>({})

onMounted(async () => {
  for (const lesson of allLessons.value) {
    try {
      const data = await $fetch(`/api/quizzes/${lesson.id}`)
      lessonQuizMap.value[lesson.id] = data
    } catch {
      // No quiz for this lesson
    }
  }
})

// Create quiz form
const showForm = ref(false)
const selectedLessonId = ref('')
const quizTitle = ref('')
const passingScore = ref(70)
const questions = ref<Array<{
  text: string
  type: string
  options: Array<{ text: string; isCorrect: boolean }>
}>>([])

function addQuestion() {
  questions.value.push({
    text: '',
    type: 'MULTIPLE_CHOICE',
    options: [
      { text: '', isCorrect: true },
      { text: '', isCorrect: false },
      { text: '', isCorrect: false },
      { text: '', isCorrect: false },
    ],
  })
}

function removeQuestion(index: number) {
  questions.value.splice(index, 1)
}

function setCorrectOption(questionIndex: number, optionIndex: number) {
  questions.value[questionIndex].options.forEach((o, i) => {
    o.isCorrect = i === optionIndex
  })
}

const submitting = ref(false)
async function createQuiz() {
  submitting.value = true
  try {
    await $fetch('/api/quizzes', {
      method: 'POST',
      body: {
        title: quizTitle.value,
        lessonId: selectedLessonId.value,
        passingScore: passingScore.value,
        questions: questions.value.map((q, i) => ({
          text: q.text,
          type: q.type,
          position: i,
          options: q.options.filter((o) => o.text),
        })),
      },
      headers: { [headerName]: csrf },
    })
    toast.success('Quiz created!')
    showForm.value = false
    quizTitle.value = ''
    selectedLessonId.value = ''
    questions.value = []
    // Re-fetch quiz map
    const data = await $fetch(`/api/quizzes/${selectedLessonId.value}`).catch(() => null)
    if (data) lessonQuizMap.value[selectedLessonId.value] = data
    await refresh()
  } catch (e: any) {
    toast.error('Failed to create quiz', { description: e.data?.statusMessage || 'Please try again.' })
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <div class="space-y-6">
    <div class="flex items-center justify-between">
      <div>
        <h1 class="text-2xl font-bold tracking-tight">Manage Quizzes</h1>
        <p class="text-muted-foreground">{{ course?.title }}</p>
      </div>
      <Button @click="showForm = !showForm; if(showForm) addQuestion()">
        {{ showForm ? 'Cancel' : 'Create Quiz' }}
      </Button>
    </div>

    <!-- Create Quiz Form -->
    <Card v-if="showForm">
      <CardHeader>
        <CardTitle>New Quiz</CardTitle>
      </CardHeader>
      <CardContent class="space-y-4">
        <div class="grid gap-4 sm:grid-cols-2">
          <div class="space-y-2">
            <Label>Quiz Title</Label>
            <Input v-model="quizTitle" placeholder="e.g. Chapter 1 Quiz" />
          </div>
          <div class="space-y-2">
            <Label>Lesson</Label>
            <Select v-model="selectedLessonId">
              <SelectTrigger>
                <SelectValue placeholder="Select lesson" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem v-for="lesson in allLessons" :key="lesson.id" :value="lesson.id">
                  {{ lesson.chapterTitle }} - {{ lesson.title }}
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div class="space-y-2">
          <Label>Passing Score (%)</Label>
          <Input v-model.number="passingScore" type="number" min="0" max="100" class="w-24" />
        </div>

        <Separator />

        <div class="space-y-4">
          <h3 class="font-semibold">Questions</h3>
          <Card v-for="(q, qi) in questions" :key="qi">
            <CardContent class="space-y-3 pt-4">
              <div class="flex items-start justify-between gap-2">
                <div class="flex-1 space-y-2">
                  <Label>Question {{ qi + 1 }}</Label>
                  <Input v-model="q.text" placeholder="Question text" />
                </div>
                <Button variant="ghost" size="sm" class="text-destructive" @click="removeQuestion(qi)">Remove</Button>
              </div>
              <div class="space-y-2">
                <Label class="text-xs text-muted-foreground">Options (click radio to set correct answer)</Label>
                <div v-for="(opt, oi) in q.options" :key="oi" class="flex items-center gap-2">
                  <input
                    type="radio"
                    :name="`correct-${qi}`"
                    :checked="opt.isCorrect"
                    @change="setCorrectOption(qi, oi)"
                    class="h-4 w-4"
                  />
                  <Input v-model="opt.text" :placeholder="`Option ${oi + 1}`" class="h-8 text-sm" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Button variant="outline" @click="addQuestion">+ Add Question</Button>
        </div>

        <Separator />
        <Button :disabled="submitting || !quizTitle || !selectedLessonId || !questions.length" @click="createQuiz">
          {{ submitting ? 'Creating...' : 'Create Quiz' }}
        </Button>
      </CardContent>
    </Card>

    <!-- Existing quizzes info -->
    <div class="space-y-3">
      <h2 class="text-lg font-semibold">Lessons</h2>
      <div v-for="lesson in allLessons" :key="lesson.id" class="flex items-center justify-between rounded border px-4 py-3">
        <div>
          <p class="text-sm font-medium">{{ lesson.title }}</p>
          <p class="text-xs text-muted-foreground">{{ lesson.chapterTitle }}</p>
        </div>
        <Badge v-if="lessonQuizMap[lesson.id]" variant="default">Has Quiz</Badge>
        <Badge v-else variant="secondary">No Quiz</Badge>
      </div>
    </div>
  </div>
</template>
