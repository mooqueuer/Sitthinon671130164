<script setup lang="ts">
import { Award } from 'lucide-vue-next'

defineProps<{
  certificate: {
    id: string
    code: string
    issuedAt: string
    course: { id: string; title: string; teacher: { name?: string | null } }
  }
}>()
</script>

<template>
  <Card>
    <CardContent class="flex items-center gap-4 py-4">
      <div class="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary/10">
        <Award class="h-6 w-6 text-primary" />
      </div>
      <div class="flex-1 min-w-0">
        <p class="font-medium line-clamp-1">{{ certificate.course.title }}</p>
        <p class="text-sm text-muted-foreground">
          by {{ certificate.course.teacher.name || 'Instructor' }}
        </p>
        <p class="text-xs text-muted-foreground mt-0.5">
          Issued {{ new Date(certificate.issuedAt).toLocaleDateString() }}
          &middot; Code: {{ certificate.code }}
        </p>
      </div>
      <Button as-child variant="outline" size="sm">
        <NuxtLink :to="`/certificates/${certificate.code}`">View</NuxtLink>
      </Button>
    </CardContent>
  </Card>
</template>
