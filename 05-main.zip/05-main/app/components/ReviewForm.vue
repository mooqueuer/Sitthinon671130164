<script setup lang="ts">
import { toast } from 'vue-sonner'

const props = defineProps<{ courseId: string }>()
const emit = defineEmits<{ submitted: [] }>()

const { csrf, headerName } = useCsrf()

const rating = ref(0)
const comment = ref('')
const submitting = ref(false)

async function submit() {
  if (rating.value === 0) return toast.error('Please select a rating')
  submitting.value = true
  try {
    await $fetch(`/api/courses/${props.courseId}/reviews`, {
      method: 'POST',
      body: { rating: rating.value, comment: comment.value || undefined },
      headers: { [headerName]: csrf },
    })
    toast.success('Review submitted!')
    emit('submitted')
  } catch (e: any) {
    toast.error('Failed to submit review', { description: e.data?.statusMessage })
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <Card>
    <CardHeader>
      <CardTitle class="text-sm font-medium">Write a Review</CardTitle>
    </CardHeader>
    <CardContent class="space-y-3">
      <StarRating v-model="rating" />
      <Textarea v-model="comment" placeholder="Share your experience (optional)" rows="3" />
      <Button :disabled="submitting || rating === 0" size="sm" @click="submit">
        {{ submitting ? 'Submitting...' : 'Submit Review' }}
      </Button>
    </CardContent>
  </Card>
</template>
