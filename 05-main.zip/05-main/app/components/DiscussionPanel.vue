<script setup lang="ts">
import { MessageSquare } from 'lucide-vue-next'
import { toast } from 'vue-sonner'

const props = defineProps<{ lessonId: string }>()
const emit = defineEmits<{ openThread: [id: string] }>()
const { csrf, headerName } = useCsrf()

const data = ref<{ discussions: any[]; total: number }>({ discussions: [], total: 0 })
const loaded = ref(false)

async function load() {
  try {
    data.value = await $fetch(`/api/discussions/${props.lessonId}`)
    loaded.value = true
  } catch {}
}

onMounted(load)

const showForm = ref(false)
const title = ref('')
const content = ref('')
const posting = ref(false)

async function post() {
  if (!title.value.trim() || !content.value.trim()) return
  posting.value = true
  try {
    await $fetch(`/api/discussions/${props.lessonId}`, {
      method: 'POST',
      body: { title: title.value, content: content.value },
      headers: { [headerName]: csrf },
    })
    title.value = ''
    content.value = ''
    showForm.value = false
    await load()
    toast.success('Discussion posted!')
  } catch (e: any) {
    toast.error('Failed to post', { description: e.data?.statusMessage })
  } finally {
    posting.value = false
  }
}
</script>

<template>
  <div class="space-y-4">
    <div class="flex items-center justify-between">
      <h3 class="font-semibold">Discussions ({{ data.total }})</h3>
      <Button size="sm" variant="outline" @click="showForm = !showForm">
        {{ showForm ? 'Cancel' : 'New Discussion' }}
      </Button>
    </div>

    <Card v-if="showForm">
      <CardContent class="pt-4 space-y-3">
        <Input v-model="title" placeholder="Discussion title" />
        <Textarea v-model="content" placeholder="What's on your mind?" rows="3" />
        <Button size="sm" :disabled="posting || !title.trim() || !content.trim()" @click="post">
          {{ posting ? 'Posting...' : 'Post' }}
        </Button>
      </CardContent>
    </Card>

    <div v-if="data.discussions?.length" class="space-y-2">
      <Card
        v-for="d in data.discussions"
        :key="d.id"
        class="cursor-pointer hover:bg-accent/50 transition-colors"
        @click="emit('openThread', d.id)"
      >
        <CardContent class="flex items-start gap-3 py-3">
          <Avatar class="h-7 w-7 shrink-0 mt-0.5">
            <AvatarFallback class="text-xs">{{ (d.user.name || '?')[0].toUpperCase() }}</AvatarFallback>
          </Avatar>
          <div class="flex-1 min-w-0">
            <p class="font-medium text-sm line-clamp-1">{{ d.title }}</p>
            <p class="text-xs text-muted-foreground line-clamp-1">{{ d.content }}</p>
            <div class="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
              <span>{{ d.user.name || 'User' }}</span>
              <span class="flex items-center gap-1">
                <MessageSquare class="h-3 w-3" />
                {{ d._count.replies }}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
    <p v-else-if="loaded" class="text-sm text-muted-foreground">No discussions yet. Start the conversation!</p>
  </div>
</template>
