<script setup lang="ts">
defineProps<{
  title: string
  value: string | number
  description?: string
}>()
</script>

<template>
  <Card>
    <CardHeader class="pb-2">
      <CardDescription>{{ title }}</CardDescription>
      <CardTitle class="text-2xl">{{ value }}</CardTitle>
    </CardHeader>
    <CardContent v-if="description">
      <p class="text-xs text-muted-foreground">{{ description }}</p>
    </CardContent>
  </Card>
</template>
