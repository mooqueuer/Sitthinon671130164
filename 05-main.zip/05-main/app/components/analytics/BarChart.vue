<script setup lang="ts">
const props = defineProps<{
  data: Array<{ label: string; value: number }>
  height?: number
}>()

const maxValue = computed(() => Math.max(...props.data.map(d => d.value), 1))
</script>

<template>
  <div class="flex items-end gap-1" :style="{ height: `${height || 200}px` }">
    <div
      v-for="(item, i) in data"
      :key="i"
      class="group relative flex flex-1 flex-col items-center justify-end"
      style="min-width: 0"
    >
      <Tooltip>
        <TooltipTrigger as-child>
          <div
            class="w-full rounded-t bg-primary/80 transition-colors hover:bg-primary"
            :style="{ height: `${Math.max((item.value / maxValue) * 100, 2)}%` }"
          />
        </TooltipTrigger>
        <TooltipContent>{{ item.label }}: {{ item.value }}</TooltipContent>
      </Tooltip>
    </div>
  </div>
</template>
