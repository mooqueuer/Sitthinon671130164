<script setup lang="ts">
import { Sun, Moon } from 'lucide-vue-next'

const { isDark, toggle } = useTheme()
</script>

<template>
  <ClientOnly>
    <Button variant="ghost" size="icon" class="h-8 w-8" @click="toggle">
      <Sun v-if="isDark" class="h-4 w-4" />
      <Moon v-else class="h-4 w-4" />
      <span class="sr-only">Toggle theme</span>
    </Button>
  </ClientOnly>
</template>
