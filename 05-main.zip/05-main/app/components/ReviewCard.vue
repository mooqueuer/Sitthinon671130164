<script setup lang="ts">
defineProps<{
  review: {
    id: string
    rating: number
    comment?: string | null
    createdAt: string
    user: { id: string; name?: string | null; avatar?: string | null }
  }
}>()
</script>

<template>
  <div class="flex gap-3 py-4">
    <Avatar class="h-8 w-8 shrink-0">
      <AvatarFallback class="text-xs">
        {{ (review.user.name || '?')[0].toUpperCase() }}
      </AvatarFallback>
    </Avatar>
    <div class="flex-1 space-y-1">
      <div class="flex items-center justify-between">
        <span class="text-sm font-medium">{{ review.user.name || 'User' }}</span>
        <span class="text-xs text-muted-foreground">
          {{ new Date(review.createdAt).toLocaleDateString() }}
        </span>
      </div>
      <StarRating :model-value="review.rating" readonly :size="14" />
      <p v-if="review.comment" class="text-sm text-muted-foreground">{{ review.comment }}</p>
    </div>
  </div>
</template>
