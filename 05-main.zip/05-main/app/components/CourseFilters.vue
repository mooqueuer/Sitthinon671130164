<script setup lang="ts">
const emit = defineEmits<{
  filter: []
}>()

const category = defineModel<string>('category', { default: '' })
const pricetype = defineModel<string>('pricetype', { default: '' })
const sort = defineModel<string>('sort', { default: 'newest' })

const { data: categories } = useLazyFetch('/api/categories', { default: () => [] })

function reset() {
  category.value = ''
  pricetype.value = ''
  sort.value = 'newest'
  emit('filter')
}
</script>

<template>
  <div class="flex flex-wrap items-center gap-3">
    <Select v-model="category" @update:model-value="emit('filter')">
      <SelectTrigger class="w-[160px]">
        <SelectValue placeholder="Category" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="">All Categories</SelectItem>
        <SelectItem v-for="cat in categories" :key="cat.id" :value="cat.id">
          {{ cat.name }}
        </SelectItem>
      </SelectContent>
    </Select>

    <Select v-model="pricetype" @update:model-value="emit('filter')">
      <SelectTrigger class="w-[130px]">
        <SelectValue placeholder="Price" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="">All Prices</SelectItem>
        <SelectItem value="free">Free</SelectItem>
        <SelectItem value="paid">Paid</SelectItem>
      </SelectContent>
    </Select>

    <Select v-model="sort" @update:model-value="emit('filter')">
      <SelectTrigger class="w-[140px]">
        <SelectValue placeholder="Sort by" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="newest">Newest</SelectItem>
        <SelectItem value="popular">Most Popular</SelectItem>
        <SelectItem value="rating">Top Rated</SelectItem>
      </SelectContent>
    </Select>

    <Button v-if="category || pricetype || sort !== 'newest'" variant="ghost" size="sm" @click="reset">
      Clear filters
    </Button>
  </div>
</template>
