<script setup lang="ts">
import { Bookmark } from 'lucide-vue-next'
import { toast } from 'vue-sonner'

const props = defineProps<{ lessonId: string; initialBookmarked?: boolean }>()
const { csrf, headerName } = useCsrf()

const bookmarked = ref(props.initialBookmarked || false)
const toggling = ref(false)

async function toggle() {
  toggling.value = true
  try {
    const result = await $fetch('/api/bookmarks', {
      method: 'POST',
      body: { lessonId: props.lessonId },
      headers: { [headerName]: csrf },
    })
    bookmarked.value = result.bookmarked
    toast.success(result.bookmarked ? 'Bookmarked!' : 'Bookmark removed')
  } catch {
    toast.error('Failed to update bookmark')
  } finally {
    toggling.value = false
  }
}
</script>

<template>
  <Button variant="ghost" size="icon" class="h-8 w-8" :disabled="toggling" @click="toggle">
    <Bookmark class="h-4 w-4" :class="bookmarked ? 'fill-current' : ''" />
  </Button>
</template>
