<script setup lang="ts">
import { Zap } from 'lucide-vue-next'

defineProps<{ xp: number }>()
</script>

<template>
  <div class="flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1">
    <Zap class="h-4 w-4 text-primary" />
    <span class="text-sm font-semibold">{{ xp.toLocaleString() }} XP</span>
  </div>
</template>
