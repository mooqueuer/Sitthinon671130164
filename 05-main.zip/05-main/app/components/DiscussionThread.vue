<script setup lang="ts">
import { ArrowLeft } from 'lucide-vue-next'
import { toast } from 'vue-sonner'

const props = defineProps<{ threadId: string }>()
const emit = defineEmits<{ back: [] }>()
const { csrf, headerName } = useCsrf()

const thread = ref<any>(null)

async function load() {
  try {
    thread.value = await $fetch(`/api/discussions/thread/${props.threadId}`)
  } catch {}
}

onMounted(load)

const replyContent = ref('')
const replying = ref(false)

async function postReply() {
  if (!replyContent.value.trim()) return
  replying.value = true
  try {
    await $fetch(`/api/discussions/thread/${props.threadId}/replies`, {
      method: 'POST',
      body: { content: replyContent.value },
      headers: { [headerName]: csrf },
    })
    replyContent.value = ''
    await load()
  } catch (e: any) {
    toast.error('Failed to reply', { description: e.data?.statusMessage })
  } finally {
    replying.value = false
  }
}
</script>

<template>
  <div v-if="thread" class="space-y-4">
    <Button variant="ghost" size="sm" class="gap-1" @click="emit('back')">
      <ArrowLeft class="h-4 w-4" />
      Back
    </Button>

    <Card>
      <CardContent class="pt-4">
        <div class="flex items-start gap-3">
          <Avatar class="h-8 w-8 shrink-0">
            <AvatarFallback class="text-xs">{{ (thread.user.name || '?')[0].toUpperCase() }}</AvatarFallback>
          </Avatar>
          <div>
            <p class="font-semibold">{{ thread.title }}</p>
            <p class="text-xs text-muted-foreground mb-2">
              {{ thread.user.name || 'User' }} &middot; {{ new Date(thread.createdAt).toLocaleDateString() }}
            </p>
            <p class="text-sm">{{ thread.content }}</p>
          </div>
        </div>
      </CardContent>
    </Card>

    <div class="space-y-3 pl-4 border-l-2 border-border">
      <div v-for="reply in thread.replies" :key="reply.id" class="flex items-start gap-3 py-2">
        <Avatar class="h-6 w-6 shrink-0">
          <AvatarFallback class="text-[10px]">{{ (reply.user.name || '?')[0].toUpperCase() }}</AvatarFallback>
        </Avatar>
        <div>
          <div class="text-xs text-muted-foreground mb-0.5">
            {{ reply.user.name || 'User' }} &middot; {{ new Date(reply.createdAt).toLocaleDateString() }}
          </div>
          <p class="text-sm">{{ reply.content }}</p>
        </div>
      </div>
    </div>

    <Card>
      <CardContent class="pt-4 space-y-3">
        <Textarea v-model="replyContent" placeholder="Write a reply..." rows="2" />
        <Button size="sm" :disabled="replying || !replyContent.trim()" @click="postReply">
          {{ replying ? 'Replying...' : 'Reply' }}
        </Button>
      </CardContent>
    </Card>
  </div>
</template>
