<script setup lang="ts">
import { Bell } from 'lucide-vue-next'

const { user } = useUserSession()
const { csrf, headerName } = useCsrf()

const unread = ref({ count: 0 })
const notifData = ref<{ notifications: any[] }>({ notifications: [] })
const isOpen = ref(false)

async function fetchUnread() {
  if (!user.value) return
  try {
    unread.value = await $fetch('/api/notifications/unread-count')
  } catch {}
}

async function fetchList() {
  if (!user.value) return
  try {
    notifData.value = await $fetch('/api/notifications')
  } catch {}
}

async function markAllRead() {
  await $fetch('/api/notifications/mark-read', {
    method: 'POST',
    body: {},
    headers: { [headerName]: csrf },
  })
  await Promise.all([fetchUnread(), fetchList()])
}

async function clickNotif(notif: any) {
  if (!notif.read) {
    await $fetch('/api/notifications/mark-read', {
      method: 'POST',
      body: { id: notif.id },
      headers: { [headerName]: csrf },
    })
    fetchUnread()
  }
  isOpen.value = false
  if (notif.link) navigateTo(notif.link)
}

let interval: ReturnType<typeof setInterval>
onMounted(() => {
  fetchUnread()
  fetchList()
  interval = setInterval(fetchUnread, 30000)
})
onUnmounted(() => clearInterval(interval))
</script>

<template>
  <ClientOnly>
    <DropdownMenu v-if="user" v-model:open="isOpen">
      <DropdownMenuTrigger as-child>
        <Button variant="ghost" size="icon" class="relative h-8 w-8">
          <Bell class="h-4 w-4" />
          <span
            v-if="unread.count > 0"
            class="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-medium text-white"
          >
            {{ unread.count > 9 ? '9+' : unread.count }}
          </span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" class="w-80">
        <div class="flex items-center justify-between px-3 py-2">
          <span class="text-sm font-semibold">Notifications</span>
          <Button v-if="unread.count > 0" variant="ghost" size="sm" class="h-auto py-0.5 text-xs" @click="markAllRead">
            Mark all read
          </Button>
        </div>
        <DropdownMenuSeparator />
        <div class="max-h-80 overflow-y-auto">
          <DropdownMenuItem
            v-for="notif in notifData.notifications?.slice(0, 10)"
            :key="notif.id"
            class="flex flex-col items-start gap-0.5 py-2 cursor-pointer"
            :class="!notif.read ? 'bg-accent/50' : ''"
            @click="clickNotif(notif)"
          >
            <span class="text-sm font-medium">{{ notif.title }}</span>
            <span class="text-xs text-muted-foreground line-clamp-2">{{ notif.message }}</span>
            <span class="text-[10px] text-muted-foreground">
              {{ new Date(notif.createdAt).toLocaleDateString() }}
            </span>
          </DropdownMenuItem>
          <div v-if="!notifData.notifications?.length" class="px-3 py-6 text-center text-sm text-muted-foreground">
            No notifications
          </div>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  </ClientOnly>
</template>
