<script setup lang="ts">
import { Star } from 'lucide-vue-next'

const props = withDefaults(defineProps<{
  modelValue?: number
  readonly?: boolean
  size?: number
}>(), {
  modelValue: 0,
  readonly: false,
  size: 20,
})

const emit = defineEmits<{ 'update:modelValue': [value: number] }>()

const hovered = ref(0)

function select(star: number) {
  if (!props.readonly) emit('update:modelValue', star)
}
</script>

<template>
  <div class="flex items-center gap-0.5">
    <button
      v-for="star in 5"
      :key="star"
      type="button"
      :class="readonly ? 'cursor-default' : 'cursor-pointer'"
      class="p-0 border-0 bg-transparent"
      @click="select(star)"
      @mouseenter="!readonly && (hovered = star)"
      @mouseleave="hovered = 0"
    >
      <Star
        :style="{ width: `${size}px`, height: `${size}px` }"
        :class="(hovered || modelValue) >= star
          ? 'fill-yellow-400 text-yellow-400'
          : 'text-muted-foreground/30'"
      />
    </button>
  </div>
</template>
