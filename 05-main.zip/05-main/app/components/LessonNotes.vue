<script setup lang="ts">
import { StickyNote } from 'lucide-vue-next'
import { toast } from 'vue-sonner'

const props = defineProps<{ lessonId: string }>()
const { csrf, headerName } = useCsrf()

const open = ref(false)
const content = ref('')
const saving = ref(false)
const loaded = ref(false)

async function load() {
  if (loaded.value) return
  try {
    const note = await $fetch(`/api/notes/${props.lessonId}`)
    if (note) content.value = note.content
    loaded.value = true
  } catch {}
}

async function save() {
  if (!content.value.trim()) return
  saving.value = true
  try {
    await $fetch(`/api/notes/${props.lessonId}`, {
      method: 'PUT',
      body: { content: content.value },
      headers: { [headerName]: csrf },
    })
    toast.success('Note saved')
  } catch {
    toast.error('Failed to save note')
  } finally {
    saving.value = false
  }
}

function toggleOpen() {
  open.value = !open.value
  if (open.value) load()
}
</script>

<template>
  <div>
    <Button variant="outline" size="sm" class="gap-2" @click="toggleOpen">
      <StickyNote class="h-4 w-4" />
      {{ open ? 'Hide Notes' : 'My Notes' }}
    </Button>
    <Card v-if="open" class="mt-3">
      <CardContent class="pt-4 space-y-3">
        <Textarea v-model="content" placeholder="Write your notes here..." rows="4" />
        <Button size="sm" :disabled="saving" @click="save">
          {{ saving ? 'Saving...' : 'Save Note' }}
        </Button>
      </CardContent>
    </Card>
  </div>
</template>
