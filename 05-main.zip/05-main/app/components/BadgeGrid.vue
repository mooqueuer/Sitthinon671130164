<script setup lang="ts">
import { Award, BookOpen, GraduationCap, CheckCircle, Trophy, Medal, Flame, Zap, Footprints } from 'lucide-vue-next'

defineProps<{
  badges: Array<{
    key: string
    name: string
    description: string
    icon: string
    earned: boolean
    earnedAt?: string | null
  }>
}>()

const iconMap: Record<string, any> = {
  footprints: Footprints,
  'book-open': BookOpen,
  'graduation-cap': GraduationCap,
  'check-circle': CheckCircle,
  trophy: Trophy,
  award: Award,
  medal: Medal,
  flame: Flame,
  zap: Zap,
}
</script>

<template>
  <div class="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-5">
    <div
      v-for="badge in badges"
      :key="badge.key"
      class="flex flex-col items-center gap-1.5 rounded-lg border p-3 text-center transition-colors"
      :class="badge.earned ? 'bg-primary/5 border-primary/20' : 'opacity-40'"
    >
      <component
        :is="iconMap[badge.icon] || Award"
        class="h-8 w-8"
        :class="badge.earned ? 'text-primary' : 'text-muted-foreground'"
      />
      <span class="text-xs font-medium line-clamp-1">{{ badge.name }}</span>
      <Tooltip>
        <TooltipTrigger as-child>
          <span class="text-[10px] text-muted-foreground line-clamp-1 cursor-help">
            {{ badge.description }}
          </span>
        </TooltipTrigger>
        <TooltipContent>{{ badge.description }}</TooltipContent>
      </Tooltip>
    </div>
  </div>
</template>
