<script setup lang="ts">
import { Flame } from 'lucide-vue-next'

defineProps<{ current: number; longest: number }>()
</script>

<template>
  <div class="flex items-center gap-1.5">
    <Flame class="h-5 w-5" :class="current > 0 ? 'text-orange-500' : 'text-muted-foreground/30'" />
    <div>
      <span class="text-sm font-semibold">{{ current }} day{{ current !== 1 ? 's' : '' }}</span>
      <span class="text-xs text-muted-foreground ml-1">(best: {{ longest }})</span>
    </div>
  </div>
</template>
