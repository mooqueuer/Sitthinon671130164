<script setup lang="ts">
const { user, clear } = useUserSession()
const { csrf, headerName } = useCsrf()

const loggingOut = ref(false)

const role = computed(() => (user.value as any)?.role)

async function logout() {
  loggingOut.value = true
  await clear()
  $fetch('/api/auth/logout', { method: 'POST', headers: { [headerName]: csrf } })
  await navigateTo('/login', { replace: true })
}
</script>

<template>
  <div class="min-h-screen bg-background">
    <header class="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div class="mx-auto flex h-14 max-w-6xl items-center justify-between px-4">
        <div class="flex items-center gap-6">
          <NuxtLink to="/" class="text-lg font-semibold tracking-tight">
            Panit
          </NuxtLink>
          <nav class="hidden items-center gap-4 text-sm md:flex">
            <NuxtLink to="/courses" class="text-muted-foreground transition-colors hover:text-foreground">
              Courses
            </NuxtLink>
            <NuxtLink to="/leaderboard" class="text-muted-foreground transition-colors hover:text-foreground">
              Leaderboard
            </NuxtLink>
            <NuxtLink v-if="user" to="/my-courses" class="text-muted-foreground transition-colors hover:text-foreground">
              My Courses
            </NuxtLink>
            <NuxtLink v-if="role === 'TEACHER' || role === 'ADMIN'" to="/teacher" class="text-muted-foreground transition-colors hover:text-foreground">
              Teacher Panel
            </NuxtLink>
            <NuxtLink v-if="role === 'ADMIN'" to="/admin" class="text-muted-foreground transition-colors hover:text-foreground">
              Admin
            </NuxtLink>
          </nav>
        </div>

        <div v-if="user" class="flex items-center gap-3">
          <ThemeToggle />
          <NotificationBell />
          <DropdownMenu>
            <DropdownMenuTrigger as-child>
              <Button variant="ghost" class="flex items-center gap-2">
                <Avatar class="h-7 w-7">
                  <AvatarFallback class="text-xs">
                    {{ (user.name || user.email || '?')[0].toUpperCase() }}
                  </AvatarFallback>
                </Avatar>
                <span class="hidden text-sm sm:inline-block">{{ user.name || user.email }}</span>
                <Badge variant="secondary" class="hidden text-[10px] sm:inline-flex">{{ role }}</Badge>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" class="w-48">
              <DropdownMenuLabel class="font-normal">
                <div class="flex flex-col gap-1">
                  <p class="text-sm font-medium">{{ user.name || 'User' }}</p>
                  <p class="text-xs text-muted-foreground truncate">{{ user.email }}</p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem as-child>
                <NuxtLink to="/dashboard">Dashboard</NuxtLink>
              </DropdownMenuItem>
              <DropdownMenuItem as-child>
                <NuxtLink to="/my-courses">My Courses</NuxtLink>
              </DropdownMenuItem>
              <DropdownMenuItem as-child>
                <NuxtLink to="/bookmarks">Bookmarks</NuxtLink>
              </DropdownMenuItem>
              <DropdownMenuItem as-child>
                <NuxtLink to="/certificates">Certificates</NuxtLink>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem @click="logout" :disabled="loggingOut" class="text-destructive focus:text-destructive">
                {{ loggingOut ? 'Logging out...' : 'Log out' }}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div v-else class="flex items-center gap-2">
          <ThemeToggle />
          <Button variant="ghost" as-child size="sm">
            <NuxtLink to="/login">Sign in</NuxtLink>
          </Button>
          <Button as-child size="sm">
            <NuxtLink to="/register">Get started</NuxtLink>
          </Button>
        </div>
      </div>
    </header>

    <main class="mx-auto max-w-6xl px-4 py-8">
      <slot />
    </main>
  </div>
</template>
