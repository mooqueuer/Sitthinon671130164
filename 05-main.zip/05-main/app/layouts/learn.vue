<script setup lang="ts">
const route = useRoute()
const courseId = computed(() => route.params.courseId as string)

const { data: course } = await useFetch(`/api/courses/${courseId.value}`)
const { data: progress } = await useFetch(`/api/enrollments/${courseId.value}/progress`, {
  default: () => ({ lessons: [], percentage: 0, completedLessons: 0, totalLessons: 0 }),
  onResponseError() {
    // Not enrolled or other error — silently fall back to zero progress
  },
})

const completedLessonIds = computed(() =>
  (progress.value?.lessons || []).filter((l: any) => l.completed).map((l: any) => l.lessonId)
)

const allLessons = computed(() =>
  (course.value?.chapters || []).flatMap((c: any) => c.lessons)
)

// Find quizzes linked to lessons for quick-link in sidebar
const lessonsWithQuiz = computed(() => {
  const map = new Map<string, string>()
  // We don't have quiz info in course chapters, so we skip for now
  return map
})

const sidebarOpen = ref(true)
</script>

<template>
  <div class="flex min-h-screen">
    <!-- Sidebar -->
    <aside
      class="fixed inset-y-0 left-0 z-40 w-80 border-r border-border bg-background transition-transform lg:translate-x-0"
      :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'"
    >
      <div class="flex h-14 items-center justify-between border-b px-4">
        <NuxtLink to="/my-courses" class="text-sm font-medium text-muted-foreground hover:text-foreground">
          &larr; Back
        </NuxtLink>
        <span class="text-xs text-muted-foreground">{{ progress?.percentage || 0 }}% complete</span>
      </div>
      <div class="p-4">
        <h2 class="mb-1 text-sm font-semibold line-clamp-2">{{ course?.title }}</h2>
        <Progress :model-value="progress?.percentage || 0" class="h-1.5" />
      </div>
      <ScrollArea class="h-[calc(100vh-8rem)]">
        <div class="space-y-4 p-4 pt-0">
          <div v-for="chapter in (course?.chapters || [])" :key="chapter.id">
            <p class="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              {{ chapter.title }}
            </p>
            <div class="space-y-1">
              <NuxtLink
                v-for="lesson in chapter.lessons"
                :key="lesson.id"
                :to="`/learn/${courseId}/${lesson.id}`"
                class="flex items-center gap-2 rounded-md px-2 py-1.5 text-sm transition-colors hover:bg-accent"
                :class="route.params.lessonId === lesson.id ? 'bg-accent font-medium' : ''"
              >
                <div
                  class="flex h-5 w-5 shrink-0 items-center justify-center rounded-full border text-[10px]"
                  :class="completedLessonIds.includes(lesson.id) ? 'border-primary bg-primary text-primary-foreground' : 'border-border'"
                >
                  <span v-if="completedLessonIds.includes(lesson.id)">&#10003;</span>
                </div>
                <span class="truncate">{{ lesson.title }}</span>
                <Badge v-if="lesson.type === 'VIDEO'" variant="secondary" class="ml-auto text-[9px]">Video</Badge>
              </NuxtLink>
            </div>
          </div>
        </div>
      </ScrollArea>
    </aside>

    <!-- Main content -->
    <div class="flex-1 lg:ml-80">
      <header class="sticky top-0 z-30 flex h-14 items-center border-b bg-background px-4 lg:hidden">
        <button @click="sidebarOpen = !sidebarOpen" class="mr-4 p-1">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" x2="21" y1="6" y2="6"/><line x1="3" x2="21" y1="12" y2="12"/><line x1="3" x2="21" y1="18" y2="18"/></svg>
        </button>
        <span class="text-sm font-medium truncate flex-1">{{ course?.title }}</span>
        <NotificationBell />
        <ThemeToggle />
      </header>
      <main class="p-6">
        <slot />
      </main>
    </div>

    <!-- Mobile overlay -->
    <div
      v-if="sidebarOpen"
      class="fixed inset-0 z-30 bg-black/50 lg:hidden"
      @click="sidebarOpen = false"
    />
  </div>
</template>
