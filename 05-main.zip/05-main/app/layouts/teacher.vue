<script setup lang="ts">
const route = useRoute()
const { user, clear } = useUserSession()
const { csrf, headerName } = useCsrf()

const navItems = [
  { label: 'Dashboard', to: '/teacher' },
  { label: 'My Courses', to: '/teacher/courses' },
  { label: 'Analytics', to: '/teacher/analytics' },
]

const mobileOpen = ref(false)

async function logout() {
  await clear()
  $fetch('/api/auth/logout', { method: 'POST', headers: { [headerName]: csrf } })
  await navigateTo('/login', { replace: true })
}
</script>

<template>
  <div class="flex min-h-screen">
    <!-- Desktop sidebar -->
    <aside class="hidden w-64 border-r border-border bg-background lg:block">
      <div class="flex h-14 items-center justify-between border-b px-6">
        <div class="flex items-center">
          <NuxtLink to="/" class="text-lg font-semibold">Panit</NuxtLink>
          <Badge variant="secondary" class="ml-2 text-[10px]">Teacher</Badge>
        </div>
        <div class="flex items-center gap-1">
          <NotificationBell />
          <ThemeToggle />
        </div>
      </div>
      <nav class="space-y-1 p-4">
        <NuxtLink
          v-for="item in navItems"
          :key="item.to"
          :to="item.to"
          class="flex items-center rounded-md px-3 py-2 text-sm transition-colors hover:bg-accent"
          :class="route.path === item.to ? 'bg-accent font-medium' : 'text-muted-foreground'"
        >
          {{ item.label }}
        </NuxtLink>
      </nav>
      <div class="absolute bottom-0 w-64 border-t p-4">
        <div class="mb-2 truncate text-sm font-medium">{{ user?.name || user?.email }}</div>
        <Button variant="ghost" size="sm" class="w-full justify-start text-destructive" @click="logout">
          Log out
        </Button>
      </div>
    </aside>

    <!-- Mobile Sheet sidebar -->
    <Sheet v-model:open="mobileOpen">
      <SheetContent side="left" class="w-64 p-0">
        <SheetHeader class="border-b px-6 py-4">
          <SheetTitle class="flex items-center text-left">
            <span class="text-lg font-semibold">Panit</span>
            <Badge variant="secondary" class="ml-2 text-[10px]">Teacher</Badge>
          </SheetTitle>
        </SheetHeader>
        <nav class="space-y-1 p-4">
          <NuxtLink
            v-for="item in navItems"
            :key="item.to"
            :to="item.to"
            class="flex items-center rounded-md px-3 py-2 text-sm transition-colors hover:bg-accent"
            :class="route.path === item.to ? 'bg-accent font-medium' : 'text-muted-foreground'"
            @click="mobileOpen = false"
          >
            {{ item.label }}
          </NuxtLink>
        </nav>
        <div class="absolute bottom-0 w-full border-t p-4">
          <div class="mb-2 truncate text-sm font-medium">{{ user?.name || user?.email }}</div>
          <Button variant="ghost" size="sm" class="w-full justify-start text-destructive" @click="logout">
            Log out
          </Button>
        </div>
      </SheetContent>
    </Sheet>

    <div class="flex-1">
      <header class="sticky top-0 z-30 flex h-14 items-center border-b bg-background px-6 lg:hidden">
        <button @click="mobileOpen = true" class="mr-4 p-1">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" x2="21" y1="6" y2="6"/><line x1="3" x2="21" y1="12" y2="12"/><line x1="3" x2="21" y1="18" y2="18"/></svg>
        </button>
        <NuxtLink to="/" class="text-lg font-semibold">Panit</NuxtLink>
        <Badge variant="secondary" class="ml-2 text-[10px]">Teacher</Badge>
        <div class="ml-auto flex items-center gap-1">
          <NotificationBell />
          <ThemeToggle />
        </div>
      </header>
      <main class="p-6">
        <slot />
      </main>
    </div>
  </div>
</template>
