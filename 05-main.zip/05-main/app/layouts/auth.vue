<template>
  <div class="grid min-h-screen lg:grid-cols-2">
    <!-- Left: Branding Panel -->
    <div class="relative hidden bg-zinc-950 lg:flex lg:flex-col lg:justify-between p-10">
      <div class="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:4rem_4rem]" />

      <div class="relative">
        <div class="flex items-center gap-2 text-white">
          <div class="flex h-8 w-8 items-center justify-center rounded-lg bg-white">
            <span class="text-sm font-bold text-zinc-950">P</span>
          </div>
          <span class="text-lg font-semibold">Panit</span>
        </div>
      </div>

      <div class="relative space-y-6">
        <blockquote class="space-y-4">
          <p class="text-xl font-medium leading-relaxed text-white/90">
            "Simple, secure, and built for modern workflows."
          </p>
          <footer class="text-sm text-white/50">
            &mdash; Secure authentication system
          </footer>
        </blockquote>
      </div>

      <div class="relative text-xs text-white/30">
        &copy; {{ new Date().getFullYear() }} Panit. All rights reserved.
      </div>
    </div>

    <!-- Right: Form -->
    <div class="flex items-center justify-center p-6 sm:p-10">
      <div class="w-full max-w-[400px]">
        <!-- Mobile logo -->
        <div class="mb-8 flex items-center justify-center gap-2 lg:hidden">
          <div class="flex h-8 w-8 items-center justify-center rounded-lg bg-zinc-950">
            <span class="text-sm font-bold text-white">P</span>
          </div>
          <span class="text-lg font-semibold">Panit</span>
        </div>

        <slot />
      </div>
    </div>
  </div>
</template>
