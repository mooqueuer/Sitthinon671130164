export default defineNuxtRouteMiddleware(() => {
  const { loggedIn, user } = useUserSession()

  if (!loggedIn.value) {
    return navigateTo('/login')
  }

  const role = (user.value as any)?.role
  if (role !== 'TEACHER' && role !== 'ADMIN') {
    return navigateTo('/')
  }
})
